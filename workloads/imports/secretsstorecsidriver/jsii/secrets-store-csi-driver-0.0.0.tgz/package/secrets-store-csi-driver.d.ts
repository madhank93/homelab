import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface SecretsstorecsidriverProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values?: {
        [key: string]: any;
    };
}
export declare class Secretsstorecsidriver extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props?: SecretsstorecsidriverProps);
    private flattenAdditionalValues;
}
