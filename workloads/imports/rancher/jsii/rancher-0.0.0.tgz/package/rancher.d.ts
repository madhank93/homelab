import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface RancherProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values?: RancherValues;
}
export declare class Rancher extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props?: RancherProps);
    private flattenAdditionalValues;
}
/**
 * @schema rancher
 */
export interface RancherValues {
    /**
     * agentTLSMode must be 'strict' or 'system-store' or null (defaults to system-store)
     *
     * @schema rancher#agentTLSMode
     */
    readonly agentTlsMode?: RancherAgentTlsMode;
    /**
     * @schema rancher#auditLog
     */
    readonly auditLog?: RancherAuditLog;
    /**
     * The default rancher service configuration
     *
     * @schema rancher#service
     */
    readonly service?: RancherService;
    /**
     * The default rancher ingress configuration
     *
     * @schema rancher#ingress
     */
    readonly ingress?: RancherIngress;
    /**
     * @schema rancher#global
     */
    readonly global?: {
        [key: string]: any;
    };
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema rancher#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherValues' to JSON representation.
 */
export declare function toJson_RancherValues(obj: RancherValues | undefined): Record<string, any> | undefined;
/**
 * agentTLSMode must be 'strict' or 'system-store' or null (defaults to system-store)
 *
 * @schema RancherAgentTlsMode
 */
export declare enum RancherAgentTlsMode {
    /** strict */
    STRICT = "strict",
    /** system-store */
    SYSTEM_HYPHEN_STORE = "system-store"
}
/**
 * @schema RancherAuditLog
 */
export interface RancherAuditLog {
    /**
     * auditLog.destination must be either 'sidecar' or 'hostPath'
     *
     * @schema RancherAuditLog#destination
     */
    readonly destination?: RancherAuditLogDestination;
    /**
     * auditLog.level must be a number 0-3; 0 to disable, 3 for most verbose
     *
     * @schema RancherAuditLog#level
     */
    readonly level?: RancherAuditLogLevel;
    /**
     * auditLog.enabled must be a boolean
     *
     * @schema RancherAuditLog#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherAuditLog#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherAuditLog' to JSON representation.
 */
export declare function toJson_RancherAuditLog(obj: RancherAuditLog | undefined): Record<string, any> | undefined;
/**
 * The default rancher service configuration
 *
 * @schema RancherService
 */
export interface RancherService {
    /**
     * @schema RancherService#type
     */
    readonly type?: RancherServiceType;
    /**
     * @schema RancherService#disableHTTP
     */
    readonly disableHttp?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherService#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherService' to JSON representation.
 */
export declare function toJson_RancherService(obj: RancherService | undefined): Record<string, any> | undefined;
/**
 * The default rancher ingress configuration
 *
 * @schema RancherIngress
 */
export interface RancherIngress {
    /**
     * @schema RancherIngress#servicePort
     */
    readonly servicePort?: RancherIngressServicePort;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherIngress#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherIngress' to JSON representation.
 */
export declare function toJson_RancherIngress(obj: RancherIngress | undefined): Record<string, any> | undefined;
/**
 * auditLog.destination must be either 'sidecar' or 'hostPath'
 *
 * @schema RancherAuditLogDestination
 */
export declare enum RancherAuditLogDestination {
    /** sidecar */
    SIDECAR = "sidecar",
    /** hostPath */
    HOST_PATH = "hostPath"
}
/**
 * auditLog.level must be a number 0-3; 0 to disable, 3 for most verbose
 *
 * @schema RancherAuditLogLevel
 */
export declare enum RancherAuditLogLevel {
    /** 0 */
    VALUE_0 = 0,
    /** 1 */
    VALUE_1 = 1,
    /** 2 */
    VALUE_2 = 2,
    /** 3 */
    VALUE_3 = 3
}
/**
 * @schema RancherServiceType
 */
export declare enum RancherServiceType {
    /** ClusterIP */
    CLUSTER_IP = "ClusterIP",
    /** LoadBalancer */
    LOAD_BALANCER = "LoadBalancer",
    /** NodePort */
    NODE_PORT = "NodePort"
}
/**
 * @schema RancherIngressServicePort
 */
export declare enum RancherIngressServicePort {
    /** 443 */
    VALUE_443 = 443,
    /** 80 */
    VALUE_80 = 80
}
