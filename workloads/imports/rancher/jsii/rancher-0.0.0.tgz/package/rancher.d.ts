import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface RancherProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values?: RancherValues;
}
export declare class Rancher extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props?: RancherProps);
    private flattenAdditionalValues;
}
/**
 * @schema rancher
 */
export interface RancherValues {
    /**
     * agentTLSMode must be 'strict' or 'system-store' or null (defaults to system-store)
     *
     * @schema rancher#agentTLSMode
     */
    readonly agentTlsMode?: RancherAgentTlsMode;
    /**
     * @schema rancher#auditLog
     */
    readonly auditLog?: RancherAuditLog;
    /**
     * The default rancher service configuration
     *
     * @schema rancher#service
     */
    readonly service?: RancherService;
    /**
     * The default rancher network exposure configuration
     *
     * @schema rancher#networkExposure
     */
    readonly networkExposure?: RancherNetworkExposure;
    /**
     * The default rancher ingress configuration
     *
     * @schema rancher#ingress
     */
    readonly ingress?: RancherIngress;
    /**
     * The default rancher gateway configuration
     *
     * @schema rancher#gateway
     */
    readonly gateway?: RancherGateway;
    /**
     * @schema rancher#global
     */
    readonly global?: {
        [key: string]: any;
    };
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema rancher#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherValues' to JSON representation.
 */
export declare function toJson_RancherValues(obj: RancherValues | undefined): Record<string, any> | undefined;
/**
 * agentTLSMode must be 'strict' or 'system-store' or null (defaults to system-store)
 *
 * @schema RancherAgentTlsMode
 */
export declare enum RancherAgentTlsMode {
    /** strict */
    STRICT = "strict",
    /** system-store */
    SYSTEM_HYPHEN_STORE = "system-store"
}
/**
 * @schema RancherAuditLog
 */
export interface RancherAuditLog {
    /**
     * auditLog.destination must be either 'sidecar' or 'hostPath'
     *
     * @schema RancherAuditLog#destination
     */
    readonly destination?: RancherAuditLogDestination;
    /**
     * auditLog.level must be a number 0-3; 0 to disable, 3 for most verbose
     *
     * @schema RancherAuditLog#level
     */
    readonly level?: RancherAuditLogLevel;
    /**
     * auditLog.enabled must be a boolean
     *
     * @schema RancherAuditLog#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherAuditLog#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherAuditLog' to JSON representation.
 */
export declare function toJson_RancherAuditLog(obj: RancherAuditLog | undefined): Record<string, any> | undefined;
/**
 * The default rancher service configuration
 *
 * @schema RancherService
 */
export interface RancherService {
    /**
     * @schema RancherService#type
     */
    readonly type?: RancherServiceType;
    /**
     * @schema RancherService#disableHTTP
     */
    readonly disableHttp?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherService#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherService' to JSON representation.
 */
export declare function toJson_RancherService(obj: RancherService | undefined): Record<string, any> | undefined;
/**
 * The default rancher network exposure configuration
 *
 * @schema RancherNetworkExposure
 */
export interface RancherNetworkExposure {
    /**
     * @schema RancherNetworkExposure#type
     */
    readonly type?: RancherNetworkExposureType;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherNetworkExposure#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherNetworkExposure' to JSON representation.
 */
export declare function toJson_RancherNetworkExposure(obj: RancherNetworkExposure | undefined): Record<string, any> | undefined;
/**
 * The default rancher ingress configuration
 *
 * @schema RancherIngress
 */
export interface RancherIngress {
    /**
     * @schema RancherIngress#servicePort
     */
    readonly servicePort?: RancherIngressServicePort;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherIngress#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherIngress' to JSON representation.
 */
export declare function toJson_RancherIngress(obj: RancherIngress | undefined): Record<string, any> | undefined;
/**
 * The default rancher gateway configuration
 *
 * @schema RancherGateway
 */
export interface RancherGateway {
    /**
     * The default rancher gateway class configuration
     *
     * @schema RancherGateway#gatewayClass
     */
    readonly gatewayClass?: RancherGatewayGatewayClass;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherGateway#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherGateway' to JSON representation.
 */
export declare function toJson_RancherGateway(obj: RancherGateway | undefined): Record<string, any> | undefined;
/**
 * auditLog.destination must be either 'sidecar' or 'hostPath'
 *
 * @schema RancherAuditLogDestination
 */
export declare enum RancherAuditLogDestination {
    /** sidecar */
    SIDECAR = "sidecar",
    /** hostPath */
    HOST_PATH = "hostPath"
}
/**
 * auditLog.level must be a number 0-3; 0 to disable, 3 for most verbose
 *
 * @schema RancherAuditLogLevel
 */
export declare enum RancherAuditLogLevel {
    /** 0 */
    VALUE_0 = 0,
    /** 1 */
    VALUE_1 = 1,
    /** 2 */
    VALUE_2 = 2,
    /** 3 */
    VALUE_3 = 3
}
/**
 * @schema RancherServiceType
 */
export declare enum RancherServiceType {
    /** ClusterIP */
    CLUSTER_IP = "ClusterIP",
    /** LoadBalancer */
    LOAD_BALANCER = "LoadBalancer",
    /** NodePort */
    NODE_PORT = "NodePort"
}
/**
 * @schema RancherNetworkExposureType
 */
export declare enum RancherNetworkExposureType {
    /** ingress */
    INGRESS = "ingress",
    /** gateway */
    GATEWAY = "gateway",
    /** none */
    NONE = "none"
}
/**
 * @schema RancherIngressServicePort
 */
export declare enum RancherIngressServicePort {
    /** 443 */
    VALUE_443 = 443,
    /** 80 */
    VALUE_80 = 80
}
/**
 * The default rancher gateway class configuration
 *
 * @schema RancherGatewayGatewayClass
 */
export interface RancherGatewayGatewayClass {
    /**
     * @schema RancherGatewayGatewayClass#name
     */
    readonly name?: string;
    /**
     * The default rancher gateway class ports configuration
     *
     * @schema RancherGatewayGatewayClass#ports
     */
    readonly ports?: RancherGatewayGatewayClassPorts;
    /**
     * @schema RancherGatewayGatewayClass#additionalListeners
     */
    readonly additionalListeners?: RancherGatewayGatewayClassAdditionalListeners[];
    /**
     * The default rancher gateway class tls configuration
     *
     * @schema RancherGatewayGatewayClass#tls
     */
    readonly tls?: RancherGatewayGatewayClassTls;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherGatewayGatewayClass#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherGatewayGatewayClass' to JSON representation.
 */
export declare function toJson_RancherGatewayGatewayClass(obj: RancherGatewayGatewayClass | undefined): Record<string, any> | undefined;
/**
 * The default rancher gateway class ports configuration
 *
 * @schema RancherGatewayGatewayClassPorts
 */
export interface RancherGatewayGatewayClassPorts {
    /**
     * @schema RancherGatewayGatewayClassPorts#http
     */
    readonly http?: number;
    /**
     * @schema RancherGatewayGatewayClassPorts#https
     */
    readonly https?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherGatewayGatewayClassPorts#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherGatewayGatewayClassPorts' to JSON representation.
 */
export declare function toJson_RancherGatewayGatewayClassPorts(obj: RancherGatewayGatewayClassPorts | undefined): Record<string, any> | undefined;
/**
 * @schema RancherGatewayGatewayClassAdditionalListeners
 */
export interface RancherGatewayGatewayClassAdditionalListeners {
    /**
     * @schema RancherGatewayGatewayClassAdditionalListeners#name
     */
    readonly name: string;
    /**
     * @schema RancherGatewayGatewayClassAdditionalListeners#protocol
     */
    readonly protocol: RancherGatewayGatewayClassAdditionalListenersProtocol;
    /**
     * @schema RancherGatewayGatewayClassAdditionalListeners#port
     */
    readonly port: number;
    /**
     * @schema RancherGatewayGatewayClassAdditionalListeners#hostname
     */
    readonly hostname?: string;
    /**
     * @schema RancherGatewayGatewayClassAdditionalListeners#tls
     */
    readonly tls?: RancherGatewayGatewayClassAdditionalListenersTls;
}
/**
 * Converts an object of type 'RancherGatewayGatewayClassAdditionalListeners' to JSON representation.
 */
export declare function toJson_RancherGatewayGatewayClassAdditionalListeners(obj: RancherGatewayGatewayClassAdditionalListeners | undefined): Record<string, any> | undefined;
/**
 * The default rancher gateway class tls configuration
 *
 * @schema RancherGatewayGatewayClassTls
 */
export interface RancherGatewayGatewayClassTls {
    /**
     * @schema RancherGatewayGatewayClassTls#source
     */
    readonly source?: RancherGatewayGatewayClassTlsSource;
    /**
     * @schema RancherGatewayGatewayClassTls#secretName
     */
    readonly secretName?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema RancherGatewayGatewayClassTls#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'RancherGatewayGatewayClassTls' to JSON representation.
 */
export declare function toJson_RancherGatewayGatewayClassTls(obj: RancherGatewayGatewayClassTls | undefined): Record<string, any> | undefined;
/**
 * @schema RancherGatewayGatewayClassAdditionalListenersProtocol
 */
export declare enum RancherGatewayGatewayClassAdditionalListenersProtocol {
    /** HTTP */
    HTTP = "HTTP",
    /** HTTPS */
    HTTPS = "HTTPS",
    /** TCP */
    TCP = "TCP",
    /** UDP */
    UDP = "UDP"
}
/**
 * @schema RancherGatewayGatewayClassAdditionalListenersTls
 */
export interface RancherGatewayGatewayClassAdditionalListenersTls {
    /**
     * @schema RancherGatewayGatewayClassAdditionalListenersTls#mode
     */
    readonly mode?: RancherGatewayGatewayClassAdditionalListenersTlsMode;
    /**
     * @schema RancherGatewayGatewayClassAdditionalListenersTls#certificateRefs
     */
    readonly certificateRefs?: RancherGatewayGatewayClassAdditionalListenersTlsCertificateRefs[];
}
/**
 * Converts an object of type 'RancherGatewayGatewayClassAdditionalListenersTls' to JSON representation.
 */
export declare function toJson_RancherGatewayGatewayClassAdditionalListenersTls(obj: RancherGatewayGatewayClassAdditionalListenersTls | undefined): Record<string, any> | undefined;
/**
 * @schema RancherGatewayGatewayClassTlsSource
 */
export declare enum RancherGatewayGatewayClassTlsSource {
    /** rancher */
    RANCHER = "rancher",
    /** letsEncrypt */
    LETS_ENCRYPT = "letsEncrypt",
    /** secret */
    SECRET = "secret"
}
/**
 * @schema RancherGatewayGatewayClassAdditionalListenersTlsMode
 */
export declare enum RancherGatewayGatewayClassAdditionalListenersTlsMode {
    /** Terminate */
    TERMINATE = "Terminate",
    /** Passthrough */
    PASSTHROUGH = "Passthrough"
}
/**
 * @schema RancherGatewayGatewayClassAdditionalListenersTlsCertificateRefs
 */
export interface RancherGatewayGatewayClassAdditionalListenersTlsCertificateRefs {
    /**
     * @schema RancherGatewayGatewayClassAdditionalListenersTlsCertificateRefs#name
     */
    readonly name?: string;
    /**
     * @schema RancherGatewayGatewayClassAdditionalListenersTlsCertificateRefs#kind
     */
    readonly kind?: string;
}
/**
 * Converts an object of type 'RancherGatewayGatewayClassAdditionalListenersTlsCertificateRefs' to JSON representation.
 */
export declare function toJson_RancherGatewayGatewayClassAdditionalListenersTlsCertificateRefs(obj: RancherGatewayGatewayClassAdditionalListenersTlsCertificateRefs | undefined): Record<string, any> | undefined;
