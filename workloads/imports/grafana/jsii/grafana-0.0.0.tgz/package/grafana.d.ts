import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface GrafanaProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values?: GrafanaValues;
}
export declare class Grafana extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props?: GrafanaProps);
    private flattenAdditionalValues;
}
/**
 * @schema grafana
 */
export interface GrafanaValues {
    /**
     * @schema grafana#admin
     */
    readonly admin?: GrafanaAdmin;
    /**
     * @schema grafana#adminUser
     */
    readonly adminUser?: string;
    /**
     * @schema grafana#affinity
     */
    readonly affinity?: any;
    /**
     * @schema grafana#alerting
     */
    readonly alerting?: any;
    /**
     * @schema grafana#assertNoLeakedSecrets
     */
    readonly assertNoLeakedSecrets?: boolean;
    /**
     * @schema grafana#automountServiceAccountToken
     */
    readonly automountServiceAccountToken?: boolean;
    /**
     * @schema grafana#autoscaling
     */
    readonly autoscaling?: GrafanaAutoscaling;
    /**
     * @schema grafana#containerSecurityContext
     */
    readonly containerSecurityContext?: any;
    /**
     * @schema grafana#createConfigmap
     */
    readonly createConfigmap?: boolean;
    /**
     * @schema grafana#dashboardProviders
     */
    readonly dashboardProviders?: any;
    /**
     * @schema grafana#dashboards
     */
    readonly dashboards?: any;
    /**
     * @schema grafana#dashboardsConfigMaps
     */
    readonly dashboardsConfigMaps?: any;
    /**
     * @schema grafana#datasources
     */
    readonly datasources?: any;
    /**
     * @schema grafana#defaultCurlOptions
     */
    readonly defaultCurlOptions?: string;
    /**
     * @schema grafana#defaultShellOptions
     */
    readonly defaultShellOptions?: string;
    /**
     * @schema grafana#deploymentStrategy
     */
    readonly deploymentStrategy?: any;
    /**
     * @schema grafana#dnsConfig
     */
    readonly dnsConfig?: any;
    /**
     * @schema grafana#dnsPolicy
     */
    readonly dnsPolicy?: string;
    /**
     * @schema grafana#downloadDashboards
     */
    readonly downloadDashboards?: GrafanaDownloadDashboards;
    /**
     * @schema grafana#downloadDashboardsImage
     */
    readonly downloadDashboardsImage?: GrafanaDownloadDashboardsImage;
    /**
     * @schema grafana#enableKubeBackwardCompatibility
     */
    readonly enableKubeBackwardCompatibility?: boolean;
    /**
     * @schema grafana#enableServiceLinks
     */
    readonly enableServiceLinks?: boolean;
    /**
     * @schema grafana#env
     */
    readonly env?: any;
    /**
     * @schema grafana#envFromConfigMaps
     */
    readonly envFromConfigMaps?: any[];
    /**
     * @schema grafana#envFromSecret
     */
    readonly envFromSecret?: string;
    /**
     * @schema grafana#envFromSecrets
     */
    readonly envFromSecrets?: any[];
    /**
     * @schema grafana#envRenderSecret
     */
    readonly envRenderSecret?: any;
    /**
     * @schema grafana#envValueFrom
     */
    readonly envValueFrom?: any;
    /**
     * @schema grafana#extraConfigmapMounts
     */
    readonly extraConfigmapMounts?: any[];
    /**
     * @schema grafana#extraContainerVolumes
     */
    readonly extraContainerVolumes?: any[];
    /**
     * @schema grafana#extraContainers
     */
    readonly extraContainers?: any;
    /**
     * @schema grafana#extraEmptyDirMounts
     */
    readonly extraEmptyDirMounts?: any[];
    /**
     * @schema grafana#extraExposePorts
     */
    readonly extraExposePorts?: any[];
    /**
     * @schema grafana#extraInitContainers
     */
    readonly extraInitContainers?: any[];
    /**
     * @schema grafana#extraLabels
     */
    readonly extraLabels?: {
        [key: string]: string;
    };
    /**
     * @schema grafana#extraObjects
     */
    readonly extraObjects?: any[];
    /**
     * @schema grafana#extraSecretMounts
     */
    readonly extraSecretMounts?: any[];
    /**
     * @schema grafana#extraVolumeMounts
     */
    readonly extraVolumeMounts?: any[];
    /**
     * @schema grafana#extraVolumes
     */
    readonly extraVolumes?: any[];
    /**
     * @schema grafana#global
     */
    readonly global?: {
        [key: string]: any;
    };
    /**
     * @schema grafana#goMemLimit
     */
    readonly goMemLimit?: GrafanaGoMemLimit;
    /**
     * @schema grafana#gossipPortName
     */
    readonly gossipPortName?: string;
    /**
     * @schema grafana#grafana.ini
     */
    readonly grafanaIni?: any;
    /**
     * @schema grafana#headlessService
     */
    readonly headlessService?: boolean;
    /**
     * @schema grafana#hostAliases
     */
    readonly hostAliases?: any[];
    /**
     * @schema grafana#hostUsers
     */
    readonly hostUsers?: boolean;
    /**
     * @schema grafana#image
     */
    readonly image?: GrafanaImage;
    /**
     * @schema grafana#imageRenderer
     */
    readonly imageRenderer?: GrafanaImageRenderer;
    /**
     * @schema grafana#ingress
     */
    readonly ingress?: GrafanaIngress;
    /**
     * @schema grafana#initChownData
     */
    readonly initChownData?: GrafanaInitChownData;
    /**
     * @schema grafana#ldap
     */
    readonly ldap?: GrafanaLdap;
    /**
     * @schema grafana#lifecycleHooks
     */
    readonly lifecycleHooks?: any;
    /**
     * BETA: Configure Gateway API ListenerSet resources for the chart here. ListenerSet allows attaching additional listeners to an existing Gateway. More listener sets can be added by adding a dictionary key like the 'main' entry. Being BETA this can/will change in the future without notice, do not use unless you want to take that risk [[ref]](https://gateway-api.sigs.k8s.io/reference/api-spec/main/spec/#listenerset)
     *
     * @schema grafana#listenerSet
     */
    readonly listenerSet?: GrafanaListenerSet;
    /**
     * @schema grafana#livenessProbe
     */
    readonly livenessProbe?: any;
    /**
     * @schema grafana#namespaceOverride
     */
    readonly namespaceOverride?: string;
    /**
     * @schema grafana#networkPolicy
     */
    readonly networkPolicy?: GrafanaNetworkPolicy;
    /**
     * @schema grafana#nodeSelector
     */
    readonly nodeSelector?: any;
    /**
     * @schema grafana#notifiers
     */
    readonly notifiers?: any;
    /**
     * @schema grafana#persistence
     */
    readonly persistence?: GrafanaPersistence;
    /**
     * @schema grafana#plugins
     */
    readonly plugins?: any[];
    /**
     * @schema grafana#podDisruptionBudget
     */
    readonly podDisruptionBudget?: any;
    /**
     * @schema grafana#podManagementPolicy
     */
    readonly podManagementPolicy?: string;
    /**
     * @schema grafana#podPortName
     */
    readonly podPortName?: string;
    /**
     * @schema grafana#progressDeadlineSeconds
     */
    readonly progressDeadlineSeconds?: number;
    /**
     * @schema grafana#rbac
     */
    readonly rbac?: GrafanaRbac;
    /**
     * @schema grafana#readinessProbe
     */
    readonly readinessProbe?: any;
    /**
     * @schema grafana#replicas
     */
    readonly replicas?: number;
    /**
     * @schema grafana#resources
     */
    readonly resources?: any;
    /**
     * @schema grafana#revisionHistoryLimit
     */
    readonly revisionHistoryLimit?: number;
    /**
     * BETA: Configure the gateway routes for the chart here. More routes can be added by adding a dictionary key like the 'main' route. Be aware that this is an early beta of this feature, kube-prometheus-stack does not guarantee this works and is subject to change. Being BETA this can/will change in the future without notice, do not use unless you want to take that risk [[ref]](https://gateway-api.sigs.k8s.io/references/spec/#gateway.networking.k8s.io%2fv1alpha2)
     *
     * @schema grafana#route
     */
    readonly route?: GrafanaRoute;
    /**
     * @schema grafana#securityContext
     */
    readonly securityContext?: any;
    /**
     * @schema grafana#service
     */
    readonly service?: GrafanaService;
    /**
     * @schema grafana#serviceAccount
     */
    readonly serviceAccount?: GrafanaServiceAccount;
    /**
     * @schema grafana#serviceMonitor
     */
    readonly serviceMonitor?: GrafanaServiceMonitor;
    /**
     * @schema grafana#shadowBundledPlugins
     */
    readonly shadowBundledPlugins?: boolean;
    /**
     * @schema grafana#shareProcessNamespace
     */
    readonly shareProcessNamespace?: boolean;
    /**
     * @schema grafana#sidecar
     */
    readonly sidecar?: GrafanaSidecar;
    /**
     * @schema grafana#smtp
     */
    readonly smtp?: GrafanaSmtp;
    /**
     * @schema grafana#startupProbe
     */
    readonly startupProbe?: any;
    /**
     * @schema grafana#testFramework
     */
    readonly testFramework?: GrafanaTestFramework;
    /**
     * @schema grafana#tolerations
     */
    readonly tolerations?: any[];
    /**
     * @schema grafana#topologySpreadConstraints
     */
    readonly topologySpreadConstraints?: any[];
    /**
     * @schema grafana#useStatefulSet
     */
    readonly useStatefulSet?: boolean;
    /**
     * @schema grafana#verticalPodAutoscaler
     */
    readonly verticalPodAutoscaler?: GrafanaVerticalPodAutoscaler;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema grafana#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaValues' to JSON representation.
 */
export declare function toJson_GrafanaValues(obj: GrafanaValues | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaAdmin
 */
export interface GrafanaAdmin {
    /**
     * @schema GrafanaAdmin#existingSecret
     */
    readonly existingSecret?: string;
    /**
     * @schema GrafanaAdmin#passwordKey
     */
    readonly passwordKey?: string;
    /**
     * @schema GrafanaAdmin#userKey
     */
    readonly userKey?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaAdmin#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaAdmin' to JSON representation.
 */
export declare function toJson_GrafanaAdmin(obj: GrafanaAdmin | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaAutoscaling
 */
export interface GrafanaAutoscaling {
    /**
     * @schema GrafanaAutoscaling#behavior
     */
    readonly behavior?: any;
    /**
     * @schema GrafanaAutoscaling#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaAutoscaling#maxReplicas
     */
    readonly maxReplicas?: number;
    /**
     * @schema GrafanaAutoscaling#minReplicas
     */
    readonly minReplicas?: number;
    /**
     * @schema GrafanaAutoscaling#targetCPU
     */
    readonly targetCpu?: any;
    /**
     * @schema GrafanaAutoscaling#targetMemory
     */
    readonly targetMemory?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaAutoscaling#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaAutoscaling' to JSON representation.
 */
export declare function toJson_GrafanaAutoscaling(obj: GrafanaAutoscaling | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaDownloadDashboards
 */
export interface GrafanaDownloadDashboards {
    /**
     * @schema GrafanaDownloadDashboards#env
     */
    readonly env?: any;
    /**
     * @schema GrafanaDownloadDashboards#envFromSecret
     */
    readonly envFromSecret?: string;
    /**
     * @schema GrafanaDownloadDashboards#envValueFrom
     */
    readonly envValueFrom?: any;
    /**
     * @schema GrafanaDownloadDashboards#resources
     */
    readonly resources?: any;
    /**
     * @schema GrafanaDownloadDashboards#securityContext
     */
    readonly securityContext?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaDownloadDashboards#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaDownloadDashboards' to JSON representation.
 */
export declare function toJson_GrafanaDownloadDashboards(obj: GrafanaDownloadDashboards | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaDownloadDashboardsImage
 */
export interface GrafanaDownloadDashboardsImage {
    /**
     * @schema GrafanaDownloadDashboardsImage#pullPolicy
     */
    readonly pullPolicy?: string;
    /**
     * The Docker registry
     *
     * @schema GrafanaDownloadDashboardsImage#registry
     */
    readonly registry?: string;
    /**
     * @schema GrafanaDownloadDashboardsImage#repository
     */
    readonly repository?: string;
    /**
     * @schema GrafanaDownloadDashboardsImage#sha
     */
    readonly sha?: string;
    /**
     * @schema GrafanaDownloadDashboardsImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaDownloadDashboardsImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaDownloadDashboardsImage' to JSON representation.
 */
export declare function toJson_GrafanaDownloadDashboardsImage(obj: GrafanaDownloadDashboardsImage | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaGoMemLimit
 */
export interface GrafanaGoMemLimit {
    /**
     * Enable automatic GOMEMLIMIT injection.
     *
     * @schema GrafanaGoMemLimit#enabled
     */
    readonly enabled?: boolean;
    /**
     * Fraction of resources.limits.memory to use as GOMEMLIMIT (e.g. 0.9 = 90 %).
     *
     * @schema GrafanaGoMemLimit#factor
     */
    readonly factor?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaGoMemLimit#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaGoMemLimit' to JSON representation.
 */
export declare function toJson_GrafanaGoMemLimit(obj: GrafanaGoMemLimit | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaImage
 */
export interface GrafanaImage {
    /**
     * @schema GrafanaImage#pullPolicy
     */
    readonly pullPolicy?: string;
    /**
     * @schema GrafanaImage#pullSecrets
     */
    readonly pullSecrets?: any[];
    /**
     * The Docker registry
     *
     * @schema GrafanaImage#registry
     */
    readonly registry?: string;
    /**
     * Docker image repository
     *
     * @schema GrafanaImage#repository
     */
    readonly repository?: string;
    /**
     * @schema GrafanaImage#sha
     */
    readonly sha?: string;
    /**
     * @schema GrafanaImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaImage' to JSON representation.
 */
export declare function toJson_GrafanaImage(obj: GrafanaImage | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaImageRenderer
 */
export interface GrafanaImageRenderer {
    /**
     * @schema GrafanaImageRenderer#affinity
     */
    readonly affinity?: any;
    /**
     * @schema GrafanaImageRenderer#automountServiceAccountToken
     */
    readonly automountServiceAccountToken?: boolean;
    /**
     * @schema GrafanaImageRenderer#autoscaling
     */
    readonly autoscaling?: GrafanaImageRendererAutoscaling;
    /**
     * @schema GrafanaImageRenderer#containerSecurityContext
     */
    readonly containerSecurityContext?: any;
    /**
     * @schema GrafanaImageRenderer#deploymentStrategy
     */
    readonly deploymentStrategy?: any;
    /**
     * @schema GrafanaImageRenderer#dnsConfig
     */
    readonly dnsConfig?: any;
    /**
     * @schema GrafanaImageRenderer#dnsPolicy
     */
    readonly dnsPolicy?: string;
    /**
     * @schema GrafanaImageRenderer#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaImageRenderer#env
     */
    readonly env?: any;
    /**
     * @schema GrafanaImageRenderer#envValueFrom
     */
    readonly envValueFrom?: any;
    /**
     * @schema GrafanaImageRenderer#existingSecret
     */
    readonly existingSecret?: string;
    /**
     * @schema GrafanaImageRenderer#extraConfigmapMounts
     */
    readonly extraConfigmapMounts?: any[];
    /**
     * @schema GrafanaImageRenderer#extraSecretMounts
     */
    readonly extraSecretMounts?: any[];
    /**
     * @schema GrafanaImageRenderer#extraVolumeMounts
     */
    readonly extraVolumeMounts?: any[];
    /**
     * @schema GrafanaImageRenderer#extraVolumes
     */
    readonly extraVolumes?: any[];
    /**
     * @schema GrafanaImageRenderer#grafanaProtocol
     */
    readonly grafanaProtocol?: string;
    /**
     * @schema GrafanaImageRenderer#grafanaSubPath
     */
    readonly grafanaSubPath?: string;
    /**
     * @schema GrafanaImageRenderer#healthcheckPath
     */
    readonly healthcheckPath?: string;
    /**
     * @schema GrafanaImageRenderer#hostAliases
     */
    readonly hostAliases?: any[];
    /**
     * @schema GrafanaImageRenderer#hostUsers
     */
    readonly hostUsers?: boolean;
    /**
     * @schema GrafanaImageRenderer#image
     */
    readonly image?: GrafanaImageRendererImage;
    /**
     * @schema GrafanaImageRenderer#networkPolicy
     */
    readonly networkPolicy?: GrafanaImageRendererNetworkPolicy;
    /**
     * @schema GrafanaImageRenderer#nodeSelector
     */
    readonly nodeSelector?: any;
    /**
     * @schema GrafanaImageRenderer#podAnnotations
     */
    readonly podAnnotations?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaImageRenderer#podPortName
     */
    readonly podPortName?: string;
    /**
     * @schema GrafanaImageRenderer#priorityClassName
     */
    readonly priorityClassName?: string;
    /**
     * @schema GrafanaImageRenderer#progressDeadlineSeconds
     */
    readonly progressDeadlineSeconds?: number;
    /**
     * @schema GrafanaImageRenderer#readinessProbe
     */
    readonly readinessProbe?: any;
    /**
     * @schema GrafanaImageRenderer#renderingCallbackURL
     */
    readonly renderingCallbackUrl?: string;
    /**
     * @schema GrafanaImageRenderer#replicas
     */
    readonly replicas?: number;
    /**
     * @schema GrafanaImageRenderer#resources
     */
    readonly resources?: any;
    /**
     * @schema GrafanaImageRenderer#revisionHistoryLimit
     */
    readonly revisionHistoryLimit?: number;
    /**
     * @schema GrafanaImageRenderer#securityContext
     */
    readonly securityContext?: any;
    /**
     * @schema GrafanaImageRenderer#serverURL
     */
    readonly serverUrl?: string;
    /**
     * @schema GrafanaImageRenderer#service
     */
    readonly service?: GrafanaImageRendererService;
    /**
     * @schema GrafanaImageRenderer#serviceAccountName
     */
    readonly serviceAccountName?: string;
    /**
     * @schema GrafanaImageRenderer#serviceMonitor
     */
    readonly serviceMonitor?: GrafanaImageRendererServiceMonitor;
    /**
     * @schema GrafanaImageRenderer#token
     */
    readonly token?: string;
    /**
     * @schema GrafanaImageRenderer#tolerations
     */
    readonly tolerations?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaImageRenderer#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaImageRenderer' to JSON representation.
 */
export declare function toJson_GrafanaImageRenderer(obj: GrafanaImageRenderer | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaIngress
 */
export interface GrafanaIngress {
    /**
     * @schema GrafanaIngress#annotations
     */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaIngress#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaIngress#extraPaths
     */
    readonly extraPaths?: any[];
    /**
     * @schema GrafanaIngress#hosts
     */
    readonly hosts?: string[];
    /**
     * @schema GrafanaIngress#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaIngress#path
     */
    readonly path?: string;
    /**
     * @schema GrafanaIngress#pathType
     */
    readonly pathType?: string;
    /**
     * @schema GrafanaIngress#tls
     */
    readonly tls?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaIngress#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaIngress' to JSON representation.
 */
export declare function toJson_GrafanaIngress(obj: GrafanaIngress | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaInitChownData
 */
export interface GrafanaInitChownData {
    /**
     * @schema GrafanaInitChownData#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaInitChownData#image
     */
    readonly image?: GrafanaInitChownDataImage;
    /**
     * @schema GrafanaInitChownData#resources
     */
    readonly resources?: any;
    /**
     * @schema GrafanaInitChownData#securityContext
     */
    readonly securityContext?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaInitChownData#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaInitChownData' to JSON representation.
 */
export declare function toJson_GrafanaInitChownData(obj: GrafanaInitChownData | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaLdap
 */
export interface GrafanaLdap {
    /**
     * @schema GrafanaLdap#config
     */
    readonly config?: string;
    /**
     * @schema GrafanaLdap#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaLdap#existingSecret
     */
    readonly existingSecret?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaLdap#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaLdap' to JSON representation.
 */
export declare function toJson_GrafanaLdap(obj: GrafanaLdap | undefined): Record<string, any> | undefined;
/**
 * BETA: Configure Gateway API ListenerSet resources for the chart here. ListenerSet allows attaching additional listeners to an existing Gateway. More listener sets can be added by adding a dictionary key like the 'main' entry. Being BETA this can/will change in the future without notice, do not use unless you want to take that risk [[ref]](https://gateway-api.sigs.k8s.io/reference/api-spec/main/spec/#listenerset)
 *
 * @schema GrafanaListenerSet
 */
export interface GrafanaListenerSet {
    /**
     * @schema GrafanaListenerSet#main
     */
    readonly main?: GrafanaListenerSetMain;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaListenerSet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaListenerSet' to JSON representation.
 */
export declare function toJson_GrafanaListenerSet(obj: GrafanaListenerSet | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaNetworkPolicy
 */
export interface GrafanaNetworkPolicy {
    /**
     * Don't require client label for connections. The Policy model to apply. When set to false, only pods with the correct client label will have network access to grafana port defined. When true, grafana will accept connections from any source (with the correct destination port).
     *
     * @schema GrafanaNetworkPolicy#allowExternal
     */
    readonly allowExternal?: boolean;
    /**
     * @schema GrafanaNetworkPolicy#egress
     */
    readonly egress?: GrafanaNetworkPolicyEgress;
    /**
     * Enable creation of NetworkPolicy resources. Only Ingress traffic is filtered for now.
     *
     * @schema GrafanaNetworkPolicy#enabled
     */
    readonly enabled?: boolean;
    /**
     * List of CIDR blocks allowed as ingress sources. Each entry must be a valid CIDR notation string (e.g. 10.0.0.0/8). When defined, the specified CIDR ranges are added to the ingress `from` rules using `ipBlock` entries and complement the other configured ingress sources. </br>  Example:  ``` explicitIpBlocks: - 35.191.0.0/16 - 130.211.0.0/22 ```
     *
     * @schema GrafanaNetworkPolicy#explicitIpBlocks
     */
    readonly explicitIpBlocks?: any[];
    /**
     * A Kubernetes LabelSelector to explicitly select namespaces from which traffic could be allowed If explicitNamespacesSelector is missing or set to {}, only client Pods that are in the networkPolicy's namespace and that match other criteria, the ones that have the good label, can reach the grafana. But sometimes, we want the grafana to be accessible to clients from other namespaces, in this case, we can use this LabelSelector to select these namespaces, note that the networkPolicy's namespace should also be explicitly added. </br>  Example:  ``` explicitNamespacesSelector: matchLabels: role: frontend matchExpressions: - {key: role, operator: In, values: [frontend]} ```
     *
     * @schema GrafanaNetworkPolicy#explicitNamespacesSelector
     */
    readonly explicitNamespacesSelector?: any;
    /**
     * When true enables the creation of an ingress network policy
     *
     * @schema GrafanaNetworkPolicy#ingress
     */
    readonly ingress?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaNetworkPolicy#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaNetworkPolicy' to JSON representation.
 */
export declare function toJson_GrafanaNetworkPolicy(obj: GrafanaNetworkPolicy | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaPersistence
 */
export interface GrafanaPersistence {
    /**
     * @schema GrafanaPersistence#accessModes
     */
    readonly accessModes?: string[];
    /**
     * @schema GrafanaPersistence#disableWarning
     */
    readonly disableWarning?: boolean;
    /**
     * @schema GrafanaPersistence#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaPersistence#extraPvcLabels
     */
    readonly extraPvcLabels?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaPersistence#finalizers
     */
    readonly finalizers?: string[];
    /**
     * @schema GrafanaPersistence#inMemory
     */
    readonly inMemory?: GrafanaPersistenceInMemory;
    /**
     * @schema GrafanaPersistence#lookupVolumeName
     */
    readonly lookupVolumeName?: boolean;
    /**
     * @schema GrafanaPersistence#persistentVolumeClaimRetentionPolicy
     */
    readonly persistentVolumeClaimRetentionPolicy?: any;
    /**
     * @schema GrafanaPersistence#size
     */
    readonly size?: any;
    /**
     * @schema GrafanaPersistence#type
     */
    readonly type?: string;
    /**
     * @schema GrafanaPersistence#volumeName
     */
    readonly volumeName?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaPersistence#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaPersistence' to JSON representation.
 */
export declare function toJson_GrafanaPersistence(obj: GrafanaPersistence | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaRbac
 */
export interface GrafanaRbac {
    /**
     * @schema GrafanaRbac#create
     */
    readonly create?: boolean;
    /**
     * @schema GrafanaRbac#extraClusterRoleRules
     */
    readonly extraClusterRoleRules?: any[];
    /**
     * @schema GrafanaRbac#extraRoleRules
     */
    readonly extraRoleRules?: any[];
    /**
     * @schema GrafanaRbac#namespaced
     */
    readonly namespaced?: boolean;
    /**
     * @schema GrafanaRbac#namespaces
     */
    readonly namespaces?: any[];
    /**
     * @schema GrafanaRbac#pspEnabled
     */
    readonly pspEnabled?: boolean;
    /**
     * @schema GrafanaRbac#pspUseAppArmor
     */
    readonly pspUseAppArmor?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaRbac#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaRbac' to JSON representation.
 */
export declare function toJson_GrafanaRbac(obj: GrafanaRbac | undefined): Record<string, any> | undefined;
/**
 * BETA: Configure the gateway routes for the chart here. More routes can be added by adding a dictionary key like the 'main' route. Be aware that this is an early beta of this feature, kube-prometheus-stack does not guarantee this works and is subject to change. Being BETA this can/will change in the future without notice, do not use unless you want to take that risk [[ref]](https://gateway-api.sigs.k8s.io/references/spec/#gateway.networking.k8s.io%2fv1alpha2)
 *
 * @schema GrafanaRoute
 */
export interface GrafanaRoute {
    /**
     * @schema GrafanaRoute#main
     */
    readonly main?: GrafanaRouteMain;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaRoute#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaRoute' to JSON representation.
 */
export declare function toJson_GrafanaRoute(obj: GrafanaRoute | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaService
 */
export interface GrafanaService {
    /**
     * @schema GrafanaService#annotations
     */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaService#appProtocol
     */
    readonly appProtocol?: string;
    /**
     * @schema GrafanaService#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaService#ipFamilies
     */
    readonly ipFamilies?: any[];
    /**
     * @schema GrafanaService#ipFamilyPolicy
     */
    readonly ipFamilyPolicy?: string;
    /**
     * @schema GrafanaService#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaService#loadBalancerClass
     */
    readonly loadBalancerClass?: string;
    /**
     * @schema GrafanaService#loadBalancerIP
     */
    readonly loadBalancerIp?: string;
    /**
     * @schema GrafanaService#loadBalancerSourceRanges
     */
    readonly loadBalancerSourceRanges?: any[];
    /**
     * @schema GrafanaService#port
     */
    readonly port?: number;
    /**
     * @schema GrafanaService#portName
     */
    readonly portName?: string;
    /**
     * @schema GrafanaService#sessionAffinity
     */
    readonly sessionAffinity?: string;
    /**
     * @schema GrafanaService#targetPort
     */
    readonly targetPort?: number;
    /**
     * @schema GrafanaService#trafficDistribution
     */
    readonly trafficDistribution?: string;
    /**
     * @schema GrafanaService#type
     */
    readonly type?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaService#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaService' to JSON representation.
 */
export declare function toJson_GrafanaService(obj: GrafanaService | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaServiceAccount
 */
export interface GrafanaServiceAccount {
    /**
     * @schema GrafanaServiceAccount#automountServiceAccountToken
     */
    readonly automountServiceAccountToken?: boolean;
    /**
     * @schema GrafanaServiceAccount#create
     */
    readonly create?: boolean;
    /**
     * @schema GrafanaServiceAccount#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaServiceAccount#name
     */
    readonly name?: string;
    /**
     * @schema GrafanaServiceAccount#nameTest
     */
    readonly nameTest?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaServiceAccount#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaServiceAccount' to JSON representation.
 */
export declare function toJson_GrafanaServiceAccount(obj: GrafanaServiceAccount | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaServiceMonitor
 */
export interface GrafanaServiceMonitor {
    /**
     * @schema GrafanaServiceMonitor#basicAuth
     */
    readonly basicAuth?: any;
    /**
     * @schema GrafanaServiceMonitor#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaServiceMonitor#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaServiceMonitor#metricRelabelings
     */
    readonly metricRelabelings?: any[];
    /**
     * @schema GrafanaServiceMonitor#path
     */
    readonly path?: string;
    /**
     * @schema GrafanaServiceMonitor#relabelings
     */
    readonly relabelings?: any[];
    /**
     * @schema GrafanaServiceMonitor#scheme
     */
    readonly scheme?: string;
    /**
     * @schema GrafanaServiceMonitor#targetLabels
     */
    readonly targetLabels?: any[];
    /**
     * @schema GrafanaServiceMonitor#tlsConfig
     */
    readonly tlsConfig?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaServiceMonitor#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaServiceMonitor' to JSON representation.
 */
export declare function toJson_GrafanaServiceMonitor(obj: GrafanaServiceMonitor | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSidecar
 */
export interface GrafanaSidecar {
    /**
     * @schema GrafanaSidecar#alerts
     */
    readonly alerts?: GrafanaSidecarAlerts;
    /**
     * @schema GrafanaSidecar#dashboards
     */
    readonly dashboards?: GrafanaSidecarDashboards;
    /**
     * @schema GrafanaSidecar#datasources
     */
    readonly datasources?: GrafanaSidecarDatasources;
    /**
     * @schema GrafanaSidecar#enableUniqueFilenames
     */
    readonly enableUniqueFilenames?: boolean;
    /**
     * @schema GrafanaSidecar#image
     */
    readonly image?: GrafanaSidecarImage;
    /**
     * @schema GrafanaSidecar#imagePullPolicy
     */
    readonly imagePullPolicy?: string;
    /**
     * @schema GrafanaSidecar#livenessProbe
     */
    readonly livenessProbe?: any;
    /**
     * @schema GrafanaSidecar#notifiers
     */
    readonly notifiers?: GrafanaSidecarNotifiers;
    /**
     * @schema GrafanaSidecar#plugins
     */
    readonly plugins?: GrafanaSidecarPlugins;
    /**
     * @schema GrafanaSidecar#readinessProbe
     */
    readonly readinessProbe?: any;
    /**
     * @schema GrafanaSidecar#resources
     */
    readonly resources?: any;
    /**
     * @schema GrafanaSidecar#securityContext
     */
    readonly securityContext?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSidecar#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSidecar' to JSON representation.
 */
export declare function toJson_GrafanaSidecar(obj: GrafanaSidecar | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSmtp
 */
export interface GrafanaSmtp {
    /**
     * @schema GrafanaSmtp#existingSecret
     */
    readonly existingSecret?: string;
    /**
     * @schema GrafanaSmtp#passwordKey
     */
    readonly passwordKey?: string;
    /**
     * @schema GrafanaSmtp#userKey
     */
    readonly userKey?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSmtp#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSmtp' to JSON representation.
 */
export declare function toJson_GrafanaSmtp(obj: GrafanaSmtp | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaTestFramework
 */
export interface GrafanaTestFramework {
    /**
     * @schema GrafanaTestFramework#containerSecurityContext
     */
    readonly containerSecurityContext?: any;
    /**
     * @schema GrafanaTestFramework#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaTestFramework#image
     */
    readonly image?: GrafanaTestFrameworkImage;
    /**
     * @schema GrafanaTestFramework#imagePullPolicy
     */
    readonly imagePullPolicy?: string;
    /**
     * @schema GrafanaTestFramework#resources
     */
    readonly resources?: any;
    /**
     * @schema GrafanaTestFramework#securityContext
     */
    readonly securityContext?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaTestFramework#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaTestFramework' to JSON representation.
 */
export declare function toJson_GrafanaTestFramework(obj: GrafanaTestFramework | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaVerticalPodAutoscaler
 */
export interface GrafanaVerticalPodAutoscaler {
    /**
     * @schema GrafanaVerticalPodAutoscaler#controlledResources
     */
    readonly controlledResources?: GrafanaVerticalPodAutoscalerControlledResources;
    /**
     * @schema GrafanaVerticalPodAutoscaler#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaVerticalPodAutoscaler#maxAllowed
     */
    readonly maxAllowed?: {
        [key: string]: any;
    };
    /**
     * @schema GrafanaVerticalPodAutoscaler#minAllowed
     */
    readonly minAllowed?: {
        [key: string]: any;
    };
    /**
     * @schema GrafanaVerticalPodAutoscaler#updateMode
     */
    readonly updateMode?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaVerticalPodAutoscaler#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaVerticalPodAutoscaler' to JSON representation.
 */
export declare function toJson_GrafanaVerticalPodAutoscaler(obj: GrafanaVerticalPodAutoscaler | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaImageRendererAutoscaling
 */
export interface GrafanaImageRendererAutoscaling {
    /**
     * @schema GrafanaImageRendererAutoscaling#behavior
     */
    readonly behavior?: any;
    /**
     * @schema GrafanaImageRendererAutoscaling#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaImageRendererAutoscaling#maxReplicas
     */
    readonly maxReplicas?: number;
    /**
     * @schema GrafanaImageRendererAutoscaling#minReplicas
     */
    readonly minReplicas?: number;
    /**
     * @schema GrafanaImageRendererAutoscaling#targetCPU
     */
    readonly targetCpu?: any;
    /**
     * @schema GrafanaImageRendererAutoscaling#targetMemory
     */
    readonly targetMemory?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaImageRendererAutoscaling#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaImageRendererAutoscaling' to JSON representation.
 */
export declare function toJson_GrafanaImageRendererAutoscaling(obj: GrafanaImageRendererAutoscaling | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaImageRendererImage
 */
export interface GrafanaImageRendererImage {
    /**
     * @schema GrafanaImageRendererImage#pullPolicy
     */
    readonly pullPolicy?: string;
    /**
     * @schema GrafanaImageRendererImage#pullSecrets
     */
    readonly pullSecrets?: any[];
    /**
     * The Docker registry
     *
     * @schema GrafanaImageRendererImage#registry
     */
    readonly registry?: string;
    /**
     * @schema GrafanaImageRendererImage#repository
     */
    readonly repository?: string;
    /**
     * @schema GrafanaImageRendererImage#sha
     */
    readonly sha?: string;
    /**
     * @schema GrafanaImageRendererImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaImageRendererImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaImageRendererImage' to JSON representation.
 */
export declare function toJson_GrafanaImageRendererImage(obj: GrafanaImageRendererImage | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaImageRendererNetworkPolicy
 */
export interface GrafanaImageRendererNetworkPolicy {
    /**
     * @schema GrafanaImageRendererNetworkPolicy#extraIngressSelectors
     */
    readonly extraIngressSelectors?: any[];
    /**
     * @schema GrafanaImageRendererNetworkPolicy#limitEgress
     */
    readonly limitEgress?: boolean;
    /**
     * @schema GrafanaImageRendererNetworkPolicy#limitIngress
     */
    readonly limitIngress?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaImageRendererNetworkPolicy#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaImageRendererNetworkPolicy' to JSON representation.
 */
export declare function toJson_GrafanaImageRendererNetworkPolicy(obj: GrafanaImageRendererNetworkPolicy | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaImageRendererService
 */
export interface GrafanaImageRendererService {
    /**
     * @schema GrafanaImageRendererService#appProtocol
     */
    readonly appProtocol?: string;
    /**
     * @schema GrafanaImageRendererService#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaImageRendererService#port
     */
    readonly port?: number;
    /**
     * @schema GrafanaImageRendererService#portName
     */
    readonly portName?: string;
    /**
     * @schema GrafanaImageRendererService#targetPort
     */
    readonly targetPort?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaImageRendererService#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaImageRendererService' to JSON representation.
 */
export declare function toJson_GrafanaImageRendererService(obj: GrafanaImageRendererService | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaImageRendererServiceMonitor
 */
export interface GrafanaImageRendererServiceMonitor {
    /**
     * @schema GrafanaImageRendererServiceMonitor#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaImageRendererServiceMonitor#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaImageRendererServiceMonitor#path
     */
    readonly path?: string;
    /**
     * @schema GrafanaImageRendererServiceMonitor#relabelings
     */
    readonly relabelings?: any[];
    /**
     * @schema GrafanaImageRendererServiceMonitor#scheme
     */
    readonly scheme?: string;
    /**
     * @schema GrafanaImageRendererServiceMonitor#targetLabels
     */
    readonly targetLabels?: any[];
    /**
     * @schema GrafanaImageRendererServiceMonitor#tlsConfig
     */
    readonly tlsConfig?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaImageRendererServiceMonitor#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaImageRendererServiceMonitor' to JSON representation.
 */
export declare function toJson_GrafanaImageRendererServiceMonitor(obj: GrafanaImageRendererServiceMonitor | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaInitChownDataImage
 */
export interface GrafanaInitChownDataImage {
    /**
     * @schema GrafanaInitChownDataImage#pullPolicy
     */
    readonly pullPolicy?: string;
    /**
     * The Docker registry
     *
     * @schema GrafanaInitChownDataImage#registry
     */
    readonly registry?: string;
    /**
     * @schema GrafanaInitChownDataImage#repository
     */
    readonly repository?: string;
    /**
     * @schema GrafanaInitChownDataImage#sha
     */
    readonly sha?: string;
    /**
     * @schema GrafanaInitChownDataImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaInitChownDataImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaInitChownDataImage' to JSON representation.
 */
export declare function toJson_GrafanaInitChownDataImage(obj: GrafanaInitChownDataImage | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaListenerSetMain
 */
export interface GrafanaListenerSetMain {
    /**
     * @schema GrafanaListenerSetMain#annotations
     */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
     * Set the ListenerSet apiVersion, e.g. gateway.networking.k8s.io/v1
     *
     * @schema GrafanaListenerSetMain#apiVersion
     */
    readonly apiVersion?: string;
    /**
     * Enables or disables the listener set
     *
     * @schema GrafanaListenerSetMain#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaListenerSetMain#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * List of listeners to attach to the parent Gateway
     *
     * @schema GrafanaListenerSetMain#listeners
     */
    readonly listeners?: any[];
    /**
     * Reference to the parent Gateway this ListenerSet attaches to
     *
     * @schema GrafanaListenerSetMain#parentRef
     */
    readonly parentRef?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaListenerSetMain#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaListenerSetMain' to JSON representation.
 */
export declare function toJson_GrafanaListenerSetMain(obj: GrafanaListenerSetMain | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaNetworkPolicyEgress
 */
export interface GrafanaNetworkPolicyEgress {
    /**
     * When enabled, DNS resolution will be blocked for all pods in the grafana namespace.
     *
     * @schema GrafanaNetworkPolicyEgress#blockDNSResolution
     */
    readonly blockDnsResolution?: boolean;
    /**
     * When enabled, an egress network policy will be created allowing grafana to connect to external data sources from kubernetes cluster.
     *
     * @schema GrafanaNetworkPolicyEgress#enabled
     */
    readonly enabled?: boolean;
    /**
     * Add individual ports to be allowed by the egress
     *
     * @schema GrafanaNetworkPolicyEgress#ports
     */
    readonly ports?: any[];
    /**
     * Allow egress traffic to specific destinations
     *
     * @schema GrafanaNetworkPolicyEgress#to
     */
    readonly to?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaNetworkPolicyEgress#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaNetworkPolicyEgress' to JSON representation.
 */
export declare function toJson_GrafanaNetworkPolicyEgress(obj: GrafanaNetworkPolicyEgress | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaPersistenceInMemory
 */
export interface GrafanaPersistenceInMemory {
    /**
     * @schema GrafanaPersistenceInMemory#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaPersistenceInMemory#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaPersistenceInMemory' to JSON representation.
 */
export declare function toJson_GrafanaPersistenceInMemory(obj: GrafanaPersistenceInMemory | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaRouteMain
 */
export interface GrafanaRouteMain {
    /**
     * @schema GrafanaRouteMain#additionalRules
     */
    readonly additionalRules?: any[];
    /**
     * @schema GrafanaRouteMain#annotations
     */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
     * Set the route apiVersion, e.g. gateway.networking.k8s.io/v1 or gateway.networking.k8s.io/v1alpha2
     *
     * @schema GrafanaRouteMain#apiVersion
     */
    readonly apiVersion?: string;
    /**
     * Enables or disables the route
     *
     * @schema GrafanaRouteMain#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaRouteMain#filters
     */
    readonly filters?: any[];
    /**
     * @schema GrafanaRouteMain#hostnames
     */
    readonly hostnames?: any[];
    /**
     * @schema GrafanaRouteMain#httpsRedirect
     */
    readonly httpsRedirect?: boolean;
    /**
     * Set the route kind Valid options are GRPCRoute, HTTPRoute, TCPRoute, TLSRoute, UDPRoute
     *
     * @schema GrafanaRouteMain#kind
     */
    readonly kind?: string;
    /**
     * @schema GrafanaRouteMain#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * @schema GrafanaRouteMain#matches
     */
    readonly matches?: GrafanaRouteMainMatches[];
    /**
     * @schema GrafanaRouteMain#parentRefs
     */
    readonly parentRefs?: any[];
    /**
     * @schema GrafanaRouteMain#sessionPersistence
     */
    readonly sessionPersistence?: any;
    /**
     * @schema GrafanaRouteMain#timeouts
     */
    readonly timeouts?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaRouteMain#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaRouteMain' to JSON representation.
 */
export declare function toJson_GrafanaRouteMain(obj: GrafanaRouteMain | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSidecarAlerts
 */
export interface GrafanaSidecarAlerts {
    /**
     * @schema GrafanaSidecarAlerts#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaSidecarAlerts#env
     */
    readonly env?: any;
    /**
     * @schema GrafanaSidecarAlerts#envValueFrom
     */
    readonly envValueFrom?: any;
    /**
     * @schema GrafanaSidecarAlerts#extraMounts
     */
    readonly extraMounts?: any[];
    /**
     * @schema GrafanaSidecarAlerts#initAlerts
     */
    readonly initAlerts?: boolean;
    /**
     * @schema GrafanaSidecarAlerts#label
     */
    readonly label?: string;
    /**
     * @schema GrafanaSidecarAlerts#labelValue
     */
    readonly labelValue?: string;
    /**
     * @schema GrafanaSidecarAlerts#reloadURL
     */
    readonly reloadUrl?: string;
    /**
     * @schema GrafanaSidecarAlerts#resource
     */
    readonly resource?: string;
    /**
     * @schema GrafanaSidecarAlerts#resourceName
     */
    readonly resourceName?: string;
    /**
     * @schema GrafanaSidecarAlerts#script
     */
    readonly script?: string;
    /**
     * @schema GrafanaSidecarAlerts#searchNamespace
     */
    readonly searchNamespace?: any;
    /**
     * @schema GrafanaSidecarAlerts#sizeLimit
     */
    readonly sizeLimit?: any;
    /**
     * @schema GrafanaSidecarAlerts#skipReload
     */
    readonly skipReload?: boolean;
    /**
     * @schema GrafanaSidecarAlerts#watchMethod
     */
    readonly watchMethod?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSidecarAlerts#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSidecarAlerts' to JSON representation.
 */
export declare function toJson_GrafanaSidecarAlerts(obj: GrafanaSidecarAlerts | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSidecarDashboards
 */
export interface GrafanaSidecarDashboards {
    /**
     * @schema GrafanaSidecarDashboards#SCProvider
     */
    readonly scProvider?: boolean;
    /**
     * @schema GrafanaSidecarDashboards#defaultFolderName
     */
    readonly defaultFolderName?: string;
    /**
     * @schema GrafanaSidecarDashboards#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaSidecarDashboards#env
     */
    readonly env?: any;
    /**
     * @schema GrafanaSidecarDashboards#envValueFrom
     */
    readonly envValueFrom?: any;
    /**
     * @schema GrafanaSidecarDashboards#extraMounts
     */
    readonly extraMounts?: any[];
    /**
     * @schema GrafanaSidecarDashboards#folder
     */
    readonly folder?: string;
    /**
     * @schema GrafanaSidecarDashboards#folderAnnotation
     */
    readonly folderAnnotation?: string;
    /**
     * @schema GrafanaSidecarDashboards#initDashboards
     */
    readonly initDashboards?: boolean;
    /**
     * @schema GrafanaSidecarDashboards#label
     */
    readonly label?: string;
    /**
     * @schema GrafanaSidecarDashboards#labelValue
     */
    readonly labelValue?: string;
    /**
     * @schema GrafanaSidecarDashboards#provider
     */
    readonly provider?: GrafanaSidecarDashboardsProvider;
    /**
     * @schema GrafanaSidecarDashboards#reloadURL
     */
    readonly reloadUrl?: string;
    /**
     * @schema GrafanaSidecarDashboards#resource
     */
    readonly resource?: string;
    /**
     * @schema GrafanaSidecarDashboards#resourceName
     */
    readonly resourceName?: string;
    /**
     * @schema GrafanaSidecarDashboards#script
     */
    readonly script?: string;
    /**
     * @schema GrafanaSidecarDashboards#searchNamespace
     */
    readonly searchNamespace?: any;
    /**
     * @schema GrafanaSidecarDashboards#sizeLimit
     */
    readonly sizeLimit?: any;
    /**
     * @schema GrafanaSidecarDashboards#skipReload
     */
    readonly skipReload?: boolean;
    /**
     * @schema GrafanaSidecarDashboards#watchMethod
     */
    readonly watchMethod?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSidecarDashboards#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSidecarDashboards' to JSON representation.
 */
export declare function toJson_GrafanaSidecarDashboards(obj: GrafanaSidecarDashboards | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSidecarDatasources
 */
export interface GrafanaSidecarDatasources {
    /**
     * @schema GrafanaSidecarDatasources#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaSidecarDatasources#env
     */
    readonly env?: any;
    /**
     * @schema GrafanaSidecarDatasources#envValueFrom
     */
    readonly envValueFrom?: any;
    /**
     * @schema GrafanaSidecarDatasources#extraMounts
     */
    readonly extraMounts?: any[];
    /**
     * @schema GrafanaSidecarDatasources#initDatasources
     */
    readonly initDatasources?: boolean;
    /**
     * @schema GrafanaSidecarDatasources#label
     */
    readonly label?: string;
    /**
     * @schema GrafanaSidecarDatasources#labelValue
     */
    readonly labelValue?: string;
    /**
     * @schema GrafanaSidecarDatasources#reloadURL
     */
    readonly reloadUrl?: string;
    /**
     * @schema GrafanaSidecarDatasources#resource
     */
    readonly resource?: string;
    /**
     * @schema GrafanaSidecarDatasources#resourceName
     */
    readonly resourceName?: string;
    /**
     * @schema GrafanaSidecarDatasources#script
     */
    readonly script?: string;
    /**
     * @schema GrafanaSidecarDatasources#searchNamespace
     */
    readonly searchNamespace?: any;
    /**
     * @schema GrafanaSidecarDatasources#sizeLimit
     */
    readonly sizeLimit?: any;
    /**
     * @schema GrafanaSidecarDatasources#skipReload
     */
    readonly skipReload?: boolean;
    /**
     * @schema GrafanaSidecarDatasources#watchMethod
     */
    readonly watchMethod?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSidecarDatasources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSidecarDatasources' to JSON representation.
 */
export declare function toJson_GrafanaSidecarDatasources(obj: GrafanaSidecarDatasources | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSidecarImage
 */
export interface GrafanaSidecarImage {
    /**
     * The Docker registry
     *
     * @schema GrafanaSidecarImage#registry
     */
    readonly registry?: string;
    /**
     * @schema GrafanaSidecarImage#repository
     */
    readonly repository?: string;
    /**
     * @schema GrafanaSidecarImage#sha
     */
    readonly sha?: string;
    /**
     * @schema GrafanaSidecarImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSidecarImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSidecarImage' to JSON representation.
 */
export declare function toJson_GrafanaSidecarImage(obj: GrafanaSidecarImage | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSidecarNotifiers
 */
export interface GrafanaSidecarNotifiers {
    /**
     * @schema GrafanaSidecarNotifiers#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaSidecarNotifiers#env
     */
    readonly env?: any;
    /**
     * @schema GrafanaSidecarNotifiers#extraMounts
     */
    readonly extraMounts?: any[];
    /**
     * @schema GrafanaSidecarNotifiers#initNotifiers
     */
    readonly initNotifiers?: boolean;
    /**
     * @schema GrafanaSidecarNotifiers#label
     */
    readonly label?: string;
    /**
     * @schema GrafanaSidecarNotifiers#labelValue
     */
    readonly labelValue?: string;
    /**
     * @schema GrafanaSidecarNotifiers#reloadURL
     */
    readonly reloadUrl?: string;
    /**
     * @schema GrafanaSidecarNotifiers#resource
     */
    readonly resource?: string;
    /**
     * @schema GrafanaSidecarNotifiers#resourceName
     */
    readonly resourceName?: string;
    /**
     * @schema GrafanaSidecarNotifiers#script
     */
    readonly script?: string;
    /**
     * @schema GrafanaSidecarNotifiers#searchNamespace
     */
    readonly searchNamespace?: any;
    /**
     * @schema GrafanaSidecarNotifiers#sizeLimit
     */
    readonly sizeLimit?: any;
    /**
     * @schema GrafanaSidecarNotifiers#skipReload
     */
    readonly skipReload?: boolean;
    /**
     * @schema GrafanaSidecarNotifiers#watchMethod
     */
    readonly watchMethod?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSidecarNotifiers#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSidecarNotifiers' to JSON representation.
 */
export declare function toJson_GrafanaSidecarNotifiers(obj: GrafanaSidecarNotifiers | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSidecarPlugins
 */
export interface GrafanaSidecarPlugins {
    /**
     * @schema GrafanaSidecarPlugins#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema GrafanaSidecarPlugins#env
     */
    readonly env?: any;
    /**
     * @schema GrafanaSidecarPlugins#extraMounts
     */
    readonly extraMounts?: any[];
    /**
     * @schema GrafanaSidecarPlugins#initPlugins
     */
    readonly initPlugins?: boolean;
    /**
     * @schema GrafanaSidecarPlugins#label
     */
    readonly label?: string;
    /**
     * @schema GrafanaSidecarPlugins#labelValue
     */
    readonly labelValue?: string;
    /**
     * @schema GrafanaSidecarPlugins#reloadURL
     */
    readonly reloadUrl?: string;
    /**
     * @schema GrafanaSidecarPlugins#resource
     */
    readonly resource?: string;
    /**
     * @schema GrafanaSidecarPlugins#resourceName
     */
    readonly resourceName?: string;
    /**
     * @schema GrafanaSidecarPlugins#script
     */
    readonly script?: string;
    /**
     * @schema GrafanaSidecarPlugins#searchNamespace
     */
    readonly searchNamespace?: any;
    /**
     * @schema GrafanaSidecarPlugins#sizeLimit
     */
    readonly sizeLimit?: any;
    /**
     * @schema GrafanaSidecarPlugins#skipReload
     */
    readonly skipReload?: boolean;
    /**
     * @schema GrafanaSidecarPlugins#watchMethod
     */
    readonly watchMethod?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSidecarPlugins#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSidecarPlugins' to JSON representation.
 */
export declare function toJson_GrafanaSidecarPlugins(obj: GrafanaSidecarPlugins | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaTestFrameworkImage
 */
export interface GrafanaTestFrameworkImage {
    /**
     * The Docker registry
     *
     * @schema GrafanaTestFrameworkImage#registry
     */
    readonly registry?: string;
    /**
     * @schema GrafanaTestFrameworkImage#repository
     */
    readonly repository?: string;
    /**
     * @schema GrafanaTestFrameworkImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaTestFrameworkImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaTestFrameworkImage' to JSON representation.
 */
export declare function toJson_GrafanaTestFrameworkImage(obj: GrafanaTestFrameworkImage | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaVerticalPodAutoscalerControlledResources
 */
export interface GrafanaVerticalPodAutoscalerControlledResources {
    /**
     * @schema GrafanaVerticalPodAutoscalerControlledResources#cpu
     */
    readonly cpu?: boolean;
    /**
     * @schema GrafanaVerticalPodAutoscalerControlledResources#memory
     */
    readonly memory?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaVerticalPodAutoscalerControlledResources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaVerticalPodAutoscalerControlledResources' to JSON representation.
 */
export declare function toJson_GrafanaVerticalPodAutoscalerControlledResources(obj: GrafanaVerticalPodAutoscalerControlledResources | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaRouteMainMatches
 */
export interface GrafanaRouteMainMatches {
    /**
     * @schema GrafanaRouteMainMatches#path
     */
    readonly path?: GrafanaRouteMainMatchesPath;
}
/**
 * Converts an object of type 'GrafanaRouteMainMatches' to JSON representation.
 */
export declare function toJson_GrafanaRouteMainMatches(obj: GrafanaRouteMainMatches | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaSidecarDashboardsProvider
 */
export interface GrafanaSidecarDashboardsProvider {
    /**
     * @schema GrafanaSidecarDashboardsProvider#allowUiUpdates
     */
    readonly allowUiUpdates?: boolean;
    /**
     * @schema GrafanaSidecarDashboardsProvider#disableDelete
     */
    readonly disableDelete?: boolean;
    /**
     * @schema GrafanaSidecarDashboardsProvider#folder
     */
    readonly folder?: string;
    /**
     * @schema GrafanaSidecarDashboardsProvider#folderUid
     */
    readonly folderUid?: string;
    /**
     * @schema GrafanaSidecarDashboardsProvider#foldersFromFilesStructure
     */
    readonly foldersFromFilesStructure?: boolean;
    /**
     * @schema GrafanaSidecarDashboardsProvider#name
     */
    readonly name?: string;
    /**
     * @schema GrafanaSidecarDashboardsProvider#orgid
     */
    readonly orgid?: any;
    /**
     * @schema GrafanaSidecarDashboardsProvider#type
     */
    readonly type?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema GrafanaSidecarDashboardsProvider#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'GrafanaSidecarDashboardsProvider' to JSON representation.
 */
export declare function toJson_GrafanaSidecarDashboardsProvider(obj: GrafanaSidecarDashboardsProvider | undefined): Record<string, any> | undefined;
/**
 * @schema GrafanaRouteMainMatchesPath
 */
export interface GrafanaRouteMainMatchesPath {
    /**
     * @schema GrafanaRouteMainMatchesPath#type
     */
    readonly type?: string;
    /**
     * @schema GrafanaRouteMainMatchesPath#value
     */
    readonly value?: string;
}
/**
 * Converts an object of type 'GrafanaRouteMainMatchesPath' to JSON representation.
 */
export declare function toJson_GrafanaRouteMainMatchesPath(obj: GrafanaRouteMainMatchesPath | undefined): Record<string, any> | undefined;
