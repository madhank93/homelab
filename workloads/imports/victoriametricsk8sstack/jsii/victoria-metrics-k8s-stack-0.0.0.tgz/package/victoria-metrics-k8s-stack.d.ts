import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface Victoriametricsk8sstackProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values?: {
        [key: string]: any;
    };
}
export declare class Victoriametricsk8sstack extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props?: Victoriametricsk8sstackProps);
    private flattenAdditionalValues;
}
