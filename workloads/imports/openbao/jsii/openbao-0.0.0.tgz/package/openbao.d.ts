import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface OpenbaoProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values?: OpenbaoValues;
}
export declare class Openbao extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props?: OpenbaoProps);
    private flattenAdditionalValues;
}
/**
 * @schema openbao
 */
export interface OpenbaoValues {
    /**
     * @schema openbao#csi
     */
    readonly csi?: OpenbaoCsi;
    /**
     * @schema openbao#global
     */
    readonly global?: {
        [key: string]: any;
    };
    /**
     * @schema openbao#injector
     */
    readonly injector?: OpenbaoInjector;
    /**
     * @schema openbao#server
     */
    readonly server?: OpenbaoServer;
    /**
     * @schema openbao#serverTelemetry
     */
    readonly serverTelemetry?: OpenbaoServerTelemetry;
    /**
     * @schema openbao#ui
     */
    readonly ui?: OpenbaoUi;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema openbao#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoValues' to JSON representation.
 */
export declare function toJson_OpenbaoValues(obj: OpenbaoValues | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsi
 */
export interface OpenbaoCsi {
    /**
     * @schema OpenbaoCsi#agent
     */
    readonly agent?: OpenbaoCsiAgent;
    /**
     * @schema OpenbaoCsi#daemonSet
     */
    readonly daemonSet?: OpenbaoCsiDaemonSet;
    /**
     * @schema OpenbaoCsi#debug
     */
    readonly debug?: boolean;
    /**
     * @schema OpenbaoCsi#enabled
     */
    readonly enabled?: any;
    /**
     * @schema OpenbaoCsi#extraArgs
     */
    readonly extraArgs?: any[];
    /**
     * @schema OpenbaoCsi#image
     */
    readonly image?: OpenbaoCsiImage;
    /**
     * @schema OpenbaoCsi#livenessProbe
     */
    readonly livenessProbe?: OpenbaoCsiLivenessProbe;
    /**
     * @schema OpenbaoCsi#pod
     */
    readonly pod?: OpenbaoCsiPod;
    /**
     * @schema OpenbaoCsi#priorityClassName
     */
    readonly priorityClassName?: string;
    /**
     * @schema OpenbaoCsi#readinessProbe
     */
    readonly readinessProbe?: OpenbaoCsiReadinessProbe;
    /**
     * @schema OpenbaoCsi#resources
     */
    readonly resources?: any;
    /**
     * @schema OpenbaoCsi#serviceAccount
     */
    readonly serviceAccount?: OpenbaoCsiServiceAccount;
    /**
     * @schema OpenbaoCsi#volumeMounts
     */
    readonly volumeMounts?: any[];
    /**
     * @schema OpenbaoCsi#volumes
     */
    readonly volumes?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsi#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsi' to JSON representation.
 */
export declare function toJson_OpenbaoCsi(obj: OpenbaoCsi | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjector
 */
export interface OpenbaoInjector {
    /**
     * @schema OpenbaoInjector#affinity
     */
    readonly affinity?: any;
    /**
     * @schema OpenbaoInjector#agentDefaults
     */
    readonly agentDefaults?: OpenbaoInjectorAgentDefaults;
    /**
     * @schema OpenbaoInjector#agentImage
     */
    readonly agentImage?: OpenbaoInjectorAgentImage;
    /**
     * @schema OpenbaoInjector#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoInjector#authPath
     */
    readonly authPath?: string;
    /**
     * @schema OpenbaoInjector#certs
     */
    readonly certs?: OpenbaoInjectorCerts;
    /**
     * @schema OpenbaoInjector#enabled
     */
    readonly enabled?: any;
    /**
     * @schema OpenbaoInjector#externalVaultAddr
     */
    readonly externalVaultAddr?: string;
    /**
     * @schema OpenbaoInjector#extraEnvironmentVars
     */
    readonly extraEnvironmentVars?: any;
    /**
     * @schema OpenbaoInjector#extraLabels
     */
    readonly extraLabels?: any;
    /**
     * @schema OpenbaoInjector#failurePolicy
     */
    readonly failurePolicy?: string;
    /**
     * @schema OpenbaoInjector#hostNetwork
     */
    readonly hostNetwork?: boolean;
    /**
     * @schema OpenbaoInjector#image
     */
    readonly image?: OpenbaoInjectorImage;
    /**
     * @schema OpenbaoInjector#leaderElector
     */
    readonly leaderElector?: OpenbaoInjectorLeaderElector;
    /**
     * @schema OpenbaoInjector#logFormat
     */
    readonly logFormat?: string;
    /**
     * @schema OpenbaoInjector#logLevel
     */
    readonly logLevel?: string;
    /**
     * @schema OpenbaoInjector#metrics
     */
    readonly metrics?: OpenbaoInjectorMetrics;
    /**
     * @schema OpenbaoInjector#namespaceSelector
     */
    readonly namespaceSelector?: any;
    /**
     * @schema OpenbaoInjector#nodeSelector
     */
    readonly nodeSelector?: any;
    /**
     * @schema OpenbaoInjector#objectSelector
     */
    readonly objectSelector?: any;
    /**
     * @schema OpenbaoInjector#podDisruptionBudget
     */
    readonly podDisruptionBudget?: any;
    /**
     * @schema OpenbaoInjector#port
     */
    readonly port?: number;
    /**
     * @schema OpenbaoInjector#priorityClassName
     */
    readonly priorityClassName?: string;
    /**
     * @schema OpenbaoInjector#replicas
     */
    readonly replicas?: number;
    /**
     * @schema OpenbaoInjector#resources
     */
    readonly resources?: any;
    /**
     * @schema OpenbaoInjector#revokeOnShutdown
     */
    readonly revokeOnShutdown?: boolean;
    /**
     * @schema OpenbaoInjector#securityContext
     */
    readonly securityContext?: OpenbaoInjectorSecurityContext;
    /**
     * @schema OpenbaoInjector#service
     */
    readonly service?: OpenbaoInjectorService;
    /**
     * @schema OpenbaoInjector#serviceAccount
     */
    readonly serviceAccount?: OpenbaoInjectorServiceAccount;
    /**
     * @schema OpenbaoInjector#strategy
     */
    readonly strategy?: any;
    /**
     * @schema OpenbaoInjector#tolerations
     */
    readonly tolerations?: any;
    /**
     * @schema OpenbaoInjector#topologySpreadConstraints
     */
    readonly topologySpreadConstraints?: any;
    /**
     * @schema OpenbaoInjector#webhook
     */
    readonly webhook?: OpenbaoInjectorWebhook;
    /**
     * @schema OpenbaoInjector#webhookAnnotations
     */
    readonly webhookAnnotations?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjector#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjector' to JSON representation.
 */
export declare function toJson_OpenbaoInjector(obj: OpenbaoInjector | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServer
 */
export interface OpenbaoServer {
    /**
     * @schema OpenbaoServer#affinity
     */
    readonly affinity?: any;
    /**
     * @schema OpenbaoServer#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoServer#auditStorage
     */
    readonly auditStorage?: OpenbaoServerAuditStorage;
    /**
     * @schema OpenbaoServer#authDelegator
     */
    readonly authDelegator?: OpenbaoServerAuthDelegator;
    /**
     * @schema OpenbaoServer#dataStorage
     */
    readonly dataStorage?: OpenbaoServerDataStorage;
    /**
     * @schema OpenbaoServer#persistentVolumeClaimRetentionPolicy
     */
    readonly persistentVolumeClaimRetentionPolicy?: OpenbaoServerPersistentVolumeClaimRetentionPolicy;
    /**
     * @schema OpenbaoServer#dev
     */
    readonly dev?: OpenbaoServerDev;
    /**
     * @schema OpenbaoServer#enabled
     */
    readonly enabled?: any;
    /**
     * @schema OpenbaoServer#extraArgs
     */
    readonly extraArgs?: string;
    /**
     * @schema OpenbaoServer#extraPorts
     */
    readonly extraPorts?: any[];
    /**
     * @schema OpenbaoServer#extraContainers
     */
    readonly extraContainers?: any[];
    /**
     * @schema OpenbaoServer#extraEnvironmentVars
     */
    readonly extraEnvironmentVars?: any;
    /**
     * @schema OpenbaoServer#extraInitContainers
     */
    readonly extraInitContainers?: any[];
    /**
     * @schema OpenbaoServer#extraLabels
     */
    readonly extraLabels?: any;
    /**
     * @schema OpenbaoServer#extraSecretEnvironmentVars
     */
    readonly extraSecretEnvironmentVars?: any[];
    /**
     * @schema OpenbaoServer#extraVolumes
     */
    readonly extraVolumes?: any[];
    /**
     * @schema OpenbaoServer#ha
     */
    readonly ha?: OpenbaoServerHa;
    /**
     * @schema OpenbaoServer#hostAliases
     */
    readonly hostAliases?: any[];
    /**
     * @schema OpenbaoServer#image
     */
    readonly image?: OpenbaoServerImage;
    /**
     * @schema OpenbaoServer#ingress
     */
    readonly ingress?: OpenbaoServerIngress;
    /**
     * @schema OpenbaoServer#livenessProbe
     */
    readonly livenessProbe?: OpenbaoServerLivenessProbe;
    /**
     * @schema OpenbaoServer#logFormat
     */
    readonly logFormat?: string;
    /**
     * @schema OpenbaoServer#logLevel
     */
    readonly logLevel?: string;
    /**
     * @schema OpenbaoServer#networkPolicy
     */
    readonly networkPolicy?: OpenbaoServerNetworkPolicy;
    /**
     * @schema OpenbaoServer#nodeSelector
     */
    readonly nodeSelector?: any;
    /**
     * @schema OpenbaoServer#postStart
     */
    readonly postStart?: any[];
    /**
     * @schema OpenbaoServer#preStopSleepSeconds
     */
    readonly preStopSleepSeconds?: number;
    /**
     * @schema OpenbaoServer#priorityClassName
     */
    readonly priorityClassName?: string;
    /**
     * @schema OpenbaoServer#readinessProbe
     */
    readonly readinessProbe?: OpenbaoServerReadinessProbe;
    /**
     * @schema OpenbaoServer#resources
     */
    readonly resources?: any;
    /**
     * @schema OpenbaoServer#route
     */
    readonly route?: OpenbaoServerRoute;
    /**
     * @schema OpenbaoServer#service
     */
    readonly service?: OpenbaoServerService;
    /**
     * @schema OpenbaoServer#serviceAccount
     */
    readonly serviceAccount?: OpenbaoServerServiceAccount;
    /**
     * @schema OpenbaoServer#shareProcessNamespace
     */
    readonly shareProcessNamespace?: boolean;
    /**
     * @schema OpenbaoServer#standalone
     */
    readonly standalone?: OpenbaoServerStandalone;
    /**
     * @schema OpenbaoServer#statefulSet
     */
    readonly statefulSet?: OpenbaoServerStatefulSet;
    /**
     * @schema OpenbaoServer#terminationGracePeriodSeconds
     */
    readonly terminationGracePeriodSeconds?: number;
    /**
     * @schema OpenbaoServer#tolerations
     */
    readonly tolerations?: any;
    /**
     * @schema OpenbaoServer#topologySpreadConstraints
     */
    readonly topologySpreadConstraints?: any;
    /**
     * @schema OpenbaoServer#updateStrategyType
     */
    readonly updateStrategyType?: string;
    /**
     * @schema OpenbaoServer#volumeMounts
     */
    readonly volumeMounts?: any[];
    /**
     * @schema OpenbaoServer#volumes
     */
    readonly volumes?: any[];
    /**
     * @schema OpenbaoServer#hostNetwork
     */
    readonly hostNetwork?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServer#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServer' to JSON representation.
 */
export declare function toJson_OpenbaoServer(obj: OpenbaoServer | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerTelemetry
 */
export interface OpenbaoServerTelemetry {
    /**
     * @schema OpenbaoServerTelemetry#prometheusRules
     */
    readonly prometheusRules?: OpenbaoServerTelemetryPrometheusRules;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerTelemetry#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerTelemetry' to JSON representation.
 */
export declare function toJson_OpenbaoServerTelemetry(obj: OpenbaoServerTelemetry | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoUi
 */
export interface OpenbaoUi {
    /**
     * @schema OpenbaoUi#activeOpenbaoPodOnly
     */
    readonly activeOpenbaoPodOnly?: boolean;
    /**
     * @schema OpenbaoUi#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoUi#enabled
     */
    readonly enabled?: any;
    /**
     * @schema OpenbaoUi#externalPort
     */
    readonly externalPort?: number;
    /**
     * @schema OpenbaoUi#externalTrafficPolicy
     */
    readonly externalTrafficPolicy?: string;
    /**
     * @schema OpenbaoUi#publishNotReadyAddresses
     */
    readonly publishNotReadyAddresses?: boolean;
    /**
     * @schema OpenbaoUi#serviceNodePort
     */
    readonly serviceNodePort?: number;
    /**
     * @schema OpenbaoUi#serviceType
     */
    readonly serviceType?: string;
    /**
     * @schema OpenbaoUi#targetPort
     */
    readonly targetPort?: number;
    /**
     * @schema OpenbaoUi#serviceIPFamilyPolicy
     */
    readonly serviceIpFamilyPolicy?: string;
    /**
     * @schema OpenbaoUi#serviceIPFamilies
     */
    readonly serviceIpFamilies?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoUi#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoUi' to JSON representation.
 */
export declare function toJson_OpenbaoUi(obj: OpenbaoUi | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiAgent
 */
export interface OpenbaoCsiAgent {
    /**
     * @schema OpenbaoCsiAgent#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoCsiAgent#extraArgs
     */
    readonly extraArgs?: any[];
    /**
     * @schema OpenbaoCsiAgent#image
     */
    readonly image?: OpenbaoCsiAgentImage;
    /**
     * @schema OpenbaoCsiAgent#logFormat
     */
    readonly logFormat?: string;
    /**
     * @schema OpenbaoCsiAgent#logLevel
     */
    readonly logLevel?: string;
    /**
     * @schema OpenbaoCsiAgent#resources
     */
    readonly resources?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiAgent#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiAgent' to JSON representation.
 */
export declare function toJson_OpenbaoCsiAgent(obj: OpenbaoCsiAgent | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiDaemonSet
 */
export interface OpenbaoCsiDaemonSet {
    /**
     * @schema OpenbaoCsiDaemonSet#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoCsiDaemonSet#extraLabels
     */
    readonly extraLabels?: any;
    /**
     * @schema OpenbaoCsiDaemonSet#kubeletRootDir
     */
    readonly kubeletRootDir?: string;
    /**
     * @schema OpenbaoCsiDaemonSet#providersDir
     */
    readonly providersDir?: string;
    /**
     * @schema OpenbaoCsiDaemonSet#securityContext
     */
    readonly securityContext?: OpenbaoCsiDaemonSetSecurityContext;
    /**
     * @schema OpenbaoCsiDaemonSet#updateStrategy
     */
    readonly updateStrategy?: OpenbaoCsiDaemonSetUpdateStrategy;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiDaemonSet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiDaemonSet' to JSON representation.
 */
export declare function toJson_OpenbaoCsiDaemonSet(obj: OpenbaoCsiDaemonSet | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiImage
 */
export interface OpenbaoCsiImage {
    /**
     * @schema OpenbaoCsiImage#pullPolicy
     */
    readonly pullPolicy?: string;
    /**
     * @schema OpenbaoCsiImage#repository
     */
    readonly repository?: string;
    /**
     * @schema OpenbaoCsiImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiImage' to JSON representation.
 */
export declare function toJson_OpenbaoCsiImage(obj: OpenbaoCsiImage | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiLivenessProbe
 */
export interface OpenbaoCsiLivenessProbe {
    /**
     * @schema OpenbaoCsiLivenessProbe#failureThreshold
     */
    readonly failureThreshold?: number;
    /**
     * @schema OpenbaoCsiLivenessProbe#initialDelaySeconds
     */
    readonly initialDelaySeconds?: number;
    /**
     * @schema OpenbaoCsiLivenessProbe#periodSeconds
     */
    readonly periodSeconds?: number;
    /**
     * @schema OpenbaoCsiLivenessProbe#successThreshold
     */
    readonly successThreshold?: number;
    /**
     * @schema OpenbaoCsiLivenessProbe#timeoutSeconds
     */
    readonly timeoutSeconds?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiLivenessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiLivenessProbe' to JSON representation.
 */
export declare function toJson_OpenbaoCsiLivenessProbe(obj: OpenbaoCsiLivenessProbe | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiPod
 */
export interface OpenbaoCsiPod {
    /**
     * @schema OpenbaoCsiPod#affinity
     */
    readonly affinity?: any;
    /**
     * @schema OpenbaoCsiPod#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoCsiPod#extraLabels
     */
    readonly extraLabels?: any;
    /**
     * @schema OpenbaoCsiPod#nodeSelector
     */
    readonly nodeSelector?: any;
    /**
     * @schema OpenbaoCsiPod#tolerations
     */
    readonly tolerations?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiPod#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiPod' to JSON representation.
 */
export declare function toJson_OpenbaoCsiPod(obj: OpenbaoCsiPod | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiReadinessProbe
 */
export interface OpenbaoCsiReadinessProbe {
    /**
     * @schema OpenbaoCsiReadinessProbe#failureThreshold
     */
    readonly failureThreshold?: number;
    /**
     * @schema OpenbaoCsiReadinessProbe#initialDelaySeconds
     */
    readonly initialDelaySeconds?: number;
    /**
     * @schema OpenbaoCsiReadinessProbe#periodSeconds
     */
    readonly periodSeconds?: number;
    /**
     * @schema OpenbaoCsiReadinessProbe#successThreshold
     */
    readonly successThreshold?: number;
    /**
     * @schema OpenbaoCsiReadinessProbe#timeoutSeconds
     */
    readonly timeoutSeconds?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiReadinessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiReadinessProbe' to JSON representation.
 */
export declare function toJson_OpenbaoCsiReadinessProbe(obj: OpenbaoCsiReadinessProbe | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiServiceAccount
 */
export interface OpenbaoCsiServiceAccount {
    /**
     * @schema OpenbaoCsiServiceAccount#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoCsiServiceAccount#extraLabels
     */
    readonly extraLabels?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiServiceAccount#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiServiceAccount' to JSON representation.
 */
export declare function toJson_OpenbaoCsiServiceAccount(obj: OpenbaoCsiServiceAccount | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorAgentDefaults
 */
export interface OpenbaoInjectorAgentDefaults {
    /**
     * @schema OpenbaoInjectorAgentDefaults#cpuLimit
     */
    readonly cpuLimit?: string;
    /**
     * @schema OpenbaoInjectorAgentDefaults#cpuRequest
     */
    readonly cpuRequest?: string;
    /**
     * @schema OpenbaoInjectorAgentDefaults#memLimit
     */
    readonly memLimit?: string;
    /**
     * @schema OpenbaoInjectorAgentDefaults#memRequest
     */
    readonly memRequest?: string;
    /**
     * @schema OpenbaoInjectorAgentDefaults#ephemeralLimit
     */
    readonly ephemeralLimit?: string;
    /**
     * @schema OpenbaoInjectorAgentDefaults#ephemeralRequest
     */
    readonly ephemeralRequest?: string;
    /**
     * @schema OpenbaoInjectorAgentDefaults#template
     */
    readonly template?: string;
    /**
     * @schema OpenbaoInjectorAgentDefaults#templateConfig
     */
    readonly templateConfig?: OpenbaoInjectorAgentDefaultsTemplateConfig;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorAgentDefaults#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorAgentDefaults' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorAgentDefaults(obj: OpenbaoInjectorAgentDefaults | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorAgentImage
 */
export interface OpenbaoInjectorAgentImage {
    /**
     * @schema OpenbaoInjectorAgentImage#repository
     */
    readonly repository?: string;
    /**
     * @schema OpenbaoInjectorAgentImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorAgentImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorAgentImage' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorAgentImage(obj: OpenbaoInjectorAgentImage | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorCerts
 */
export interface OpenbaoInjectorCerts {
    /**
     * @schema OpenbaoInjectorCerts#caBundle
     */
    readonly caBundle?: string;
    /**
     * @schema OpenbaoInjectorCerts#certName
     */
    readonly certName?: string;
    /**
     * @schema OpenbaoInjectorCerts#keyName
     */
    readonly keyName?: string;
    /**
     * @schema OpenbaoInjectorCerts#secretName
     */
    readonly secretName?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorCerts#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorCerts' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorCerts(obj: OpenbaoInjectorCerts | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorImage
 */
export interface OpenbaoInjectorImage {
    /**
     * @schema OpenbaoInjectorImage#pullPolicy
     */
    readonly pullPolicy?: string;
    /**
     * @schema OpenbaoInjectorImage#repository
     */
    readonly repository?: string;
    /**
     * @schema OpenbaoInjectorImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorImage' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorImage(obj: OpenbaoInjectorImage | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorLeaderElector
 */
export interface OpenbaoInjectorLeaderElector {
    /**
     * @schema OpenbaoInjectorLeaderElector#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorLeaderElector#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorLeaderElector' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorLeaderElector(obj: OpenbaoInjectorLeaderElector | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorMetrics
 */
export interface OpenbaoInjectorMetrics {
    /**
     * @schema OpenbaoInjectorMetrics#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorMetrics#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorMetrics' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorMetrics(obj: OpenbaoInjectorMetrics | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorSecurityContext
 */
export interface OpenbaoInjectorSecurityContext {
    /**
     * @schema OpenbaoInjectorSecurityContext#container
     */
    readonly container?: any;
    /**
     * @schema OpenbaoInjectorSecurityContext#pod
     */
    readonly pod?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorSecurityContext#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorSecurityContext' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorSecurityContext(obj: OpenbaoInjectorSecurityContext | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorService
 */
export interface OpenbaoInjectorService {
    /**
     * @schema OpenbaoInjectorService#annotations
     */
    readonly annotations?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorService#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorService' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorService(obj: OpenbaoInjectorService | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorServiceAccount
 */
export interface OpenbaoInjectorServiceAccount {
    /**
     * @schema OpenbaoInjectorServiceAccount#annotations
     */
    readonly annotations?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorServiceAccount#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorServiceAccount' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorServiceAccount(obj: OpenbaoInjectorServiceAccount | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorWebhook
 */
export interface OpenbaoInjectorWebhook {
    /**
     * @schema OpenbaoInjectorWebhook#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoInjectorWebhook#failurePolicy
     */
    readonly failurePolicy?: string;
    /**
     * @schema OpenbaoInjectorWebhook#matchPolicy
     */
    readonly matchPolicy?: string;
    /**
     * @schema OpenbaoInjectorWebhook#namespaceSelector
     */
    readonly namespaceSelector?: any;
    /**
     * @schema OpenbaoInjectorWebhook#objectSelector
     */
    readonly objectSelector?: any;
    /**
     * @schema OpenbaoInjectorWebhook#timeoutSeconds
     */
    readonly timeoutSeconds?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorWebhook#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorWebhook' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorWebhook(obj: OpenbaoInjectorWebhook | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerAuditStorage
 */
export interface OpenbaoServerAuditStorage {
    /**
     * @schema OpenbaoServerAuditStorage#accessMode
     */
    readonly accessMode?: string;
    /**
     * @schema OpenbaoServerAuditStorage#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoServerAuditStorage#labels
     */
    readonly labels?: any;
    /**
     * @schema OpenbaoServerAuditStorage#enabled
     */
    readonly enabled?: any;
    /**
     * @schema OpenbaoServerAuditStorage#mountPath
     */
    readonly mountPath?: string;
    /**
     * @schema OpenbaoServerAuditStorage#size
     */
    readonly size?: string;
    /**
     * @schema OpenbaoServerAuditStorage#storageClass
     */
    readonly storageClass?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerAuditStorage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerAuditStorage' to JSON representation.
 */
export declare function toJson_OpenbaoServerAuditStorage(obj: OpenbaoServerAuditStorage | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerAuthDelegator
 */
export interface OpenbaoServerAuthDelegator {
    /**
     * @schema OpenbaoServerAuthDelegator#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerAuthDelegator#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerAuthDelegator' to JSON representation.
 */
export declare function toJson_OpenbaoServerAuthDelegator(obj: OpenbaoServerAuthDelegator | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerDataStorage
 */
export interface OpenbaoServerDataStorage {
    /**
     * @schema OpenbaoServerDataStorage#accessMode
     */
    readonly accessMode?: string;
    /**
     * @schema OpenbaoServerDataStorage#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoServerDataStorage#labels
     */
    readonly labels?: any;
    /**
     * @schema OpenbaoServerDataStorage#enabled
     */
    readonly enabled?: any;
    /**
     * @schema OpenbaoServerDataStorage#mountPath
     */
    readonly mountPath?: string;
    /**
     * @schema OpenbaoServerDataStorage#size
     */
    readonly size?: string;
    /**
     * @schema OpenbaoServerDataStorage#storageClass
     */
    readonly storageClass?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerDataStorage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerDataStorage' to JSON representation.
 */
export declare function toJson_OpenbaoServerDataStorage(obj: OpenbaoServerDataStorage | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerPersistentVolumeClaimRetentionPolicy
 */
export interface OpenbaoServerPersistentVolumeClaimRetentionPolicy {
    /**
     * @schema OpenbaoServerPersistentVolumeClaimRetentionPolicy#whenDeleted
     */
    readonly whenDeleted?: string;
    /**
     * @schema OpenbaoServerPersistentVolumeClaimRetentionPolicy#whenScaled
     */
    readonly whenScaled?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerPersistentVolumeClaimRetentionPolicy#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerPersistentVolumeClaimRetentionPolicy' to JSON representation.
 */
export declare function toJson_OpenbaoServerPersistentVolumeClaimRetentionPolicy(obj: OpenbaoServerPersistentVolumeClaimRetentionPolicy | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerDev
 */
export interface OpenbaoServerDev {
    /**
     * @schema OpenbaoServerDev#devRootToken
     */
    readonly devRootToken?: string;
    /**
     * @schema OpenbaoServerDev#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerDev#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerDev' to JSON representation.
 */
export declare function toJson_OpenbaoServerDev(obj: OpenbaoServerDev | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerHa
 */
export interface OpenbaoServerHa {
    /**
     * @schema OpenbaoServerHa#apiAddr
     */
    readonly apiAddr?: string;
    /**
     * @schema OpenbaoServerHa#clusterAddr
     */
    readonly clusterAddr?: string;
    /**
     * @schema OpenbaoServerHa#config
     */
    readonly config?: any;
    /**
     * @schema OpenbaoServerHa#disruptionBudget
     */
    readonly disruptionBudget?: OpenbaoServerHaDisruptionBudget;
    /**
     * @schema OpenbaoServerHa#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerHa#raft
     */
    readonly raft?: OpenbaoServerHaRaft;
    /**
     * @schema OpenbaoServerHa#replicas
     */
    readonly replicas?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerHa#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerHa' to JSON representation.
 */
export declare function toJson_OpenbaoServerHa(obj: OpenbaoServerHa | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerImage
 */
export interface OpenbaoServerImage {
    /**
     * @schema OpenbaoServerImage#pullPolicy
     */
    readonly pullPolicy?: string;
    /**
     * @schema OpenbaoServerImage#repository
     */
    readonly repository?: string;
    /**
     * @schema OpenbaoServerImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerImage' to JSON representation.
 */
export declare function toJson_OpenbaoServerImage(obj: OpenbaoServerImage | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerIngress
 */
export interface OpenbaoServerIngress {
    /**
     * @schema OpenbaoServerIngress#activeService
     */
    readonly activeService?: boolean;
    /**
     * @schema OpenbaoServerIngress#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoServerIngress#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerIngress#extraPaths
     */
    readonly extraPaths?: any[];
    /**
     * @schema OpenbaoServerIngress#hosts
     */
    readonly hosts?: OpenbaoServerIngressHosts[];
    /**
     * @schema OpenbaoServerIngress#ingressClassName
     */
    readonly ingressClassName?: string;
    /**
     * @schema OpenbaoServerIngress#labels
     */
    readonly labels?: any;
    /**
     * @schema OpenbaoServerIngress#pathType
     */
    readonly pathType?: string;
    /**
     * @schema OpenbaoServerIngress#tls
     */
    readonly tls?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerIngress#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerIngress' to JSON representation.
 */
export declare function toJson_OpenbaoServerIngress(obj: OpenbaoServerIngress | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerLivenessProbe
 */
export interface OpenbaoServerLivenessProbe {
    /**
     * @schema OpenbaoServerLivenessProbe#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerLivenessProbe#failureThreshold
     */
    readonly failureThreshold?: number;
    /**
     * @schema OpenbaoServerLivenessProbe#initialDelaySeconds
     */
    readonly initialDelaySeconds?: number;
    /**
     * @schema OpenbaoServerLivenessProbe#path
     */
    readonly path?: string;
    /**
     * @schema OpenbaoServerLivenessProbe#port
     */
    readonly port?: number;
    /**
     * @schema OpenbaoServerLivenessProbe#execCommand
     */
    readonly execCommand?: any[];
    /**
     * @schema OpenbaoServerLivenessProbe#periodSeconds
     */
    readonly periodSeconds?: number;
    /**
     * @schema OpenbaoServerLivenessProbe#successThreshold
     */
    readonly successThreshold?: number;
    /**
     * @schema OpenbaoServerLivenessProbe#timeoutSeconds
     */
    readonly timeoutSeconds?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerLivenessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerLivenessProbe' to JSON representation.
 */
export declare function toJson_OpenbaoServerLivenessProbe(obj: OpenbaoServerLivenessProbe | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerNetworkPolicy
 */
export interface OpenbaoServerNetworkPolicy {
    /**
     * @schema OpenbaoServerNetworkPolicy#egress
     */
    readonly egress?: any[];
    /**
     * @schema OpenbaoServerNetworkPolicy#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerNetworkPolicy#ingress
     */
    readonly ingress?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerNetworkPolicy#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerNetworkPolicy' to JSON representation.
 */
export declare function toJson_OpenbaoServerNetworkPolicy(obj: OpenbaoServerNetworkPolicy | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerReadinessProbe
 */
export interface OpenbaoServerReadinessProbe {
    /**
     * @schema OpenbaoServerReadinessProbe#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerReadinessProbe#failureThreshold
     */
    readonly failureThreshold?: number;
    /**
     * @schema OpenbaoServerReadinessProbe#initialDelaySeconds
     */
    readonly initialDelaySeconds?: number;
    /**
     * @schema OpenbaoServerReadinessProbe#periodSeconds
     */
    readonly periodSeconds?: number;
    /**
     * @schema OpenbaoServerReadinessProbe#successThreshold
     */
    readonly successThreshold?: number;
    /**
     * @schema OpenbaoServerReadinessProbe#timeoutSeconds
     */
    readonly timeoutSeconds?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerReadinessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerReadinessProbe' to JSON representation.
 */
export declare function toJson_OpenbaoServerReadinessProbe(obj: OpenbaoServerReadinessProbe | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerRoute
 */
export interface OpenbaoServerRoute {
    /**
     * @schema OpenbaoServerRoute#activeService
     */
    readonly activeService?: boolean;
    /**
     * @schema OpenbaoServerRoute#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoServerRoute#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerRoute#host
     */
    readonly host?: string;
    /**
     * @schema OpenbaoServerRoute#labels
     */
    readonly labels?: any;
    /**
     * @schema OpenbaoServerRoute#tls
     */
    readonly tls?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerRoute#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerRoute' to JSON representation.
 */
export declare function toJson_OpenbaoServerRoute(obj: OpenbaoServerRoute | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerService
 */
export interface OpenbaoServerService {
    /**
     * @schema OpenbaoServerService#active
     */
    readonly active?: OpenbaoServerServiceActive;
    /**
     * @schema OpenbaoServerService#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoServerService#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerService#externalTrafficPolicy
     */
    readonly externalTrafficPolicy?: string;
    /**
     * @schema OpenbaoServerService#instanceSelector
     */
    readonly instanceSelector?: OpenbaoServerServiceInstanceSelector;
    /**
     * @schema OpenbaoServerService#port
     */
    readonly port?: number;
    /**
     * @schema OpenbaoServerService#publishNotReadyAddresses
     */
    readonly publishNotReadyAddresses?: boolean;
    /**
     * @schema OpenbaoServerService#standby
     */
    readonly standby?: OpenbaoServerServiceStandby;
    /**
     * @schema OpenbaoServerService#targetPort
     */
    readonly targetPort?: number;
    /**
     * @schema OpenbaoServerService#nodePort
     */
    readonly nodePort?: number;
    /**
     * @schema OpenbaoServerService#activeNodePort
     */
    readonly activeNodePort?: number;
    /**
     * @schema OpenbaoServerService#standbyNodePort
     */
    readonly standbyNodePort?: number;
    /**
     * @schema OpenbaoServerService#ipFamilyPolicy
     */
    readonly ipFamilyPolicy?: string;
    /**
     * @schema OpenbaoServerService#ipFamilies
     */
    readonly ipFamilies?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerService#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerService' to JSON representation.
 */
export declare function toJson_OpenbaoServerService(obj: OpenbaoServerService | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerServiceAccount
 */
export interface OpenbaoServerServiceAccount {
    /**
     * @schema OpenbaoServerServiceAccount#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoServerServiceAccount#create
     */
    readonly create?: boolean;
    /**
     * @schema OpenbaoServerServiceAccount#extraLabels
     */
    readonly extraLabels?: any;
    /**
     * @schema OpenbaoServerServiceAccount#createSecret
     */
    readonly createSecret?: boolean;
    /**
     * @schema OpenbaoServerServiceAccount#name
     */
    readonly name?: string;
    /**
     * @schema OpenbaoServerServiceAccount#serviceDiscovery
     */
    readonly serviceDiscovery?: OpenbaoServerServiceAccountServiceDiscovery;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerServiceAccount#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerServiceAccount' to JSON representation.
 */
export declare function toJson_OpenbaoServerServiceAccount(obj: OpenbaoServerServiceAccount | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerStandalone
 */
export interface OpenbaoServerStandalone {
    /**
     * @schema OpenbaoServerStandalone#config
     */
    readonly config?: any;
    /**
     * @schema OpenbaoServerStandalone#enabled
     */
    readonly enabled?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerStandalone#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerStandalone' to JSON representation.
 */
export declare function toJson_OpenbaoServerStandalone(obj: OpenbaoServerStandalone | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerStatefulSet
 */
export interface OpenbaoServerStatefulSet {
    /**
     * @schema OpenbaoServerStatefulSet#annotations
     */
    readonly annotations?: any;
    /**
     * @schema OpenbaoServerStatefulSet#securityContext
     */
    readonly securityContext?: OpenbaoServerStatefulSetSecurityContext;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerStatefulSet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerStatefulSet' to JSON representation.
 */
export declare function toJson_OpenbaoServerStatefulSet(obj: OpenbaoServerStatefulSet | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerTelemetryPrometheusRules
 */
export interface OpenbaoServerTelemetryPrometheusRules {
    /**
     * @schema OpenbaoServerTelemetryPrometheusRules#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerTelemetryPrometheusRules#rules
     */
    readonly rules?: any[];
    /**
     * @schema OpenbaoServerTelemetryPrometheusRules#selectors
     */
    readonly selectors?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerTelemetryPrometheusRules#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerTelemetryPrometheusRules' to JSON representation.
 */
export declare function toJson_OpenbaoServerTelemetryPrometheusRules(obj: OpenbaoServerTelemetryPrometheusRules | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiAgentImage
 */
export interface OpenbaoCsiAgentImage {
    /**
     * @schema OpenbaoCsiAgentImage#pullPolicy
     */
    readonly pullPolicy?: string;
    /**
     * @schema OpenbaoCsiAgentImage#repository
     */
    readonly repository?: string;
    /**
     * @schema OpenbaoCsiAgentImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiAgentImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiAgentImage' to JSON representation.
 */
export declare function toJson_OpenbaoCsiAgentImage(obj: OpenbaoCsiAgentImage | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiDaemonSetSecurityContext
 */
export interface OpenbaoCsiDaemonSetSecurityContext {
    /**
     * @schema OpenbaoCsiDaemonSetSecurityContext#container
     */
    readonly container?: any;
    /**
     * @schema OpenbaoCsiDaemonSetSecurityContext#pod
     */
    readonly pod?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiDaemonSetSecurityContext#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiDaemonSetSecurityContext' to JSON representation.
 */
export declare function toJson_OpenbaoCsiDaemonSetSecurityContext(obj: OpenbaoCsiDaemonSetSecurityContext | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoCsiDaemonSetUpdateStrategy
 */
export interface OpenbaoCsiDaemonSetUpdateStrategy {
    /**
     * @schema OpenbaoCsiDaemonSetUpdateStrategy#maxUnavailable
     */
    readonly maxUnavailable?: string;
    /**
     * @schema OpenbaoCsiDaemonSetUpdateStrategy#type
     */
    readonly type?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoCsiDaemonSetUpdateStrategy#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoCsiDaemonSetUpdateStrategy' to JSON representation.
 */
export declare function toJson_OpenbaoCsiDaemonSetUpdateStrategy(obj: OpenbaoCsiDaemonSetUpdateStrategy | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoInjectorAgentDefaultsTemplateConfig
 */
export interface OpenbaoInjectorAgentDefaultsTemplateConfig {
    /**
     * @schema OpenbaoInjectorAgentDefaultsTemplateConfig#exitOnRetryFailure
     */
    readonly exitOnRetryFailure?: boolean;
    /**
     * @schema OpenbaoInjectorAgentDefaultsTemplateConfig#staticSecretRenderInterval
     */
    readonly staticSecretRenderInterval?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoInjectorAgentDefaultsTemplateConfig#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoInjectorAgentDefaultsTemplateConfig' to JSON representation.
 */
export declare function toJson_OpenbaoInjectorAgentDefaultsTemplateConfig(obj: OpenbaoInjectorAgentDefaultsTemplateConfig | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerHaDisruptionBudget
 */
export interface OpenbaoServerHaDisruptionBudget {
    /**
     * @schema OpenbaoServerHaDisruptionBudget#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerHaDisruptionBudget#maxUnavailable
     */
    readonly maxUnavailable?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerHaDisruptionBudget#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerHaDisruptionBudget' to JSON representation.
 */
export declare function toJson_OpenbaoServerHaDisruptionBudget(obj: OpenbaoServerHaDisruptionBudget | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerHaRaft
 */
export interface OpenbaoServerHaRaft {
    /**
     * @schema OpenbaoServerHaRaft#config
     */
    readonly config?: any;
    /**
     * @schema OpenbaoServerHaRaft#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerHaRaft#setNodeId
     */
    readonly setNodeId?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerHaRaft#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerHaRaft' to JSON representation.
 */
export declare function toJson_OpenbaoServerHaRaft(obj: OpenbaoServerHaRaft | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerIngressHosts
 */
export interface OpenbaoServerIngressHosts {
    /**
     * @schema OpenbaoServerIngressHosts#host
     */
    readonly host?: string;
    /**
     * @schema OpenbaoServerIngressHosts#paths
     */
    readonly paths?: any[];
}
/**
 * Converts an object of type 'OpenbaoServerIngressHosts' to JSON representation.
 */
export declare function toJson_OpenbaoServerIngressHosts(obj: OpenbaoServerIngressHosts | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerServiceActive
 */
export interface OpenbaoServerServiceActive {
    /**
     * @schema OpenbaoServerServiceActive#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerServiceActive#annotations
     */
    readonly annotations?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerServiceActive#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerServiceActive' to JSON representation.
 */
export declare function toJson_OpenbaoServerServiceActive(obj: OpenbaoServerServiceActive | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerServiceInstanceSelector
 */
export interface OpenbaoServerServiceInstanceSelector {
    /**
     * @schema OpenbaoServerServiceInstanceSelector#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerServiceInstanceSelector#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerServiceInstanceSelector' to JSON representation.
 */
export declare function toJson_OpenbaoServerServiceInstanceSelector(obj: OpenbaoServerServiceInstanceSelector | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerServiceStandby
 */
export interface OpenbaoServerServiceStandby {
    /**
     * @schema OpenbaoServerServiceStandby#enabled
     */
    readonly enabled?: boolean;
    /**
     * @schema OpenbaoServerServiceStandby#annotations
     */
    readonly annotations?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerServiceStandby#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerServiceStandby' to JSON representation.
 */
export declare function toJson_OpenbaoServerServiceStandby(obj: OpenbaoServerServiceStandby | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerServiceAccountServiceDiscovery
 */
export interface OpenbaoServerServiceAccountServiceDiscovery {
    /**
     * @schema OpenbaoServerServiceAccountServiceDiscovery#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerServiceAccountServiceDiscovery#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerServiceAccountServiceDiscovery' to JSON representation.
 */
export declare function toJson_OpenbaoServerServiceAccountServiceDiscovery(obj: OpenbaoServerServiceAccountServiceDiscovery | undefined): Record<string, any> | undefined;
/**
 * @schema OpenbaoServerStatefulSetSecurityContext
 */
export interface OpenbaoServerStatefulSetSecurityContext {
    /**
     * @schema OpenbaoServerStatefulSetSecurityContext#container
     */
    readonly container?: any;
    /**
     * @schema OpenbaoServerStatefulSetSecurityContext#pod
     */
    readonly pod?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema OpenbaoServerStatefulSetSecurityContext#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'OpenbaoServerStatefulSetSecurityContext' to JSON representation.
 */
export declare function toJson_OpenbaoServerStatefulSetSecurityContext(obj: OpenbaoServerStatefulSetSecurityContext | undefined): Record<string, any> | undefined;
