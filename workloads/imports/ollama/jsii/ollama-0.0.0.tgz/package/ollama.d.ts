import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface OllamaProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values?: {
        [key: string]: any;
    };
}
export declare class Ollama extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props?: OllamaProps);
    private flattenAdditionalValues;
}
