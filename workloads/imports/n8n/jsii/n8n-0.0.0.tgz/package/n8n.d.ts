import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface N8nProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values: N8nValues;
}
export declare class N8n extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props: N8nProps);
    private flattenAdditionalValues;
}
/**
 * @schema n8n
 */
export interface N8nValues {
    /**
     * DEPRECATED: Use main, worker, and webhook blocks affinity fields instead. This field will be removed in a future release.
     *
     * @schema n8n#affinity
     */
    readonly affinity: any;
    /**
     * @schema n8n#api
     */
    readonly api: N8NApi;
    /**
     * Configuration for binary data storage
     *
     * @schema n8n#binaryData
     */
    readonly binaryData: N8NBinaryData;
    /**
     * n8n database configurations
     *
     * @schema n8n#db
     */
    readonly db: N8NDb;
    /**
     * A locale identifier, compatible with the Accept-Language header. n8n doesn't support regional identifiers, such as de-AT.
     *
     * @schema n8n#defaultLocale
     */
    readonly defaultLocale: N8NDefaultLocale;
    /**
     * @schema n8n#sentry
     */
    readonly sentry: N8NSentry;
    /**
     * @schema n8n#diagnostics
     */
    readonly diagnostics: N8NDiagnostics;
    /**
     * If you install n8n first time, you can keep this empty and it will be auto generated and never change again. If you already have a encryption key generated before, please use it here.
     *
     * @schema n8n#encryptionKey
     */
    readonly encryptionKey: string;
    /**
     * The name of an existing secret with encryption key. The secret must contain a key with the name N8N_ENCRYPTION_KEY.
     *
     * @schema n8n#existingEncryptionKeySecret
     */
    readonly existingEncryptionKeySecret: string;
    /**
     * External PostgreSQL parameters
     *
     * @schema n8n#externalPostgresql
     */
    readonly externalPostgresql: N8NExternalPostgresql;
    /**
     * External Redis parameters
     *
     * @schema n8n#externalRedis
     */
    readonly externalRedis: N8NExternalRedis;
    /**
     * DEPRECATED: Use main, worker, and webhook blocks extraEnvVars fields instead. This field will be removed in a future release.
     *
     * @schema n8n#extraEnvVars
     */
    readonly extraEnvVars?: any;
    /**
     * DEPRECATED: Use main, worker, and webhook blocks extraSecretNamesForEnvFrom fields instead. This field will be removed in a future release.
     *
     * @schema n8n#extraSecretNamesForEnvFrom
     */
    readonly extraSecretNamesForEnvFrom?: any[];
    /**
     * @schema n8n#fullnameOverride
     */
    readonly fullnameOverride: string;
    /**
     * @schema n8n#global
     */
    readonly global?: {
        [key: string]: any;
    };
    /**
     * graceful shutdown timeout in seconds
     *
     * @schema n8n#gracefulShutdownTimeout
     */
    readonly gracefulShutdownTimeout: number;
    /**
     * This sets the container image more information can be found here: https://kubernetes.io/docs/concepts/containers/images/
     *
     * @schema n8n#image
     */
    readonly image: N8NImage;
    /**
     * This is for the secretes for pulling an image from a private repository more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/
     *
     * @schema n8n#imagePullSecrets
     */
    readonly imagePullSecrets: any[];
    /**
     * This block is for setting up the ingress for more information can be found here: https://kubernetes.io/docs/concepts/services-networking/ingress/
     *
     * @schema n8n#ingress
     */
    readonly ingress: N8NIngress;
    /**
     * DEPRECATED: Use main, worker, and webhook blocks livenessProbe field instead. This field will be removed in a future release.
     *
     * @schema n8n#livenessProbe
     */
    readonly livenessProbe?: N8NLivenessProbe;
    /**
     * n8n log configurations
     *
     * @schema n8n#log
     */
    readonly log: N8NLog;
    /**
     * Node configurations for built-in and external npm packages
     *
     * @schema n8n#nodes
     */
    readonly nodes: N8NNodes;
    /**
     * Configuration for private npm registry
     *
     * @schema n8n#npmRegistry
     */
    readonly npmRegistry: N8NNpmRegistry;
    /**
     * n8n license configurations
     *
     * @schema n8n#license
     */
    readonly license: N8NLicense;
    /**
     * Main node configuration
     *
     * @schema n8n#main
     */
    readonly main: N8NMain;
    /**
     * This is to override the chart name.
     *
     * @schema n8n#nameOverride
     */
    readonly nameOverride: string;
    /**
     * For more information checkout: https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#nodeselector
     *
     * @schema n8n#nodeSelector
     */
    readonly nodeSelector: any;
    /**
     * This is for setting Kubernetes Annotations to a Pod. For more information checkout: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
     *
     * @schema n8n#podAnnotations
     */
    readonly podAnnotations: any;
    /**
     * This is for setting Kubernetes Labels to a Pod. For more information checkout: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
     *
     * @schema n8n#podLabels
     */
    readonly podLabels: any;
    /**
     * This is for setting Security Context to a Pod. For more information checkout: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/
     *
     * @schema n8n#podSecurityContext
     */
    readonly podSecurityContext: N8NPodSecurityContext;
    /**
     * @schema n8n#postgresql
     */
    readonly postgresql: {
        [key: string]: any;
    };
    /**
     * DEPRECATED: Use main, worker, and webhook blocks readinessProbe field instead. This field will be removed in a future release.
     *
     * @schema n8n#readinessProbe
     */
    readonly readinessProbe?: N8NReadinessProbe;
    /**
     * @schema n8n#redis
     */
    readonly redis: {
        [key: string]: any;
    };
    /**
     * DEPRECATED: Use main, worker, and webhook blocks resources fields instead. This field will be removed in a future release.
     *
     * @schema n8n#resources
     */
    readonly resources?: N8NResources;
    /**
     * This is for setting Security Context to a Container. For more information checkout: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/
     *
     * @schema n8n#securityContext
     */
    readonly securityContext: N8NSecurityContext;
    /**
     * This is for setting up a service more information can be found here: https://kubernetes.io/docs/concepts/services-networking/service/
     *
     * @schema n8n#service
     */
    readonly service: N8NService;
    /**
     * This section builds out the service account more information can be found here: https://kubernetes.io/docs/concepts/security/service-accounts/
     *
     * @schema n8n#serviceAccount
     */
    readonly serviceAccount: N8NServiceAccount;
    /**
     * This will set the deployment strategy more information can be found here: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#strategy
     *
     * @schema n8n#strategy
     */
    readonly strategy: N8NStrategy;
    /**
     * For instance, the Schedule node uses it to know at what time the workflow should start. Find you timezone from here: https://momentjs.com/timezone/
     *
     * @schema n8n#timezone
     */
    readonly timezone: string;
    /**
     * For more information checkout: https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/
     *
     * @schema n8n#tolerations
     */
    readonly tolerations: any[];
    /**
     * @schema n8n#versionNotifications
     */
    readonly versionNotifications: N8NVersionNotifications;
    /**
     * DEPRECATED: Use main, worker, and webhook blocks volumeMounts fields instead. This field will be removed in a future release.
     *
     * @schema n8n#volumeMounts
     */
    readonly volumeMounts?: any[];
    /**
     * DEPRECATED: Use main, worker, and webhook blocks volumes fields instead. This field will be removed in a future release.
     *
     * @schema n8n#volumes
     */
    readonly volumes?: any[];
    /**
     * @schema n8n#webhook
     */
    readonly webhook: N8NWebhook;
    /**
     * @schema n8n#worker
     */
    readonly worker: N8NWorker;
    /**
     * @schema n8n#taskRunners
     */
    readonly taskRunners: N8NTaskRunners;
    /**
     * @schema n8n#workflowHistory
     */
    readonly workflowHistory: N8NWorkflowHistory;
    /**
     * The ServiceMonitor configuration for the n8n deployment. Please refer to the following link for more information: https://github.com/prometheus-operator/prometheus-operator/blob/main/Documentation/api-reference/api.md
     *
     * @schema n8n#serviceMonitor
     */
    readonly serviceMonitor: N8NServiceMonitor;
    /**
     * @schema n8n#minio
     */
    readonly minio: {
        [key: string]: any;
    };
    /**
     * For more information checkout: https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-policy
     *
     * @schema n8n#dnsPolicy
     */
    readonly dnsPolicy: N8NDnsPolicy;
    /**
     * For more information checkout: https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-dns-config
     *
     * @schema n8n#dnsConfig
     */
    readonly dnsConfig: N8NDnsConfig;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema n8n#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8nValues' to JSON representation.
 */
export declare function toJson_N8nValues(obj: N8nValues | undefined): Record<string, any> | undefined;
/**
 * @schema N8NApi
 */
export interface N8NApi {
    /**
     * Whether to enable the Public API
     *
     * @schema N8NApi#enabled
     */
    readonly enabled: boolean;
    /**
     * Path segment for the Public API
     *
     * @schema N8NApi#path
     */
    readonly path: string;
    /**
     * Whether to enable the Swagger UI for the Public API
     *
     * @schema N8NApi#swagger
     */
    readonly swagger: N8NApiSwagger;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NApi#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NApi' to JSON representation.
 */
export declare function toJson_N8NApi(obj: N8NApi | undefined): Record<string, any> | undefined;
/**
 * Configuration for binary data storage
 *
 * @schema N8NBinaryData
 */
export interface N8NBinaryData {
    /**
     * Available modes of binary data storage. If not set, the default mode will be used. For more information, see https://docs.n8n.io/hosting/configuration/environment-variables/binary-data/
     *
     * @schema N8NBinaryData#availableModes
     */
    readonly availableModes?: N8NBinaryDataAvailableModes[];
    /**
     * The default binary data mode. default keeps binary data in memory. Set to filesystem to use the filesystem, or s3 to AWS S3. Note that binary data pruning operates on the active binary data mode. For example, if your instance stored data in S3, and you later switched to filesystem mode, n8n only prunes binary data in the filesystem. This may change in future. Valid values are 'default' | 'filesystem' | 's3'. For more information, see https://docs.n8n.io/hosting/configuration/environment-variables/binary-data/
     *
     * @schema N8NBinaryData#mode
     */
    readonly mode: N8NBinaryDataMode;
    /**
     * Path for binary data storage in 'filesystem' mode. If not set, the default path will be used. For more information, see https://docs.n8n.io/hosting/configuration/environment-variables/binary-data/
     *
     * @schema N8NBinaryData#localStoragePath
     */
    readonly localStoragePath: string;
    /**
     * S3-compatible external storage configurations. For more information, see https://docs.n8n.io/hosting/configuration/environment-variables/external-data-storage/
     *
     * @schema N8NBinaryData#s3
     */
    readonly s3: N8NBinaryDataS3;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NBinaryData#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NBinaryData' to JSON representation.
 */
export declare function toJson_N8NBinaryData(obj: N8NBinaryData | undefined): Record<string, any> | undefined;
/**
 * n8n database configurations
 *
 * @schema N8NDb
 */
export interface N8NDb {
    /**
     * @schema N8NDb#logging
     */
    readonly logging: N8NDbLogging;
    /**
     * @schema N8NDb#sqlite
     */
    readonly sqlite: N8NDbSqlite;
    /**
     * @schema N8NDb#postgresdb
     */
    readonly postgresdb: N8NDbPostgresdb;
    /**
     * Prefix to use for table names.
     *
     * @schema N8NDb#tablePrefix
     */
    readonly tablePrefix: string;
    /**
     * Type of database to use. Valid values 'sqlite' | 'postgresdb'
     *
     * @schema N8NDb#type
     */
    readonly type: N8NDbType;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDb#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDb' to JSON representation.
 */
export declare function toJson_N8NDb(obj: N8NDb | undefined): Record<string, any> | undefined;
/**
 * A locale identifier, compatible with the Accept-Language header. n8n doesn't support regional identifiers, such as de-AT.
 *
 * @schema N8NDefaultLocale
 */
export declare enum N8NDefaultLocale {
    /** af */
    AF = "af",
    /** am */
    AM = "am",
    /** as */
    AS = "as",
    /** be */
    BE = "be",
    /** bg */
    BG = "bg",
    /** bs */
    BS = "bs",
    /** ca */
    CA = "ca",
    /** cs */
    CS = "cs",
    /** cy */
    CY = "cy",
    /** da */
    DA = "da",
    /** de */
    DE = "de",
    /** el */
    EL = "el",
    /** en */
    EN = "en",
    /** es */
    ES = "es",
    /** et */
    ET = "et",
    /** eu */
    EU = "eu",
    /** fa */
    FA = "fa",
    /** fi */
    FI = "fi",
    /** fr */
    FR = "fr",
    /** ga */
    GA = "ga",
    /** gl */
    GL = "gl",
    /** gu */
    GU = "gu",
    /** he */
    HE = "he",
    /** hi */
    HI = "hi",
    /** hr */
    HR = "hr",
    /** hu */
    HU = "hu",
    /** hy */
    HY = "hy",
    /** id */
    ID = "id",
    /** is */
    IS = "is",
    /** it */
    IT = "it",
    /** ja */
    JA = "ja",
    /** ka */
    KA = "ka",
    /** kk */
    KK = "kk",
    /** km */
    KM = "km",
    /** kn */
    KN = "kn",
    /** ko */
    KO = "ko",
    /** lb */
    LB = "lb",
    /** lt */
    LT = "lt",
    /** lv */
    LV = "lv",
    /** mk */
    MK = "mk",
    /** ml */
    ML = "ml",
    /** mr */
    MR = "mr",
    /** ms */
    MS = "ms",
    /** mt */
    MT = "mt",
    /** nb */
    NB = "nb",
    /** ne */
    NE = "ne",
    /** nl */
    NL = "nl",
    /** nn */
    NN = "nn",
    /** or */
    OR = "or",
    /** pa */
    PA = "pa",
    /** pl */
    PL = "pl",
    /** ro */
    RO = "ro",
    /** ru */
    RU = "ru",
    /** rw */
    RW = "rw",
    /** si */
    SI = "si",
    /** sk */
    SK = "sk",
    /** sl */
    SL = "sl",
    /** sq */
    SQ = "sq",
    /** sv */
    SV = "sv",
    /** sw */
    SW = "sw",
    /** ta */
    TA = "ta",
    /** te */
    TE = "te",
    /** th */
    TH = "th",
    /** ti */
    TI = "ti",
    /** tn */
    TN = "tn",
    /** tr */
    TR = "tr",
    /** uk */
    UK = "uk",
    /** ur */
    UR = "ur",
    /** vi */
    VI = "vi",
    /** wo */
    WO = "wo",
    /** xh */
    XH = "xh",
    /** zu */
    ZU = "zu"
}
/**
 * @schema N8NSentry
 */
export interface N8NSentry {
    /**
     * Whether sentry is enabled.
     *
     * @schema N8NSentry#enabled
     */
    readonly enabled: boolean;
    /**
     * Sentry DSN for backend.
     *
     * @schema N8NSentry#backendDsn
     */
    readonly backendDsn: string;
    /**
     * Sentry DSN for frontend.
     *
     * @schema N8NSentry#frontendDsn
     */
    readonly frontendDsn: string;
    /**
     * Sentry DSN for external task runners.
     *
     * @schema N8NSentry#externalTaskRunnersDsn
     */
    readonly externalTaskRunnersDsn: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NSentry#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NSentry' to JSON representation.
 */
export declare function toJson_N8NSentry(obj: N8NSentry | undefined): Record<string, any> | undefined;
/**
 * @schema N8NDiagnostics
 */
export interface N8NDiagnostics {
    /**
     * Whether diagnostics are enabled.
     *
     * @schema N8NDiagnostics#enabled
     */
    readonly enabled: boolean;
    /**
     * Diagnostics config for backend.
     *
     * @schema N8NDiagnostics#backendConfig
     */
    readonly backendConfig: string;
    /**
     * Diagnostics config for frontend.
     *
     * @schema N8NDiagnostics#frontendConfig
     */
    readonly frontendConfig: string;
    /**
     * @schema N8NDiagnostics#postHog
     */
    readonly postHog: N8NDiagnosticsPostHog;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDiagnostics#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDiagnostics' to JSON representation.
 */
export declare function toJson_N8NDiagnostics(obj: N8NDiagnostics | undefined): Record<string, any> | undefined;
/**
 * External PostgreSQL parameters
 *
 * @schema N8NExternalPostgresql
 */
export interface N8NExternalPostgresql {
    /**
     * The name of the external PostgreSQL database. For more information: https://docs.n8n.io/hosting/configuration/supported-databases-settings/#required-permissions
     *
     * @schema N8NExternalPostgresql#database
     */
    readonly database: string;
    /**
     * The name of an existing secret with PostgreSQL (must contain key `postgres-password`) and credentials.
     * When it's set, the `externalPostgresql.password` parameter is ignored
     *
     * @schema N8NExternalPostgresql#existingSecret
     */
    readonly existingSecret: string;
    /**
     * External PostgreSQL server host
     *
     * @schema N8NExternalPostgresql#host
     */
    readonly host: string;
    /**
     * External PostgreSQL password
     *
     * @schema N8NExternalPostgresql#password
     */
    readonly password: string;
    /**
     * External PostgreSQL server port
     *
     * @schema N8NExternalPostgresql#port
     */
    readonly port: number;
    /**
     * External PostgreSQL username
     *
     * @schema N8NExternalPostgresql#username
     */
    readonly username: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NExternalPostgresql#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NExternalPostgresql' to JSON representation.
 */
export declare function toJson_N8NExternalPostgresql(obj: N8NExternalPostgresql | undefined): Record<string, any> | undefined;
/**
 * External Redis parameters
 *
 * @schema N8NExternalRedis
 */
export interface N8NExternalRedis {
    /**
     * Redis database for Bull queue.
     *
     * @schema N8NExternalRedis#database
     */
    readonly database: number;
    /**
     * External Redis server host
     *
     * @schema N8NExternalRedis#host
     */
    readonly host: string;
    /**
     * External Redis username
     *
     * @schema N8NExternalRedis#username
     */
    readonly username: string;
    /**
     * External Redis password
     *
     * @schema N8NExternalRedis#password
     */
    readonly password: string;
    /**
     * External Redis server port
     *
     * @schema N8NExternalRedis#port
     */
    readonly port: number;
    /**
     * The name of an existing secret with Redis (must contain key `redis-password`) and Sentinel credentials.
     * When it's set, the `externalRedis.password` parameter is ignored
     *
     * @schema N8NExternalRedis#existingSecret
     */
    readonly existingSecret: string;
    /**
     * List of Redis Cluster nodes. Setting this variable will create a Redis Cluster client instead of a Redis client, and n8n will ignore `externalRedis.host` and `externalRedis.port`.
     *
     * @schema N8NExternalRedis#clusterNodes
     */
    readonly clusterNodes: N8NExternalRedisClusterNodes[];
    /**
     * Placeholder for future Redis TLS certificates.
     *
     * @schema N8NExternalRedis#tls
     */
    readonly tls: N8NExternalRedisTls;
    /**
     * Enable dual-stack support (IPv4 and IPv6) on Redis connections.
     *
     * @schema N8NExternalRedis#dualStack
     */
    readonly dualStack: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NExternalRedis#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NExternalRedis' to JSON representation.
 */
export declare function toJson_N8NExternalRedis(obj: N8NExternalRedis | undefined): Record<string, any> | undefined;
/**
 * This sets the container image more information can be found here: https://kubernetes.io/docs/concepts/containers/images/
 *
 * @schema N8NImage
 */
export interface N8NImage {
    /**
     * This sets the pull policy for images.
     *
     * @schema N8NImage#pullPolicy
     */
    readonly pullPolicy: string;
    /**
     * @schema N8NImage#repository
     */
    readonly repository: string;
    /**
     * Overrides the image tag whose default is the chart appVersion.
     *
     * @schema N8NImage#tag
     */
    readonly tag: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NImage' to JSON representation.
 */
export declare function toJson_N8NImage(obj: N8NImage | undefined): Record<string, any> | undefined;
/**
 * This block is for setting up the ingress for more information can be found here: https://kubernetes.io/docs/concepts/services-networking/ingress/
 *
 * @schema N8NIngress
 */
export interface N8NIngress {
    /**
     * @schema N8NIngress#annotations
     */
    readonly annotations: any;
    /**
     * @schema N8NIngress#className
     */
    readonly className: string;
    /**
     * @schema N8NIngress#enabled
     */
    readonly enabled: boolean;
    /**
     * kubernetes.io/ingress.class: nginx
     * kubernetes.io/tls-acme: "true"
     *
     * @schema N8NIngress#hosts
     */
    readonly hosts: any[];
    /**
     * @schema N8NIngress#tls
     */
    readonly tls: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NIngress#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NIngress' to JSON representation.
 */
export declare function toJson_N8NIngress(obj: N8NIngress | undefined): Record<string, any> | undefined;
/**
 * DEPRECATED: Use main, worker, and webhook blocks livenessProbe field instead. This field will be removed in a future release.
 *
 * @schema N8NLivenessProbe
 */
export interface N8NLivenessProbe {
    /**
     * @schema N8NLivenessProbe#httpGet
     */
    readonly httpGet?: N8NLivenessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NLivenessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NLivenessProbe' to JSON representation.
 */
export declare function toJson_N8NLivenessProbe(obj: N8NLivenessProbe | undefined): Record<string, any> | undefined;
/**
 * n8n log configurations
 *
 * @schema N8NLog
 */
export interface N8NLog {
    /**
     * @schema N8NLog#file
     */
    readonly file: N8NLogFile;
    /**
     * The log output level. The available options are (from lowest to highest level) are error, warn, info, and debug. The default value is info. You can learn more about these options [here](https://docs.n8n.io/hosting/logging-monitoring/logging/#log-levels).
     *
     * @schema N8NLog#level
     */
    readonly level: N8NLogLevel;
    /**
     * Where to output logs to. Options are: `console` or `file` or both.
     *
     * @schema N8NLog#output
     */
    readonly output: N8NLogOutput[];
    /**
     * Scopes to filter logs by. Nothing is filtered by default. Supported log scopes: concurrency, external-secrets, license, multi-main-setup, pubsub, redis, scaling, waiting-executions
     *
     * @schema N8NLog#scopes
     */
    readonly scopes: N8NLogScopes[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NLog#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NLog' to JSON representation.
 */
export declare function toJson_N8NLog(obj: N8NLog | undefined): Record<string, any> | undefined;
/**
 * Node configurations for built-in and external npm packages
 *
 * @schema N8NNodes
 */
export interface N8NNodes {
    /**
     * Enable built-in node functions (e.g., HTTP Request, Code Node, etc.)
     *
     * @schema N8NNodes#builtin
     */
    readonly builtin?: N8NNodesBuiltin;
    /**
     * External npm packages to install and allow in the Code node
     *
     * @schema N8NNodes#external
     */
    readonly external?: N8NNodesExternal;
    /**
     * Image for the init container to install npm packages
     *
     * @schema N8NNodes#initContainer
     */
    readonly initContainer: N8NNodesInitContainer;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NNodes#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NNodes' to JSON representation.
 */
export declare function toJson_N8NNodes(obj: N8NNodes | undefined): Record<string, any> | undefined;
/**
 * Configuration for private npm registry
 *
 * @schema N8NNpmRegistry
 */
export interface N8NNpmRegistry {
    /**
     * Enable private npm registry
     *
     * @schema N8NNpmRegistry#enabled
     */
    readonly enabled: boolean;
    /**
     * URL of the private npm registry (e.g., https://registry.npmjs.org/)
     *
     * @schema N8NNpmRegistry#url
     */
    readonly url: string;
    /**
     * Name of the Kubernetes secret containing npm registry credentials
     *
     * @schema N8NNpmRegistry#secretName
     */
    readonly secretName: string;
    /**
     * Key in the secret for the .npmrc content or auth token
     *
     * @schema N8NNpmRegistry#secretKey
     */
    readonly secretKey: string;
    /**
     * Custom .npmrc content (optional, overrides secret if provided)
     *
     * @schema N8NNpmRegistry#customNpmrc
     */
    readonly customNpmrc: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NNpmRegistry#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NNpmRegistry' to JSON representation.
 */
export declare function toJson_N8NNpmRegistry(obj: N8NNpmRegistry | undefined): Record<string, any> | undefined;
/**
 * n8n license configurations
 *
 * @schema N8NLicense
 */
export interface N8NLicense {
    /**
     * Whether to enable the license
     *
     * @schema N8NLicense#enabled
     */
    readonly enabled: boolean;
    /**
     * Activation key to initialize license. Not applicable if the n8n instance was already activated. For more information please refer to the following link: https://docs.n8n.io/enterprise-key/
     *
     * @schema N8NLicense#activationKey
     */
    readonly activationKey: string;
    /**
     * The name of an existing secret with license activation key. The secret must contain a key with the name N8N_LICENSE_ACTIVATION_KEY.
     *
     * @schema N8NLicense#existingActivationKeySecret
     */
    readonly existingActivationKeySecret: string;
    /**
     * The auto new license configuration
     *
     * @schema N8NLicense#autoNenew
     */
    readonly autoNenew: N8NLicenseAutoNenew;
    /**
     * Server URL to retrieve license. The default value is https://license.n8n.io/v1.
     *
     * @schema N8NLicense#serverUrl
     */
    readonly serverUrl: string;
    /**
     * Tenant ID associated with the license. Only set this variable if explicitly instructed by n8n.
     *
     * @schema N8NLicense#tenantId
     */
    readonly tenantId: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NLicense#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NLicense' to JSON representation.
 */
export declare function toJson_N8NLicense(obj: N8NLicense | undefined): Record<string, any> | undefined;
/**
 * Main node configuration
 *
 * @schema N8NMain
 */
export interface N8NMain {
    /**
     * Number of main nodes. Only enterprise license users can have one leader main node and mutiple follower main nodes.
     *
     * @schema N8NMain#count
     */
    readonly count: number;
    /**
     * Editor based URL. If it's not defined and ingress definition exists, ingress host will be used.
     *
     * @schema N8NMain#editorBaseUrl
     */
    readonly editorBaseUrl: string;
    /**
     * PodDisruptionBudget configuration for the main node
     *
     * @schema N8NMain#pdb
     */
    readonly pdb: N8NMainPdb;
    /**
     * This block is for setting up the resource management for the pod more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
     *
     * @schema N8NMain#resources
     */
    readonly resources: N8NMainResources;
    /**
     * This is to setup the liveness probe for the main pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NMain#livenessProbe
     */
    readonly livenessProbe: N8NMainLivenessProbe;
    /**
     * This is to setup the readiness probe for the main pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NMain#readinessProbe
     */
    readonly readinessProbe: N8NMainReadinessProbe;
    /**
     * Force to use statefulset for the main pod. If true, the main pod will be created as a statefulset.
     *
     * @schema N8NMain#forceToUseStatefulset
     */
    readonly forceToUseStatefulset: boolean;
    /**
     * Persistence configuration for the main pod
     *
     * @schema N8NMain#persistence
     */
    readonly persistence: N8NMainPersistence;
    /**
     * Extra environment variables
     *
     * @schema N8NMain#extraEnvVars
     */
    readonly extraEnvVars: any;
    /**
     * Extra secrets for environment variables
     *
     * @schema N8NMain#extraSecretNamesForEnvFrom
     */
    readonly extraSecretNamesForEnvFrom: any[];
    /**
     * Additional volumes on the output Deployment definition.
     *
     * @schema N8NMain#volumes
     */
    readonly volumes: any[];
    /**
     * Additional volumeMounts on the output Deployment definition.
     *
     * @schema N8NMain#volumeMounts
     */
    readonly volumeMounts: any[];
    /**
     * Additional init containers for the main pod
     *
     * @schema N8NMain#initContainers
     */
    readonly initContainers: any[];
    /**
     * Additional containers for the main pod
     *
     * @schema N8NMain#extraContainers
     */
    readonly extraContainers: any[];
    /**
     * For more information checkout: https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#affinity-and-anti-affinity
     *
     * @schema N8NMain#affinity
     */
    readonly affinity: any;
    /**
     * Host aliases for the main pod. For more information checkout: https://kubernetes.io/docs/tasks/network/customize-hosts-file-for-pods/#adding-additional-entries-with-hostaliases
     *
     * @schema N8NMain#hostAliases
     */
    readonly hostAliases: N8NMainHostAliases[];
    /**
     * Runtime class name for the main pod. For more information checkout: https://kubernetes.io/docs/concepts/containers/runtime-class/
     *
     * @schema N8NMain#runtimeClassName
     */
    readonly runtimeClassName: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMain#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMain' to JSON representation.
 */
export declare function toJson_N8NMain(obj: N8NMain | undefined): Record<string, any> | undefined;
/**
 * This is for setting Security Context to a Pod. For more information checkout: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/
 *
 * @schema N8NPodSecurityContext
 */
export interface N8NPodSecurityContext {
    /**
     * @schema N8NPodSecurityContext#runAsUser
     */
    readonly runAsUser?: number;
    /**
     * @schema N8NPodSecurityContext#runAsGroup
     */
    readonly runAsGroup?: number;
    /**
     * @schema N8NPodSecurityContext#fsGroup
     */
    readonly fsGroup?: number;
    /**
     * @schema N8NPodSecurityContext#supplementalGroups
     */
    readonly supplementalGroups?: any[];
    /**
     * @schema N8NPodSecurityContext#fsGroupChangePolicy
     */
    readonly fsGroupChangePolicy?: N8NPodSecurityContextFsGroupChangePolicy;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NPodSecurityContext#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NPodSecurityContext' to JSON representation.
 */
export declare function toJson_N8NPodSecurityContext(obj: N8NPodSecurityContext | undefined): Record<string, any> | undefined;
/**
 * DEPRECATED: Use main, worker, and webhook blocks readinessProbe field instead. This field will be removed in a future release.
 *
 * @schema N8NReadinessProbe
 */
export interface N8NReadinessProbe {
    /**
     * @schema N8NReadinessProbe#httpGet
     */
    readonly httpGet?: N8NReadinessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NReadinessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NReadinessProbe' to JSON representation.
 */
export declare function toJson_N8NReadinessProbe(obj: N8NReadinessProbe | undefined): Record<string, any> | undefined;
/**
 * DEPRECATED: Use main, worker, and webhook blocks resources fields instead. This field will be removed in a future release.
 *
 * @schema N8NResources
 */
export interface N8NResources {
    /**
     * @schema N8NResources#limits
     */
    readonly limits?: N8NResourcesLimits;
    /**
     * @schema N8NResources#requests
     */
    readonly requests?: N8NResourcesRequests;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NResources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NResources' to JSON representation.
 */
export declare function toJson_N8NResources(obj: N8NResources | undefined): Record<string, any> | undefined;
/**
 * This is for setting Security Context to a Container. For more information checkout: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/
 *
 * @schema N8NSecurityContext
 */
export interface N8NSecurityContext {
    /**
     * @schema N8NSecurityContext#allowPrivilegeEscalation
     */
    readonly allowPrivilegeEscalation?: boolean;
    /**
     * @schema N8NSecurityContext#readOnlyRootFilesystem
     */
    readonly readOnlyRootFilesystem?: boolean;
    /**
     * @schema N8NSecurityContext#runAsNonRoot
     */
    readonly runAsNonRoot?: boolean;
    /**
     * @schema N8NSecurityContext#runAsUser
     */
    readonly runAsUser?: number;
    /**
     * @schema N8NSecurityContext#capabilities
     */
    readonly capabilities?: N8NSecurityContextCapabilities;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NSecurityContext#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NSecurityContext' to JSON representation.
 */
export declare function toJson_N8NSecurityContext(obj: N8NSecurityContext | undefined): Record<string, any> | undefined;
/**
 * This is for setting up a service more information can be found here: https://kubernetes.io/docs/concepts/services-networking/service/
 *
 * @schema N8NService
 */
export interface N8NService {
    /**
     * Whether to enable the service
     *
     * @schema N8NService#enabled
     */
    readonly enabled: boolean;
    /**
     * Additional service annotations
     *
     * @schema N8NService#annotations
     */
    readonly annotations: any;
    /**
     * Additional service labels
     *
     * @schema N8NService#labels
     */
    readonly labels: any;
    /**
     * Default Service name
     *
     * @schema N8NService#name
     */
    readonly name: string;
    /**
     * This sets the ports more information can be found here: https://kubernetes.io/docs/concepts/services-networking/service/#field-spec-ports
     *
     * @schema N8NService#port
     */
    readonly port: number;
    /**
     * This sets the service type more information can be found here: https://kubernetes.io/docs/concepts/services-networking/service/#publishing-services-service-types
     *
     * @schema N8NService#type
     */
    readonly type: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NService#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NService' to JSON representation.
 */
export declare function toJson_N8NService(obj: N8NService | undefined): Record<string, any> | undefined;
/**
 * This section builds out the service account more information can be found here: https://kubernetes.io/docs/concepts/security/service-accounts/
 *
 * @schema N8NServiceAccount
 */
export interface N8NServiceAccount {
    /**
     * Annotations to add to the service account
     *
     * @schema N8NServiceAccount#annotations
     */
    readonly annotations: any;
    /**
     * Automatically mount a ServiceAccount's API credentials?
     *
     * @schema N8NServiceAccount#automount
     */
    readonly automount: boolean;
    /**
     * Specifies whether a service account should be created
     *
     * @schema N8NServiceAccount#create
     */
    readonly create: boolean;
    /**
     * The name of the service account to use. If not set and create is true, a name is generated using the fullname template
     *
     * @schema N8NServiceAccount#name
     */
    readonly name: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NServiceAccount#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NServiceAccount' to JSON representation.
 */
export declare function toJson_N8NServiceAccount(obj: N8NServiceAccount | undefined): Record<string, any> | undefined;
/**
 * This will set the deployment strategy more information can be found here: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#strategy
 *
 * @schema N8NStrategy
 */
export interface N8NStrategy {
    /**
     * @schema N8NStrategy#type
     */
    readonly type: N8NStrategyType;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NStrategy#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NStrategy' to JSON representation.
 */
export declare function toJson_N8NStrategy(obj: N8NStrategy | undefined): Record<string, any> | undefined;
/**
 * @schema N8NVersionNotifications
 */
export interface N8NVersionNotifications {
    /**
     * Whether to request notifications about new n8n versions
     *
     * @schema N8NVersionNotifications#enabled
     */
    readonly enabled: boolean;
    /**
     * Endpoint to retrieve n8n version information from
     *
     * @schema N8NVersionNotifications#endpoint
     */
    readonly endpoint: string;
    /**
     * URL for versions panel to page instructing user on how to update n8n instance
     *
     * @schema N8NVersionNotifications#infoUrl
     */
    readonly infoUrl: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NVersionNotifications#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NVersionNotifications' to JSON representation.
 */
export declare function toJson_N8NVersionNotifications(obj: N8NVersionNotifications | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhook
 */
export interface N8NWebhook {
    /**
     * number of webhooks
     *
     * @schema N8NWebhook#count
     */
    readonly count: number;
    /**
     * Use `regular` to use main node as webhook node, or use `queue` to have webhook nodes
     *
     * @schema N8NWebhook#mode
     */
    readonly mode: N8NWebhookMode;
    /**
     * If true, all k8s nodes will deploy exatly one worker pod
     *
     * @schema N8NWebhook#allNodes
     */
    readonly allNodes: boolean;
    /**
     * MCP webhook configuration. This is only used when the webhook mode is set to `queue` and the database type is set to `postgresdb`.
     *
     * @schema N8NWebhook#mcp
     */
    readonly mcp: N8NWebhookMcp;
    /**
     * @schema N8NWebhook#autoscaling
     */
    readonly autoscaling: N8NWebhookAutoscaling;
    /**
     * PodDisruptionBudget configuration for the worker node
     *
     * @schema N8NWebhook#pdb
     */
    readonly pdb: N8NWebhookPdb;
    /**
     * This is to setup the wait for the main node to be ready.
     *
     * @schema N8NWebhook#waitMainNodeReady
     */
    readonly waitMainNodeReady: N8NWebhookWaitMainNodeReady;
    /**
     * Webhook url together with http schema
     *
     * @schema N8NWebhook#url
     */
    readonly url: string;
    /**
     * This block is for setting up the resource management for the pod more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
     *
     * @schema N8NWebhook#resources
     */
    readonly resources: N8NWebhookResources;
    /**
     * This is to setup the startup probe for the webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWebhook#startupProbe
     */
    readonly startupProbe: N8NWebhookStartupProbe;
    /**
     * This is to setup the liveness probe for the webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWebhook#livenessProbe
     */
    readonly livenessProbe: N8NWebhookLivenessProbe;
    /**
     * This is to setup the readiness probe for the webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWebhook#readinessProbe
     */
    readonly readinessProbe: N8NWebhookReadinessProbe;
    /**
     * Extra environment variables
     *
     * @schema N8NWebhook#extraEnvVars
     */
    readonly extraEnvVars: any;
    /**
     * Extra secrets for environment variables
     *
     * @schema N8NWebhook#extraSecretNamesForEnvFrom
     */
    readonly extraSecretNamesForEnvFrom: any[];
    /**
     * Additional volumes on the output Deployment definition.
     *
     * @schema N8NWebhook#volumes
     */
    readonly volumes: any[];
    /**
     * Additional volumeMounts on the output Deployment definition.
     *
     * @schema N8NWebhook#volumeMounts
     */
    readonly volumeMounts: any[];
    /**
     * Additional init containers for the pod
     *
     * @schema N8NWebhook#initContainers
     */
    readonly initContainers: any[];
    /**
     * Additional containers for the webhook pod
     *
     * @schema N8NWebhook#extraContainers
     */
    readonly extraContainers: any[];
    /**
     * For more information checkout: https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#affinity-and-anti-affinity
     *
     * @schema N8NWebhook#affinity
     */
    readonly affinity: any;
    /**
     * Host aliases for the webhook pod. For more information checkout: https://kubernetes.io/docs/tasks/network/customize-hosts-file-for-pods/#adding-additional-entries-with-hostaliases
     *
     * @schema N8NWebhook#hostAliases
     */
    readonly hostAliases: N8NWebhookHostAliases[];
    /**
     * Runtime class name for the webhook pod. For more information checkout: https://kubernetes.io/docs/concepts/containers/runtime-class/
     *
     * @schema N8NWebhook#runtimeClassName
     */
    readonly runtimeClassName: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhook#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhook' to JSON representation.
 */
export declare function toJson_N8NWebhook(obj: N8NWebhook | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorker
 */
export interface N8NWorker {
    /**
     * number of concurrency for each worker
     *
     * @schema N8NWorker#concurrency
     */
    readonly concurrency: number;
    /**
     * number of workers
     *
     * @schema N8NWorker#count
     */
    readonly count: number;
    /**
     * Use `regular` to use main node as executer, or use `queue` to have worker nodes
     *
     * @schema N8NWorker#mode
     */
    readonly mode: N8NWorkerMode;
    /**
     * If true, all k8s nodes will deploy exatly one worker pod
     *
     * @schema N8NWorker#allNodes
     */
    readonly allNodes: boolean;
    /**
     * @schema N8NWorker#autoscaling
     */
    readonly autoscaling: N8NWorkerAutoscaling;
    /**
     * PodDisruptionBudget configuration for the worker node
     *
     * @schema N8NWorker#pdb
     */
    readonly pdb: N8NWorkerPdb;
    /**
     * This is to setup the wait for the main node to be ready.
     *
     * @schema N8NWorker#waitMainNodeReady
     */
    readonly waitMainNodeReady: N8NWorkerWaitMainNodeReady;
    /**
     * This block is for setting up the resource management for the pod more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
     *
     * @schema N8NWorker#resources
     */
    readonly resources: N8NWorkerResources;
    /**
     * This is to setup the startup probe for the worker pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWorker#startupProbe
     */
    readonly startupProbe: N8NWorkerStartupProbe;
    /**
     * This is to setup the liveness probe for the worker pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWorker#livenessProbe
     */
    readonly livenessProbe: N8NWorkerLivenessProbe;
    /**
     * This is to setup the readiness probe for the worker pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWorker#readinessProbe
     */
    readonly readinessProbe: N8NWorkerReadinessProbe;
    /**
     * Force to use statefulset for the worker pod. If true, the worker pod will be created as a statefulset.
     *
     * @schema N8NWorker#forceToUseStatefulset
     */
    readonly forceToUseStatefulset: boolean;
    /**
     * Persistence configuration for the worker pod
     *
     * @schema N8NWorker#persistence
     */
    readonly persistence: N8NWorkerPersistence;
    /**
     * Extra environment variables
     *
     * @schema N8NWorker#extraEnvVars
     */
    readonly extraEnvVars: any;
    /**
     * Extra secrets for environment variables
     *
     * @schema N8NWorker#extraSecretNamesForEnvFrom
     */
    readonly extraSecretNamesForEnvFrom: any[];
    /**
     * Additional volumes on the output Deployment definition.
     *
     * @schema N8NWorker#volumes
     */
    readonly volumes: any[];
    /**
     * Additional volumeMounts on the output Deployment definition.
     *
     * @schema N8NWorker#volumeMounts
     */
    readonly volumeMounts: any[];
    /**
     * Additional init containers for the worker pod
     *
     * @schema N8NWorker#initContainers
     */
    readonly initContainers: any[];
    /**
     * Additional containers for the worker pod
     *
     * @schema N8NWorker#extraContainers
     */
    readonly extraContainers: any[];
    /**
     * For more information checkout: https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#affinity-and-anti-affinity
     *
     * @schema N8NWorker#affinity
     */
    readonly affinity: any;
    /**
     * Host aliases for the worker pod. For more information checkout: https://kubernetes.io/docs/tasks/network/customize-hosts-file-for-pods/#adding-additional-entries-with-hostaliases
     *
     * @schema N8NWorker#hostAliases
     */
    readonly hostAliases: N8NWorkerHostAliases[];
    /**
     * Runtime class name for the worker pod. For more information checkout: https://kubernetes.io/docs/concepts/containers/runtime-class/
     *
     * @schema N8NWorker#runtimeClassName
     */
    readonly runtimeClassName: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorker#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorker' to JSON representation.
 */
export declare function toJson_N8NWorker(obj: N8NWorker | undefined): Record<string, any> | undefined;
/**
 * @schema N8NTaskRunners
 */
export interface N8NTaskRunners {
    /**
     * Use `internal` to use internal task runner, or use `external` to have external sidecar task runner
     *
     * @schema N8NTaskRunners#mode
     */
    readonly mode: N8NTaskRunnersMode;
    /**
     * The timeout for the task in seconds
     *
     * @schema N8NTaskRunners#taskTimeout
     */
    readonly taskTimeout: number;
    /**
     * The heartbeat interval for the task in seconds
     *
     * @schema N8NTaskRunners#taskHeartbeatInterval
     */
    readonly taskHeartbeatInterval: number;
    /**
     * The maximum concurrency for the task
     *
     * @schema N8NTaskRunners#maxConcurrency
     */
    readonly maxConcurrency: number;
    /**
     * @schema N8NTaskRunners#broker
     */
    readonly broker: N8NTaskRunnersBroker;
    /**
     * @schema N8NTaskRunners#external
     */
    readonly external?: N8NTaskRunnersExternal;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NTaskRunners#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NTaskRunners' to JSON representation.
 */
export declare function toJson_N8NTaskRunners(obj: N8NTaskRunners | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkflowHistory
 */
export interface N8NWorkflowHistory {
    /**
     * Whether to save workflow history versions
     *
     * @schema N8NWorkflowHistory#enabled
     */
    readonly enabled: boolean;
    /**
     * Time (in hours) to keep workflow history versions for. To disable it, use -1 as a value
     *
     * @schema N8NWorkflowHistory#pruneTime
     */
    readonly pruneTime: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkflowHistory#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkflowHistory' to JSON representation.
 */
export declare function toJson_N8NWorkflowHistory(obj: N8NWorkflowHistory | undefined): Record<string, any> | undefined;
/**
 * The ServiceMonitor configuration for the n8n deployment. Please refer to the following link for more information: https://github.com/prometheus-operator/prometheus-operator/blob/main/Documentation/api-reference/api.md
 *
 * @schema N8NServiceMonitor
 */
export interface N8NServiceMonitor {
    /**
     * Whether to enable the ServiceMonitor for the n8n deployment
     *
     * @schema N8NServiceMonitor#enabled
     */
    readonly enabled: boolean;
    /**
     * The namespace for the ServiceMonitor. If empty, the ServiceMonitor will be deployed in the same namespace as the n8n chart.
     *
     * @schema N8NServiceMonitor#namespace
     */
    readonly namespace: string;
    /**
     * The interval for the ServiceMonitor (e.g., 30s, 1m, 1h)
     *
     * @schema N8NServiceMonitor#interval
     */
    readonly interval: string;
    /**
     * The labels for the ServiceMonitor, use this to define your scrape label for Prometheus Operator
     *
     * @schema N8NServiceMonitor#labels
     */
    readonly labels: {
        [key: string]: string;
    };
    /**
     * The timeout for the ServiceMonitor (e.g., 10s, 1m)
     *
     * @schema N8NServiceMonitor#timeout
     */
    readonly timeout: string;
    /**
     * Set of labels to transfer from the Kubernetes Service onto the target
     *
     * @schema N8NServiceMonitor#targetLabels
     */
    readonly targetLabels: string[];
    /**
     * The metric relabelings for the ServiceMonitor, following Prometheus relabel_config structure
     *
     * @schema N8NServiceMonitor#metricRelabelings
     */
    readonly metricRelabelings: N8NServiceMonitorMetricRelabelings[];
    /**
     * The metrics prefix for the ServiceMonitor
     *
     * @schema N8NServiceMonitor#metricsPrefix
     */
    readonly metricsPrefix: string;
    /**
     * Metrics and labels to include in the ServiceMonitor
     *
     * @schema N8NServiceMonitor#include
     */
    readonly include: N8NServiceMonitorInclude;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NServiceMonitor#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NServiceMonitor' to JSON representation.
 */
export declare function toJson_N8NServiceMonitor(obj: N8NServiceMonitor | undefined): Record<string, any> | undefined;
/**
 * For more information checkout: https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-policy
 *
 * @schema N8NDnsPolicy
 */
export declare enum N8NDnsPolicy {
    /** ClusterFirst */
    CLUSTER_FIRST = "ClusterFirst",
    /** ClusterFirstWithHostNet */
    CLUSTER_FIRST_WITH_HOST_NET = "ClusterFirstWithHostNet",
    /** Default */
    DEFAULT = "Default",
    /** None */
    NONE = "None"
}
/**
 * For more information checkout: https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-dns-config
 *
 * @schema N8NDnsConfig
 */
export interface N8NDnsConfig {
    /**
     * List of DNS nameserver IP addresses (IPv4 or IPv6).
     *
     * @schema N8NDnsConfig#nameservers
     */
    readonly nameservers?: string[];
    /**
     * List of DNS search domains for hostname lookup.
     *
     * @schema N8NDnsConfig#searches
     */
    readonly searches?: string[];
    /**
     * List of DNS resolver options.
     *
     * @schema N8NDnsConfig#options
     */
    readonly options?: N8NDnsConfigOptions[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDnsConfig#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDnsConfig' to JSON representation.
 */
export declare function toJson_N8NDnsConfig(obj: N8NDnsConfig | undefined): Record<string, any> | undefined;
/**
 * Whether to enable the Swagger UI for the Public API
 *
 * @schema N8NApiSwagger
 */
export interface N8NApiSwagger {
    /**
     * @schema N8NApiSwagger#enabled
     */
    readonly enabled: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NApiSwagger#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NApiSwagger' to JSON representation.
 */
export declare function toJson_N8NApiSwagger(obj: N8NApiSwagger | undefined): Record<string, any> | undefined;
/**
 * @schema N8NBinaryDataAvailableModes
 */
export declare enum N8NBinaryDataAvailableModes {
    /** filesystem */
    FILESYSTEM = "filesystem",
    /** s3 */
    S3 = "s3"
}
/**
 * The default binary data mode. default keeps binary data in memory. Set to filesystem to use the filesystem, or s3 to AWS S3. Note that binary data pruning operates on the active binary data mode. For example, if your instance stored data in S3, and you later switched to filesystem mode, n8n only prunes binary data in the filesystem. This may change in future. Valid values are 'default' | 'filesystem' | 's3'. For more information, see https://docs.n8n.io/hosting/configuration/environment-variables/binary-data/
 *
 * @schema N8NBinaryDataMode
 */
export declare enum N8NBinaryDataMode {
    /** default */
    DEFAULT = "default",
    /** filesystem */
    FILESYSTEM = "filesystem",
    /** s3 */
    S3 = "s3"
}
/**
 * S3-compatible external storage configurations. For more information, see https://docs.n8n.io/hosting/configuration/environment-variables/external-data-storage/
 *
 * @schema N8NBinaryDataS3
 */
export interface N8NBinaryDataS3 {
    /**
     * Host of the n8n bucket in S3-compatible external storage. For example, s3.us-east-1.amazonaws.com
     *
     * @schema N8NBinaryDataS3#host
     */
    readonly host: string;
    /**
     * Name of the n8n bucket in S3-compatible external storage.
     *
     * @schema N8NBinaryDataS3#bucketName
     */
    readonly bucketName: string;
    /**
     * Region of the S3-compatible external storage bucket. For example, us-east-1
     *
     * @schema N8NBinaryDataS3#bucketRegion
     */
    readonly bucketRegion: string;
    /**
     * Access key in S3-compatible external storage
     *
     * @schema N8NBinaryDataS3#accessKey
     */
    readonly accessKey: string;
    /**
     * Access secret in S3-compatible external storage
     *
     * @schema N8NBinaryDataS3#accessSecret
     */
    readonly accessSecret: string;
    /**
     * This is for setting up the s3 file storage existing secret. Must contain access-key-id and secret-access-key keys.
     *
     * @schema N8NBinaryDataS3#existingSecret
     */
    readonly existingSecret: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NBinaryDataS3#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NBinaryDataS3' to JSON representation.
 */
export declare function toJson_N8NBinaryDataS3(obj: N8NBinaryDataS3 | undefined): Record<string, any> | undefined;
/**
 * @schema N8NDbLogging
 */
export interface N8NDbLogging {
    /**
     * Whether database logging is enabled.
     *
     * @schema N8NDbLogging#enabled
     */
    readonly enabled: boolean;
    /**
     * Only queries that exceed this time (ms) will be logged. Set `0` to disable.
     *
     * @schema N8NDbLogging#maxQueryExecutionTime
     */
    readonly maxQueryExecutionTime: number;
    /**
     * Database logging level. Requires `maxQueryExecutionTime` to be higher than `0`. Valid values 'query' | 'error' | 'schema' | 'warn' | 'info' | 'log' | 'all'
     *
     * @schema N8NDbLogging#options
     */
    readonly options: N8NDbLoggingOptions;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDbLogging#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDbLogging' to JSON representation.
 */
export declare function toJson_N8NDbLogging(obj: N8NDbLogging | undefined): Record<string, any> | undefined;
/**
 * @schema N8NDbSqlite
 */
export interface N8NDbSqlite {
    /**
     * SQLite database file name
     *
     * @schema N8NDbSqlite#database
     */
    readonly database: string;
    /**
     * SQLite database pool size. Set to `0` to disable pooling.
     *
     * @schema N8NDbSqlite#poolSize
     */
    readonly poolSize: number;
    /**
     * Runs VACUUM operation on startup to rebuild the database. Reduces file size and optimizes indexes. This is a long running blocking operation and increases start-up time.
     *
     * @schema N8NDbSqlite#vacuum
     */
    readonly vacuum: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDbSqlite#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDbSqlite' to JSON representation.
 */
export declare function toJson_N8NDbSqlite(obj: N8NDbSqlite | undefined): Record<string, any> | undefined;
/**
 * @schema N8NDbPostgresdb
 */
export interface N8NDbPostgresdb {
    /**
     * Control how many parallel open Postgres connections n8n should have. Increasing it may help with resource utilization, but too many connections may degrade performance.
     *
     * @schema N8NDbPostgresdb#poolSize
     */
    readonly poolSize: number;
    /**
     * Postgres connection timeout (ms).
     *
     * @schema N8NDbPostgresdb#connectionTimeout
     */
    readonly connectionTimeout: number;
    /**
     * Amount of time before an idle connection is eligible for eviction for being idle.
     *
     * @schema N8NDbPostgresdb#idleConnectionTimeout
     */
    readonly idleConnectionTimeout: number;
    /**
     * The PostgreSQL schema.
     *
     * @schema N8NDbPostgresdb#schema
     */
    readonly schema: string;
    /**
     * The PostgreSQL connection SSL settings. Find more information from here: https://docs.n8n.io/hosting/configuration/supported-databases-settings/#postgresdb
     *
     * @schema N8NDbPostgresdb#ssl
     */
    readonly ssl: N8NDbPostgresdbSsl;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDbPostgresdb#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDbPostgresdb' to JSON representation.
 */
export declare function toJson_N8NDbPostgresdb(obj: N8NDbPostgresdb | undefined): Record<string, any> | undefined;
/**
 * Type of database to use. Valid values 'sqlite' | 'postgresdb'
 *
 * @schema N8NDbType
 */
export declare enum N8NDbType {
    /** sqlite */
    SQLITE = "sqlite",
    /** postgresdb */
    POSTGRESDB = "postgresdb"
}
/**
 * @schema N8NDiagnosticsPostHog
 */
export interface N8NDiagnosticsPostHog {
    /**
     * API host for PostHog.
     *
     * @schema N8NDiagnosticsPostHog#apiHost
     */
    readonly apiHost: string;
    /**
     * API key for PostHog.
     *
     * @schema N8NDiagnosticsPostHog#apiKey
     */
    readonly apiKey: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDiagnosticsPostHog#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDiagnosticsPostHog' to JSON representation.
 */
export declare function toJson_N8NDiagnosticsPostHog(obj: N8NDiagnosticsPostHog | undefined): Record<string, any> | undefined;
/**
 * Redis Cluster node
 *
 * @schema N8NExternalRedisClusterNodes
 */
export interface N8NExternalRedisClusterNodes {
    /**
     * External Redis server host
     *
     * @schema N8NExternalRedisClusterNodes#host
     */
    readonly host: string;
    /**
     * External Redis server port
     *
     * @schema N8NExternalRedisClusterNodes#port
     */
    readonly port: number;
}
/**
 * Converts an object of type 'N8NExternalRedisClusterNodes' to JSON representation.
 */
export declare function toJson_N8NExternalRedisClusterNodes(obj: N8NExternalRedisClusterNodes | undefined): Record<string, any> | undefined;
/**
 * Placeholder for future Redis TLS certificates.
 *
 * @schema N8NExternalRedisTls
 */
export interface N8NExternalRedisTls {
    /**
     * Whether to enable TLS on Redis connections.
     *
     * @schema N8NExternalRedisTls#enabled
     */
    readonly enabled: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NExternalRedisTls#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NExternalRedisTls' to JSON representation.
 */
export declare function toJson_N8NExternalRedisTls(obj: N8NExternalRedisTls | undefined): Record<string, any> | undefined;
/**
 * @schema N8NLivenessProbeHttpGet
 */
export interface N8NLivenessProbeHttpGet {
    /**
     * @schema N8NLivenessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NLivenessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NLivenessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NLivenessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NLivenessProbeHttpGet(obj: N8NLivenessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * @schema N8NLogFile
 */
export interface N8NLogFile {
    /**
     * Location of the log files inside `~/.n8n`. Only for `file` log output.
     *
     * @schema N8NLogFile#location
     */
    readonly location: string;
    /**
     * Max number of log files to keep, or max number of days to keep logs for. Once the limit is reached, the oldest log files will be rotated out. If using days, append a `d` suffix. Only for `file` log output.
     *
     * @schema N8NLogFile#maxcount
     */
    readonly maxcount: string;
    /**
     * The maximum size (in MB) for each log file. By default, n8n uses 16 MB.
     *
     * @schema N8NLogFile#maxsize
     */
    readonly maxsize: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NLogFile#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NLogFile' to JSON representation.
 */
export declare function toJson_N8NLogFile(obj: N8NLogFile | undefined): Record<string, any> | undefined;
/**
 * The log output level. The available options are (from lowest to highest level) are error, warn, info, and debug. The default value is info. You can learn more about these options [here](https://docs.n8n.io/hosting/logging-monitoring/logging/#log-levels).
 *
 * @schema N8NLogLevel
 */
export declare enum N8NLogLevel {
    /** error */
    ERROR = "error",
    /** warn */
    WARN = "warn",
    /** info */
    INFO = "info",
    /** debug */
    DEBUG = "debug"
}
/**
 * @schema N8NLogOutput
 */
export declare enum N8NLogOutput {
    /** console */
    CONSOLE = "console",
    /** file */
    FILE = "file"
}
/**
 * @schema N8NLogScopes
 */
export declare enum N8NLogScopes {
    /** concurrency */
    CONCURRENCY = "concurrency",
    /** external-secrets */
    EXTERNAL_HYPHEN_SECRETS = "external-secrets",
    /** license */
    LICENSE = "license",
    /** multi-main-setup */
    MULTI_HYPHEN_MAIN_HYPHEN_SETUP = "multi-main-setup",
    /** pubsub */
    PUBSUB = "pubsub",
    /** redis */
    REDIS = "redis",
    /** scaling */
    SCALING = "scaling",
    /** waiting-executions */
    WAITING_HYPHEN_EXECUTIONS = "waiting-executions"
}
/**
 * Enable built-in node functions (e.g., HTTP Request, Code Node, etc.)
 *
 * @schema N8NNodesBuiltin
 */
export interface N8NNodesBuiltin {
    /**
     * Enable built-in modules for the Code node
     *
     * @schema N8NNodesBuiltin#enabled
     */
    readonly enabled?: boolean;
    /**
     * List of built-in Node.js modules to allow in the Code node (e.g., crypto, fs). Use '*' to allow all.
     *
     * @schema N8NNodesBuiltin#modules
     */
    readonly modules?: string[];
}
/**
 * Converts an object of type 'N8NNodesBuiltin' to JSON representation.
 */
export declare function toJson_N8NNodesBuiltin(obj: N8NNodesBuiltin | undefined): Record<string, any> | undefined;
/**
 * External npm packages to install and allow in the Code node
 *
 * @schema N8NNodesExternal
 */
export interface N8NNodesExternal {
    /**
     * Allow all external npm packages
     *
     * @schema N8NNodesExternal#allowAll
     */
    readonly allowAll: boolean;
    /**
     * Whether to reinstall missing packages. For more information, see https://docs.n8n.io/integrations/community-nodes/troubleshooting/#error-missing-packages
     *
     * @schema N8NNodesExternal#reinstallMissingPackages
     */
    readonly reinstallMissingPackages: boolean;
    /**
     * List of npm package names and versions (e.g., "package-name@1.0.0")
     *
     * @schema N8NNodesExternal#packages
     */
    readonly packages: string[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NNodesExternal#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NNodesExternal' to JSON representation.
 */
export declare function toJson_N8NNodesExternal(obj: N8NNodesExternal | undefined): Record<string, any> | undefined;
/**
 * Image for the init container to install npm packages
 *
 * @schema N8NNodesInitContainer
 */
export interface N8NNodesInitContainer {
    /**
     * Image for the init container to install npm packages
     *
     * @schema N8NNodesInitContainer#image
     */
    readonly image: N8NNodesInitContainerImage;
    /**
     * This block is for setting up the resource management for the init container more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
     *
     * @schema N8NNodesInitContainer#resources
     */
    readonly resources: N8NNodesInitContainerResources;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NNodesInitContainer#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NNodesInitContainer' to JSON representation.
 */
export declare function toJson_N8NNodesInitContainer(obj: N8NNodesInitContainer | undefined): Record<string, any> | undefined;
/**
 * The auto new license configuration
 *
 * @schema N8NLicenseAutoNenew
 */
export interface N8NLicenseAutoNenew {
    /**
     * Enables (true) or disables (false) autorenewal for licenses. If disabled, you need to manually renew the license every 10 days by navigating to Settings > Usage and plan, and pressing F5. Failure to renew the license will disable Enterprise features.
     *
     * @schema N8NLicenseAutoNenew#enabled
     */
    readonly enabled: boolean;
    /**
     * The offset in hours before expiry a license should automatically renew. The default value is 72 hours (3 days).
     *
     * @schema N8NLicenseAutoNenew#offsetInHours
     */
    readonly offsetInHours: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NLicenseAutoNenew#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NLicenseAutoNenew' to JSON representation.
 */
export declare function toJson_N8NLicenseAutoNenew(obj: N8NLicenseAutoNenew | undefined): Record<string, any> | undefined;
/**
 * PodDisruptionBudget configuration for the main node
 *
 * @schema N8NMainPdb
 */
export interface N8NMainPdb {
    /**
     * Whether to enable the PodDisruptionBudget for the main node
     *
     * @schema N8NMainPdb#enabled
     */
    readonly enabled: boolean;
    /**
     * Minimum number of available replicas for the main node
     *
     * @schema N8NMainPdb#minAvailable
     */
    readonly minAvailable?: any;
    /**
     * Maximum number of unavailable replicas for the main node
     *
     * @schema N8NMainPdb#maxUnavailable
     */
    readonly maxUnavailable?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainPdb#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainPdb' to JSON representation.
 */
export declare function toJson_N8NMainPdb(obj: N8NMainPdb | undefined): Record<string, any> | undefined;
/**
 * This block is for setting up the resource management for the pod more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
 *
 * @schema N8NMainResources
 */
export interface N8NMainResources {
    /**
     * @schema N8NMainResources#limits
     */
    readonly limits?: N8NMainResourcesLimits;
    /**
     * @schema N8NMainResources#requests
     */
    readonly requests?: N8NMainResourcesRequests;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainResources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainResources' to JSON representation.
 */
export declare function toJson_N8NMainResources(obj: N8NMainResources | undefined): Record<string, any> | undefined;
/**
 * This is to setup the liveness probe for the main pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NMainLivenessProbe
 */
export interface N8NMainLivenessProbe {
    /**
     * @schema N8NMainLivenessProbe#httpGet
     */
    readonly httpGet: N8NMainLivenessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainLivenessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainLivenessProbe' to JSON representation.
 */
export declare function toJson_N8NMainLivenessProbe(obj: N8NMainLivenessProbe | undefined): Record<string, any> | undefined;
/**
 * This is to setup the readiness probe for the main pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NMainReadinessProbe
 */
export interface N8NMainReadinessProbe {
    /**
     * @schema N8NMainReadinessProbe#httpGet
     */
    readonly httpGet: N8NMainReadinessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainReadinessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainReadinessProbe' to JSON representation.
 */
export declare function toJson_N8NMainReadinessProbe(obj: N8NMainReadinessProbe | undefined): Record<string, any> | undefined;
/**
 * Persistence configuration for the main pod
 *
 * @schema N8NMainPersistence
 */
export interface N8NMainPersistence {
    /**
     * Whether to enable persistence
     *
     * @schema N8NMainPersistence#enabled
     */
    readonly enabled: boolean;
    /**
     * Name of the volume to use for persistence
     *
     * @schema N8NMainPersistence#volumeName
     */
    readonly volumeName: string;
    /**
     * Existing claim to use for persistence
     *
     * @schema N8NMainPersistence#existingClaim
     */
    readonly existingClaim: string;
    /**
     * Mount path for persistence
     *
     * @schema N8NMainPersistence#mountPath
     */
    readonly mountPath: string;
    /**
     * Sub path for persistence
     *
     * @schema N8NMainPersistence#subPath
     */
    readonly subPath: string;
    /**
     * Storage class for persistence
     *
     * @schema N8NMainPersistence#storageClass
     */
    readonly storageClass: string;
    /**
     * Access mode for persistence
     *
     * @schema N8NMainPersistence#accessMode
     */
    readonly accessMode: N8NMainPersistenceAccessMode;
    /**
     * Size for persistence
     *
     * @schema N8NMainPersistence#size
     */
    readonly size: string;
    /**
     * Annotations for persistence
     *
     * @schema N8NMainPersistence#annotations
     */
    readonly annotations: any;
    /**
     * Labels for persistence
     *
     * @schema N8NMainPersistence#labels
     */
    readonly labels: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainPersistence#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainPersistence' to JSON representation.
 */
export declare function toJson_N8NMainPersistence(obj: N8NMainPersistence | undefined): Record<string, any> | undefined;
/**
 * @schema N8NMainHostAliases
 */
export interface N8NMainHostAliases {
    /**
     * IP address for the host alias
     *
     * @schema N8NMainHostAliases#ip
     */
    readonly ip: string;
    /**
     * List of hostnames to associate with the IP address
     *
     * @schema N8NMainHostAliases#hostnames
     */
    readonly hostnames: string[];
}
/**
 * Converts an object of type 'N8NMainHostAliases' to JSON representation.
 */
export declare function toJson_N8NMainHostAliases(obj: N8NMainHostAliases | undefined): Record<string, any> | undefined;
/**
 * @schema N8NPodSecurityContextFsGroupChangePolicy
 */
export declare enum N8NPodSecurityContextFsGroupChangePolicy {
    /** OnRootMismatch */
    ON_ROOT_MISMATCH = "OnRootMismatch",
    /** Always */
    ALWAYS = "Always"
}
/**
 * @schema N8NReadinessProbeHttpGet
 */
export interface N8NReadinessProbeHttpGet {
    /**
     * @schema N8NReadinessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NReadinessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NReadinessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NReadinessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NReadinessProbeHttpGet(obj: N8NReadinessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * @schema N8NResourcesLimits
 */
export interface N8NResourcesLimits {
    /**
     * @schema N8NResourcesLimits#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NResourcesLimits#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NResourcesLimits#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NResourcesLimits' to JSON representation.
 */
export declare function toJson_N8NResourcesLimits(obj: N8NResourcesLimits | undefined): Record<string, any> | undefined;
/**
 * @schema N8NResourcesRequests
 */
export interface N8NResourcesRequests {
    /**
     * @schema N8NResourcesRequests#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NResourcesRequests#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NResourcesRequests#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NResourcesRequests' to JSON representation.
 */
export declare function toJson_N8NResourcesRequests(obj: N8NResourcesRequests | undefined): Record<string, any> | undefined;
/**
 * @schema N8NSecurityContextCapabilities
 */
export interface N8NSecurityContextCapabilities {
    /**
     * @schema N8NSecurityContextCapabilities#drop
     */
    readonly drop?: any[];
    /**
     * @schema N8NSecurityContextCapabilities#add
     */
    readonly add?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NSecurityContextCapabilities#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NSecurityContextCapabilities' to JSON representation.
 */
export declare function toJson_N8NSecurityContextCapabilities(obj: N8NSecurityContextCapabilities | undefined): Record<string, any> | undefined;
/**
 * @schema N8NStrategyType
 */
export declare enum N8NStrategyType {
    /** RollingUpdate */
    ROLLING_UPDATE = "RollingUpdate",
    /** Recreate */
    RECREATE = "Recreate"
}
/**
 * Use `regular` to use main node as webhook node, or use `queue` to have webhook nodes
 *
 * @schema N8NWebhookMode
 */
export declare enum N8NWebhookMode {
    /** regular */
    REGULAR = "regular",
    /** queue */
    QUEUE = "queue"
}
/**
 * MCP webhook configuration. This is only used when the webhook mode is set to `queue` and the database type is set to `postgresdb`.
 *
 * @schema N8NWebhookMcp
 */
export interface N8NWebhookMcp {
    /**
     * Whether to enable MCP webhook
     *
     * @schema N8NWebhookMcp#enabled
     */
    readonly enabled: boolean;
    /**
     * This block is for setting up the resource management for the mcp webhook pod more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
     *
     * @schema N8NWebhookMcp#resources
     */
    readonly resources: N8NWebhookMcpResources;
    /**
     * This is to setup the startup probe for the mcp webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWebhookMcp#startupProbe
     */
    readonly startupProbe: N8NWebhookMcpStartupProbe;
    /**
     * This is to setup the liveness probe for the mcp webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWebhookMcp#livenessProbe
     */
    readonly livenessProbe: N8NWebhookMcpLivenessProbe;
    /**
     * This is to setup the readiness probe for the mcp webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
     *
     * @schema N8NWebhookMcp#readinessProbe
     */
    readonly readinessProbe: N8NWebhookMcpReadinessProbe;
    /**
     * Extra environment variables for the mcp webhook pod
     *
     * @schema N8NWebhookMcp#extraEnvVars
     */
    readonly extraEnvVars: any;
    /**
     * Extra secrets for environment variables for the mcp webhook pod
     *
     * @schema N8NWebhookMcp#extraSecretNamesForEnvFrom
     */
    readonly extraSecretNamesForEnvFrom: any[];
    /**
     * Additional volumes on the output Deployment definition for the mcp webhook pod.
     *
     * @schema N8NWebhookMcp#volumes
     */
    readonly volumes: any[];
    /**
     * Additional volumeMounts on the output Deployment definition for the mcp webhook pod.
     *
     * @schema N8NWebhookMcp#volumeMounts
     */
    readonly volumeMounts: any[];
    /**
     * Additional init containers for the mcp webhook pod
     *
     * @schema N8NWebhookMcp#initContainers
     */
    readonly initContainers: any[];
    /**
     * Additional containers for the mcp webhook pod
     *
     * @schema N8NWebhookMcp#extraContainers
     */
    readonly extraContainers: any[];
    /**
     * Webhook node affinity for the mcp webhook pod. For more information checkout: https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#affinity-and-anti-affinity
     *
     * @schema N8NWebhookMcp#affinity
     */
    readonly affinity: any;
    /**
     * Host aliases for the mcp webhook pod. For more information checkout: https://kubernetes.io/docs/tasks/network/customize-hosts-file-for-pods/#adding-additional-entries-with-hostaliases
     *
     * @schema N8NWebhookMcp#hostAliases
     */
    readonly hostAliases: N8NWebhookMcpHostAliases[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcp#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcp' to JSON representation.
 */
export declare function toJson_N8NWebhookMcp(obj: N8NWebhookMcp | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookAutoscaling
 */
export interface N8NWebhookAutoscaling {
    /**
     * If true, the number of workers will be automatically scaled based on default metrics. On default, it will scale based on CPU and memory. For more information can be found here: https://kubernetes.io/docs/concepts/workloads/autoscaling/
     *
     * @schema N8NWebhookAutoscaling#enabled
     */
    readonly enabled: boolean;
    /**
     * Minimum number of workers
     *
     * @schema N8NWebhookAutoscaling#minReplicas
     */
    readonly minReplicas: number;
    /**
     * Maximum number of workers
     *
     * @schema N8NWebhookAutoscaling#maxReplicas
     */
    readonly maxReplicas: number;
    /**
     * @schema N8NWebhookAutoscaling#metrics
     */
    readonly metrics: N8NWebhookAutoscalingMetrics[];
    /**
     * @schema N8NWebhookAutoscaling#behavior
     */
    readonly behavior: N8NWebhookAutoscalingBehavior;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookAutoscaling#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookAutoscaling' to JSON representation.
 */
export declare function toJson_N8NWebhookAutoscaling(obj: N8NWebhookAutoscaling | undefined): Record<string, any> | undefined;
/**
 * PodDisruptionBudget configuration for the worker node
 *
 * @schema N8NWebhookPdb
 */
export interface N8NWebhookPdb {
    /**
     * Whether to enable the PodDisruptionBudget for the worker node
     *
     * @schema N8NWebhookPdb#enabled
     */
    readonly enabled: boolean;
    /**
     * Minimum number of available replicas for the worker node
     *
     * @schema N8NWebhookPdb#minAvailable
     */
    readonly minAvailable?: any;
    /**
     * Maximum number of unavailable replicas for the worker node
     *
     * @schema N8NWebhookPdb#maxUnavailable
     */
    readonly maxUnavailable?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookPdb#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookPdb' to JSON representation.
 */
export declare function toJson_N8NWebhookPdb(obj: N8NWebhookPdb | undefined): Record<string, any> | undefined;
/**
 * This is to setup the wait for the main node to be ready.
 *
 * @schema N8NWebhookWaitMainNodeReady
 */
export interface N8NWebhookWaitMainNodeReady {
    /**
     * Whether to enable the wait for the main node to be ready.
     *
     * @schema N8NWebhookWaitMainNodeReady#enabled
     */
    readonly enabled: boolean;
    /**
     * The schema to use for request to the main node. On default, it will use identify the schema from the main N8N_PROTOCOL environment variable or use http.
     *
     * @schema N8NWebhookWaitMainNodeReady#overwriteSchema
     */
    readonly overwriteSchema: string;
    /**
     * The URL to use for request to the main node. On default, it will use service name and port.
     *
     * @schema N8NWebhookWaitMainNodeReady#overwriteUrl
     */
    readonly overwriteUrl: string;
    /**
     * The health check path to use for request to the main node.
     *
     * @schema N8NWebhookWaitMainNodeReady#healthCheckPath
     */
    readonly healthCheckPath: string;
    /**
     * The additional parameters to use part of wget command. e.g. --no-check-certificate
     *
     * @schema N8NWebhookWaitMainNodeReady#additionalParameters
     */
    readonly additionalParameters: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookWaitMainNodeReady#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookWaitMainNodeReady' to JSON representation.
 */
export declare function toJson_N8NWebhookWaitMainNodeReady(obj: N8NWebhookWaitMainNodeReady | undefined): Record<string, any> | undefined;
/**
 * This block is for setting up the resource management for the pod more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
 *
 * @schema N8NWebhookResources
 */
export interface N8NWebhookResources {
    /**
     * @schema N8NWebhookResources#limits
     */
    readonly limits?: N8NWebhookResourcesLimits;
    /**
     * @schema N8NWebhookResources#requests
     */
    readonly requests?: N8NWebhookResourcesRequests;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookResources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookResources' to JSON representation.
 */
export declare function toJson_N8NWebhookResources(obj: N8NWebhookResources | undefined): Record<string, any> | undefined;
/**
 * This is to setup the startup probe for the webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWebhookStartupProbe
 */
export interface N8NWebhookStartupProbe {
    /**
     * @schema N8NWebhookStartupProbe#exec
     */
    readonly exec?: N8NWebhookStartupProbeExec;
    /**
     * @schema N8NWebhookStartupProbe#initialDelaySeconds
     */
    readonly initialDelaySeconds?: number;
    /**
     * @schema N8NWebhookStartupProbe#periodSeconds
     */
    readonly periodSeconds?: number;
    /**
     * @schema N8NWebhookStartupProbe#failureThreshold
     */
    readonly failureThreshold?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookStartupProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookStartupProbe' to JSON representation.
 */
export declare function toJson_N8NWebhookStartupProbe(obj: N8NWebhookStartupProbe | undefined): Record<string, any> | undefined;
/**
 * This is to setup the liveness probe for the webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWebhookLivenessProbe
 */
export interface N8NWebhookLivenessProbe {
    /**
     * @schema N8NWebhookLivenessProbe#httpGet
     */
    readonly httpGet: N8NWebhookLivenessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookLivenessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookLivenessProbe' to JSON representation.
 */
export declare function toJson_N8NWebhookLivenessProbe(obj: N8NWebhookLivenessProbe | undefined): Record<string, any> | undefined;
/**
 * This is to setup the readiness probe for the webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWebhookReadinessProbe
 */
export interface N8NWebhookReadinessProbe {
    /**
     * @schema N8NWebhookReadinessProbe#httpGet
     */
    readonly httpGet: N8NWebhookReadinessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookReadinessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookReadinessProbe' to JSON representation.
 */
export declare function toJson_N8NWebhookReadinessProbe(obj: N8NWebhookReadinessProbe | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookHostAliases
 */
export interface N8NWebhookHostAliases {
    /**
     * IP address for the host alias
     *
     * @schema N8NWebhookHostAliases#ip
     */
    readonly ip: string;
    /**
     * List of hostnames to associate with the IP address
     *
     * @schema N8NWebhookHostAliases#hostnames
     */
    readonly hostnames: string[];
}
/**
 * Converts an object of type 'N8NWebhookHostAliases' to JSON representation.
 */
export declare function toJson_N8NWebhookHostAliases(obj: N8NWebhookHostAliases | undefined): Record<string, any> | undefined;
/**
 * Use `regular` to use main node as executer, or use `queue` to have worker nodes
 *
 * @schema N8NWorkerMode
 */
export declare enum N8NWorkerMode {
    /** regular */
    REGULAR = "regular",
    /** queue */
    QUEUE = "queue"
}
/**
 * @schema N8NWorkerAutoscaling
 */
export interface N8NWorkerAutoscaling {
    /**
     * If true, the number of workers will be automatically scaled based on default metrics. On default, it will scale based on CPU and memory. For more information can be found here: https://kubernetes.io/docs/concepts/workloads/autoscaling/
     *
     * @schema N8NWorkerAutoscaling#enabled
     */
    readonly enabled: boolean;
    /**
     * Minimum number of workers
     *
     * @schema N8NWorkerAutoscaling#minReplicas
     */
    readonly minReplicas: number;
    /**
     * Maximum number of workers
     *
     * @schema N8NWorkerAutoscaling#maxReplicas
     */
    readonly maxReplicas: number;
    /**
     * @schema N8NWorkerAutoscaling#metrics
     */
    readonly metrics: N8NWorkerAutoscalingMetrics[];
    /**
     * @schema N8NWorkerAutoscaling#behavior
     */
    readonly behavior: N8NWorkerAutoscalingBehavior;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerAutoscaling#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerAutoscaling' to JSON representation.
 */
export declare function toJson_N8NWorkerAutoscaling(obj: N8NWorkerAutoscaling | undefined): Record<string, any> | undefined;
/**
 * PodDisruptionBudget configuration for the worker node
 *
 * @schema N8NWorkerPdb
 */
export interface N8NWorkerPdb {
    /**
     * Whether to enable the PodDisruptionBudget for the worker node
     *
     * @schema N8NWorkerPdb#enabled
     */
    readonly enabled: boolean;
    /**
     * Minimum number of available replicas for the worker node
     *
     * @schema N8NWorkerPdb#minAvailable
     */
    readonly minAvailable?: any;
    /**
     * Maximum number of unavailable replicas for the worker node
     *
     * @schema N8NWorkerPdb#maxUnavailable
     */
    readonly maxUnavailable?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerPdb#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerPdb' to JSON representation.
 */
export declare function toJson_N8NWorkerPdb(obj: N8NWorkerPdb | undefined): Record<string, any> | undefined;
/**
 * This is to setup the wait for the main node to be ready.
 *
 * @schema N8NWorkerWaitMainNodeReady
 */
export interface N8NWorkerWaitMainNodeReady {
    /**
     * Whether to enable the wait for the main node to be ready.
     *
     * @schema N8NWorkerWaitMainNodeReady#enabled
     */
    readonly enabled: boolean;
    /**
     * The schema to use for request to the main node. On default, it will use identify the schema from the main N8N_PROTOCOL environment variable or use http.
     *
     * @schema N8NWorkerWaitMainNodeReady#overwriteSchema
     */
    readonly overwriteSchema: string;
    /**
     * The URL to use for request to the main node. On default, it will use service name and port.
     *
     * @schema N8NWorkerWaitMainNodeReady#overwriteUrl
     */
    readonly overwriteUrl: string;
    /**
     * The health check path to use for request to the main node.
     *
     * @schema N8NWorkerWaitMainNodeReady#healthCheckPath
     */
    readonly healthCheckPath: string;
    /**
     * The additional parameters to use part of wget command. e.g. --no-check-certificate
     *
     * @schema N8NWorkerWaitMainNodeReady#additionalParameters
     */
    readonly additionalParameters: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerWaitMainNodeReady#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerWaitMainNodeReady' to JSON representation.
 */
export declare function toJson_N8NWorkerWaitMainNodeReady(obj: N8NWorkerWaitMainNodeReady | undefined): Record<string, any> | undefined;
/**
 * This block is for setting up the resource management for the pod more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
 *
 * @schema N8NWorkerResources
 */
export interface N8NWorkerResources {
    /**
     * @schema N8NWorkerResources#limits
     */
    readonly limits?: N8NWorkerResourcesLimits;
    /**
     * @schema N8NWorkerResources#requests
     */
    readonly requests?: N8NWorkerResourcesRequests;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerResources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerResources' to JSON representation.
 */
export declare function toJson_N8NWorkerResources(obj: N8NWorkerResources | undefined): Record<string, any> | undefined;
/**
 * This is to setup the startup probe for the worker pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWorkerStartupProbe
 */
export interface N8NWorkerStartupProbe {
    /**
     * @schema N8NWorkerStartupProbe#exec
     */
    readonly exec?: N8NWorkerStartupProbeExec;
    /**
     * @schema N8NWorkerStartupProbe#initialDelaySeconds
     */
    readonly initialDelaySeconds?: number;
    /**
     * @schema N8NWorkerStartupProbe#periodSeconds
     */
    readonly periodSeconds?: number;
    /**
     * @schema N8NWorkerStartupProbe#failureThreshold
     */
    readonly failureThreshold?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerStartupProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerStartupProbe' to JSON representation.
 */
export declare function toJson_N8NWorkerStartupProbe(obj: N8NWorkerStartupProbe | undefined): Record<string, any> | undefined;
/**
 * This is to setup the liveness probe for the worker pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWorkerLivenessProbe
 */
export interface N8NWorkerLivenessProbe {
    /**
     * @schema N8NWorkerLivenessProbe#httpGet
     */
    readonly httpGet: N8NWorkerLivenessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerLivenessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerLivenessProbe' to JSON representation.
 */
export declare function toJson_N8NWorkerLivenessProbe(obj: N8NWorkerLivenessProbe | undefined): Record<string, any> | undefined;
/**
 * This is to setup the readiness probe for the worker pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWorkerReadinessProbe
 */
export interface N8NWorkerReadinessProbe {
    /**
     * @schema N8NWorkerReadinessProbe#httpGet
     */
    readonly httpGet: N8NWorkerReadinessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerReadinessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerReadinessProbe' to JSON representation.
 */
export declare function toJson_N8NWorkerReadinessProbe(obj: N8NWorkerReadinessProbe | undefined): Record<string, any> | undefined;
/**
 * Persistence configuration for the worker pod
 *
 * @schema N8NWorkerPersistence
 */
export interface N8NWorkerPersistence {
    /**
     * Whether to enable persistence
     *
     * @schema N8NWorkerPersistence#enabled
     */
    readonly enabled: boolean;
    /**
     * Name of the volume to use for persistence
     *
     * @schema N8NWorkerPersistence#volumeName
     */
    readonly volumeName: string;
    /**
     * Existing claim to use for persistence
     *
     * @schema N8NWorkerPersistence#existingClaim
     */
    readonly existingClaim: string;
    /**
     * Mount path for persistence
     *
     * @schema N8NWorkerPersistence#mountPath
     */
    readonly mountPath: string;
    /**
     * Sub path for persistence
     *
     * @schema N8NWorkerPersistence#subPath
     */
    readonly subPath: string;
    /**
     * Storage class for persistence
     *
     * @schema N8NWorkerPersistence#storageClass
     */
    readonly storageClass: string;
    /**
     * Access mode for persistence
     *
     * @schema N8NWorkerPersistence#accessMode
     */
    readonly accessMode: N8NWorkerPersistenceAccessMode;
    /**
     * Size for persistence
     *
     * @schema N8NWorkerPersistence#size
     */
    readonly size: string;
    /**
     * Annotations for persistence
     *
     * @schema N8NWorkerPersistence#annotations
     */
    readonly annotations: any;
    /**
     * Labels for persistence
     *
     * @schema N8NWorkerPersistence#labels
     */
    readonly labels: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerPersistence#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerPersistence' to JSON representation.
 */
export declare function toJson_N8NWorkerPersistence(obj: N8NWorkerPersistence | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerHostAliases
 */
export interface N8NWorkerHostAliases {
    /**
     * IP address for the host alias
     *
     * @schema N8NWorkerHostAliases#ip
     */
    readonly ip: string;
    /**
     * List of hostnames to associate with the IP address
     *
     * @schema N8NWorkerHostAliases#hostnames
     */
    readonly hostnames: string[];
}
/**
 * Converts an object of type 'N8NWorkerHostAliases' to JSON representation.
 */
export declare function toJson_N8NWorkerHostAliases(obj: N8NWorkerHostAliases | undefined): Record<string, any> | undefined;
/**
 * Use `internal` to use internal task runner, or use `external` to have external sidecar task runner
 *
 * @schema N8NTaskRunnersMode
 */
export declare enum N8NTaskRunnersMode {
    /** internal */
    INTERNAL = "internal",
    /** external */
    EXTERNAL = "external"
}
/**
 * @schema N8NTaskRunnersBroker
 */
export interface N8NTaskRunnersBroker {
    /**
     * This sets the address for the broker of the external task runner
     *
     * @schema N8NTaskRunnersBroker#address
     */
    readonly address: string;
    /**
     * This sets the port for the broker of the external task runner
     *
     * @schema N8NTaskRunnersBroker#port
     */
    readonly port: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NTaskRunnersBroker#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NTaskRunnersBroker' to JSON representation.
 */
export declare function toJson_N8NTaskRunnersBroker(obj: N8NTaskRunnersBroker | undefined): Record<string, any> | undefined;
/**
 * @schema N8NTaskRunnersExternal
 */
export interface N8NTaskRunnersExternal {
    /**
     * This sets the auth token for the n8n main node of the external task runner
     *
     * @schema N8NTaskRunnersExternal#mainNodeAuthToken
     */
    readonly mainNodeAuthToken?: string;
    /**
     * This sets the auth token for the n8n worker node of the external task runner
     *
     * @schema N8NTaskRunnersExternal#workerNodeAuthToken
     */
    readonly workerNodeAuthToken?: string;
    /**
     * This sets the auto shutdown timeout for the external task runner in seconds
     *
     * @schema N8NTaskRunnersExternal#autoShutdownTimeout
     */
    readonly autoShutdownTimeout: number;
    /**
     * This sets the ports for the external task runner more information can be found here: https://kubernetes.io/docs/concepts/services-networking/service/#field-spec-ports
     *
     * @schema N8NTaskRunnersExternal#port
     */
    readonly port: number;
    /**
     * This sets the node options for the external task runner
     *
     * @schema N8NTaskRunnersExternal#nodeOptions
     */
    readonly nodeOptions: string[];
    /**
     * @schema N8NTaskRunnersExternal#resources
     */
    readonly resources: N8NTaskRunnersExternalResources;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NTaskRunnersExternal#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NTaskRunnersExternal' to JSON representation.
 */
export declare function toJson_N8NTaskRunnersExternal(obj: N8NTaskRunnersExternal | undefined): Record<string, any> | undefined;
/**
 * @schema N8NServiceMonitorMetricRelabelings
 */
export interface N8NServiceMonitorMetricRelabelings {
    /**
     * The source labels to relabel from
     *
     * @schema N8NServiceMonitorMetricRelabelings#sourceLabels
     */
    readonly sourceLabels?: string[];
    /**
     * The regular expression to match against source labels
     *
     * @schema N8NServiceMonitorMetricRelabelings#regex
     */
    readonly regex?: string;
    /**
     * The label to write the result to
     *
     * @schema N8NServiceMonitorMetricRelabelings#targetLabel
     */
    readonly targetLabel?: string;
    /**
     * The relabeling action to perform
     *
     * @schema N8NServiceMonitorMetricRelabelings#action
     */
    readonly action: N8NServiceMonitorMetricRelabelingsAction;
    /**
     * Separator used when concatenating source labels
     *
     * @schema N8NServiceMonitorMetricRelabelings#separator
     */
    readonly separator?: string;
    /**
     * Modulus to use with hashmod action
     *
     * @schema N8NServiceMonitorMetricRelabelings#modulus
     */
    readonly modulus?: number;
    /**
     * Replacement value for the 'replace' action
     *
     * @schema N8NServiceMonitorMetricRelabelings#replacement
     */
    readonly replacement?: string;
}
/**
 * Converts an object of type 'N8NServiceMonitorMetricRelabelings' to JSON representation.
 */
export declare function toJson_N8NServiceMonitorMetricRelabelings(obj: N8NServiceMonitorMetricRelabelings | undefined): Record<string, any> | undefined;
/**
 * Metrics and labels to include in the ServiceMonitor
 *
 * @schema N8NServiceMonitorInclude
 */
export interface N8NServiceMonitorInclude {
    /**
     * Whether to include default metrics
     *
     * @schema N8NServiceMonitorInclude#defaultMetrics
     */
    readonly defaultMetrics: boolean;
    /**
     * Whether to include cache metrics
     *
     * @schema N8NServiceMonitorInclude#cacheMetrics
     */
    readonly cacheMetrics: boolean;
    /**
     * Whether to include message event bus metrics
     *
     * @schema N8NServiceMonitorInclude#messageEventBusMetrics
     */
    readonly messageEventBusMetrics: boolean;
    /**
     * Whether to include workflow id label
     *
     * @schema N8NServiceMonitorInclude#workflowIdLabel
     */
    readonly workflowIdLabel: boolean;
    /**
     * Whether to include node type label
     *
     * @schema N8NServiceMonitorInclude#nodeTypeLabel
     */
    readonly nodeTypeLabel: boolean;
    /**
     * Whether to include credential type label
     *
     * @schema N8NServiceMonitorInclude#credentialTypeLabel
     */
    readonly credentialTypeLabel: boolean;
    /**
     * Whether to include api endpoints
     *
     * @schema N8NServiceMonitorInclude#apiEndpoints
     */
    readonly apiEndpoints: boolean;
    /**
     * Whether to include api path label
     *
     * @schema N8NServiceMonitorInclude#apiPathLabel
     */
    readonly apiPathLabel: boolean;
    /**
     * Whether to include api method label
     *
     * @schema N8NServiceMonitorInclude#apiMethodLabel
     */
    readonly apiMethodLabel: boolean;
    /**
     * Whether to include api status code label
     *
     * @schema N8NServiceMonitorInclude#apiStatusCodeLabel
     */
    readonly apiStatusCodeLabel: boolean;
    /**
     * Whether to include queue metrics
     *
     * @schema N8NServiceMonitorInclude#queueMetrics
     */
    readonly queueMetrics: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NServiceMonitorInclude#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NServiceMonitorInclude' to JSON representation.
 */
export declare function toJson_N8NServiceMonitorInclude(obj: N8NServiceMonitorInclude | undefined): Record<string, any> | undefined;
/**
 * A DNS option object.
 *
 * @schema N8NDnsConfigOptions
 */
export interface N8NDnsConfigOptions {
    /**
     * Name of the DNS option.
     *
     * @schema N8NDnsConfigOptions#name
     */
    readonly name: string;
    /**
     * Value of the DNS option (optional).
     *
     * @schema N8NDnsConfigOptions#value
     */
    readonly value?: string;
}
/**
 * Converts an object of type 'N8NDnsConfigOptions' to JSON representation.
 */
export declare function toJson_N8NDnsConfigOptions(obj: N8NDnsConfigOptions | undefined): Record<string, any> | undefined;
/**
 * Database logging level. Requires `maxQueryExecutionTime` to be higher than `0`. Valid values 'query' | 'error' | 'schema' | 'warn' | 'info' | 'log' | 'all'
 *
 * @schema N8NDbLoggingOptions
 */
export declare enum N8NDbLoggingOptions {
    /** query */
    QUERY = "query",
    /** error */
    ERROR = "error",
    /** schema */
    SCHEMA = "schema",
    /** warn */
    WARN = "warn",
    /** info */
    INFO = "info",
    /** log */
    LOG = "log",
    /** all */
    ALL = "all"
}
/**
 * The PostgreSQL connection SSL settings. Find more information from here: https://docs.n8n.io/hosting/configuration/supported-databases-settings/#postgresdb
 *
 * @schema N8NDbPostgresdbSsl
 */
export interface N8NDbPostgresdbSsl {
    /**
     * Whether to enable SSL.
     *
     * @schema N8NDbPostgresdbSsl#enabled
     */
    readonly enabled: boolean;
    /**
     * The PostgreSQL base64 encoded version of SSL certificate authority file content.
     *
     * @schema N8NDbPostgresdbSsl#base64EncodedCertificateAuthorityFile
     */
    readonly base64EncodedCertificateAuthorityFile: string;
    /**
     * The PostgreSQL base64 encoded version of SSL certificate file content.
     *
     * @schema N8NDbPostgresdbSsl#base64EncodedCertFile
     */
    readonly base64EncodedCertFile: string;
    /**
     * The PostgreSQL base64 encoded version of SSL private key file content.
     *
     * @schema N8NDbPostgresdbSsl#base64EncodedPrivateKeyFile
     */
    readonly base64EncodedPrivateKeyFile: string;
    /**
     * The PostgreSQL existing certificate authority file secret.
     *
     * @schema N8NDbPostgresdbSsl#existingCertificateAuthorityFileSecret
     */
    readonly existingCertificateAuthorityFileSecret: N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret;
    /**
     * The PostgreSQL existing certificate file secret.
     *
     * @schema N8NDbPostgresdbSsl#existingCertFileSecret
     */
    readonly existingCertFileSecret: N8NDbPostgresdbSslExistingCertFileSecret;
    /**
     * The PostgreSQL existing SSL private key file secret.
     *
     * @schema N8NDbPostgresdbSsl#existingPrivateKeyFileSecret
     */
    readonly existingPrivateKeyFileSecret: N8NDbPostgresdbSslExistingPrivateKeyFileSecret;
    /**
     * If n8n should reject unauthorized SSL connections (true) or not (false).
     *
     * @schema N8NDbPostgresdbSsl#rejectUnauthorized
     */
    readonly rejectUnauthorized: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDbPostgresdbSsl#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDbPostgresdbSsl' to JSON representation.
 */
export declare function toJson_N8NDbPostgresdbSsl(obj: N8NDbPostgresdbSsl | undefined): Record<string, any> | undefined;
/**
 * Image for the init container to install npm packages
 *
 * @schema N8NNodesInitContainerImage
 */
export interface N8NNodesInitContainerImage {
    /**
     * Repository for the init container to install npm packages
     *
     * @schema N8NNodesInitContainerImage#repository
     */
    readonly repository: string;
    /**
     * Tag for the init container to install npm packages
     *
     * @schema N8NNodesInitContainerImage#tag
     */
    readonly tag: string;
    /**
     * Pull policy for the init container to install npm packages
     *
     * @schema N8NNodesInitContainerImage#pullPolicy
     */
    readonly pullPolicy: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NNodesInitContainerImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NNodesInitContainerImage' to JSON representation.
 */
export declare function toJson_N8NNodesInitContainerImage(obj: N8NNodesInitContainerImage | undefined): Record<string, any> | undefined;
/**
 * This block is for setting up the resource management for the init container more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
 *
 * @schema N8NNodesInitContainerResources
 */
export interface N8NNodesInitContainerResources {
    /**
     * This block is for setting up the resource management for the init container more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
     *
     * @schema N8NNodesInitContainerResources#limits
     */
    readonly limits?: N8NNodesInitContainerResourcesLimits;
    /**
     * This block is for setting up the resource management for the init container more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
     *
     * @schema N8NNodesInitContainerResources#requests
     */
    readonly requests?: N8NNodesInitContainerResourcesRequests;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NNodesInitContainerResources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NNodesInitContainerResources' to JSON representation.
 */
export declare function toJson_N8NNodesInitContainerResources(obj: N8NNodesInitContainerResources | undefined): Record<string, any> | undefined;
/**
 * @schema N8NMainResourcesLimits
 */
export interface N8NMainResourcesLimits {
    /**
     * @schema N8NMainResourcesLimits#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NMainResourcesLimits#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainResourcesLimits#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainResourcesLimits' to JSON representation.
 */
export declare function toJson_N8NMainResourcesLimits(obj: N8NMainResourcesLimits | undefined): Record<string, any> | undefined;
/**
 * @schema N8NMainResourcesRequests
 */
export interface N8NMainResourcesRequests {
    /**
     * @schema N8NMainResourcesRequests#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NMainResourcesRequests#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainResourcesRequests#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainResourcesRequests' to JSON representation.
 */
export declare function toJson_N8NMainResourcesRequests(obj: N8NMainResourcesRequests | undefined): Record<string, any> | undefined;
/**
 * @schema N8NMainLivenessProbeHttpGet
 */
export interface N8NMainLivenessProbeHttpGet {
    /**
     * @schema N8NMainLivenessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NMainLivenessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainLivenessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainLivenessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NMainLivenessProbeHttpGet(obj: N8NMainLivenessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * @schema N8NMainReadinessProbeHttpGet
 */
export interface N8NMainReadinessProbeHttpGet {
    /**
     * @schema N8NMainReadinessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NMainReadinessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NMainReadinessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NMainReadinessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NMainReadinessProbeHttpGet(obj: N8NMainReadinessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * Access mode for persistence
 *
 * @schema N8NMainPersistenceAccessMode
 */
export declare enum N8NMainPersistenceAccessMode {
    /** ReadWriteOnce */
    READ_WRITE_ONCE = "ReadWriteOnce",
    /** ReadWriteMany */
    READ_WRITE_MANY = "ReadWriteMany"
}
/**
 * This block is for setting up the resource management for the mcp webhook pod more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
 *
 * @schema N8NWebhookMcpResources
 */
export interface N8NWebhookMcpResources {
    /**
     * @schema N8NWebhookMcpResources#limits
     */
    readonly limits?: N8NWebhookMcpResourcesLimits;
    /**
     * @schema N8NWebhookMcpResources#requests
     */
    readonly requests?: N8NWebhookMcpResourcesRequests;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpResources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpResources' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpResources(obj: N8NWebhookMcpResources | undefined): Record<string, any> | undefined;
/**
 * This is to setup the startup probe for the mcp webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWebhookMcpStartupProbe
 */
export interface N8NWebhookMcpStartupProbe {
    /**
     * @schema N8NWebhookMcpStartupProbe#exec
     */
    readonly exec?: N8NWebhookMcpStartupProbeExec;
    /**
     * @schema N8NWebhookMcpStartupProbe#initialDelaySeconds
     */
    readonly initialDelaySeconds?: number;
    /**
     * @schema N8NWebhookMcpStartupProbe#periodSeconds
     */
    readonly periodSeconds?: number;
    /**
     * @schema N8NWebhookMcpStartupProbe#failureThreshold
     */
    readonly failureThreshold?: number;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpStartupProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpStartupProbe' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpStartupProbe(obj: N8NWebhookMcpStartupProbe | undefined): Record<string, any> | undefined;
/**
 * This is to setup the liveness probe for the mcp webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWebhookMcpLivenessProbe
 */
export interface N8NWebhookMcpLivenessProbe {
    /**
     * @schema N8NWebhookMcpLivenessProbe#httpGet
     */
    readonly httpGet: N8NWebhookMcpLivenessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpLivenessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpLivenessProbe' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpLivenessProbe(obj: N8NWebhookMcpLivenessProbe | undefined): Record<string, any> | undefined;
/**
 * This is to setup the readiness probe for the mcp webhook pod more information can be found here: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
 *
 * @schema N8NWebhookMcpReadinessProbe
 */
export interface N8NWebhookMcpReadinessProbe {
    /**
     * @schema N8NWebhookMcpReadinessProbe#httpGet
     */
    readonly httpGet: N8NWebhookMcpReadinessProbeHttpGet;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpReadinessProbe#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpReadinessProbe' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpReadinessProbe(obj: N8NWebhookMcpReadinessProbe | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookMcpHostAliases
 */
export interface N8NWebhookMcpHostAliases {
    /**
     * IP address for the host alias
     *
     * @schema N8NWebhookMcpHostAliases#ip
     */
    readonly ip: string;
    /**
     * List of hostnames to associate with the IP address
     *
     * @schema N8NWebhookMcpHostAliases#hostnames
     */
    readonly hostnames: string[];
}
/**
 * Converts an object of type 'N8NWebhookMcpHostAliases' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpHostAliases(obj: N8NWebhookMcpHostAliases | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookAutoscalingMetrics
 */
export interface N8NWebhookAutoscalingMetrics {
    /**
     * @schema N8NWebhookAutoscalingMetrics#type
     */
    readonly type: N8NWebhookAutoscalingMetricsType;
}
/**
 * Converts an object of type 'N8NWebhookAutoscalingMetrics' to JSON representation.
 */
export declare function toJson_N8NWebhookAutoscalingMetrics(obj: N8NWebhookAutoscalingMetrics | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookAutoscalingBehavior
 */
export interface N8NWebhookAutoscalingBehavior {
    /**
     * @schema N8NWebhookAutoscalingBehavior#scaleUp
     */
    readonly scaleUp?: N8NWebhookAutoscalingBehaviorScaleUp;
    /**
     * @schema N8NWebhookAutoscalingBehavior#scaleDown
     */
    readonly scaleDown?: N8NWebhookAutoscalingBehaviorScaleDown;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookAutoscalingBehavior#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookAutoscalingBehavior' to JSON representation.
 */
export declare function toJson_N8NWebhookAutoscalingBehavior(obj: N8NWebhookAutoscalingBehavior | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookResourcesLimits
 */
export interface N8NWebhookResourcesLimits {
    /**
     * @schema N8NWebhookResourcesLimits#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NWebhookResourcesLimits#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookResourcesLimits#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookResourcesLimits' to JSON representation.
 */
export declare function toJson_N8NWebhookResourcesLimits(obj: N8NWebhookResourcesLimits | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookResourcesRequests
 */
export interface N8NWebhookResourcesRequests {
    /**
     * @schema N8NWebhookResourcesRequests#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NWebhookResourcesRequests#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookResourcesRequests#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookResourcesRequests' to JSON representation.
 */
export declare function toJson_N8NWebhookResourcesRequests(obj: N8NWebhookResourcesRequests | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookStartupProbeExec
 */
export interface N8NWebhookStartupProbeExec {
    /**
     * @schema N8NWebhookStartupProbeExec#command
     */
    readonly command: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookStartupProbeExec#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookStartupProbeExec' to JSON representation.
 */
export declare function toJson_N8NWebhookStartupProbeExec(obj: N8NWebhookStartupProbeExec | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookLivenessProbeHttpGet
 */
export interface N8NWebhookLivenessProbeHttpGet {
    /**
     * @schema N8NWebhookLivenessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NWebhookLivenessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookLivenessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookLivenessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NWebhookLivenessProbeHttpGet(obj: N8NWebhookLivenessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookReadinessProbeHttpGet
 */
export interface N8NWebhookReadinessProbeHttpGet {
    /**
     * @schema N8NWebhookReadinessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NWebhookReadinessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookReadinessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookReadinessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NWebhookReadinessProbeHttpGet(obj: N8NWebhookReadinessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerAutoscalingMetrics
 */
export interface N8NWorkerAutoscalingMetrics {
    /**
     * @schema N8NWorkerAutoscalingMetrics#type
     */
    readonly type: N8NWorkerAutoscalingMetricsType;
}
/**
 * Converts an object of type 'N8NWorkerAutoscalingMetrics' to JSON representation.
 */
export declare function toJson_N8NWorkerAutoscalingMetrics(obj: N8NWorkerAutoscalingMetrics | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerAutoscalingBehavior
 */
export interface N8NWorkerAutoscalingBehavior {
    /**
     * @schema N8NWorkerAutoscalingBehavior#scaleUp
     */
    readonly scaleUp?: N8NWorkerAutoscalingBehaviorScaleUp;
    /**
     * @schema N8NWorkerAutoscalingBehavior#scaleDown
     */
    readonly scaleDown?: N8NWorkerAutoscalingBehaviorScaleDown;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerAutoscalingBehavior#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerAutoscalingBehavior' to JSON representation.
 */
export declare function toJson_N8NWorkerAutoscalingBehavior(obj: N8NWorkerAutoscalingBehavior | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerResourcesLimits
 */
export interface N8NWorkerResourcesLimits {
    /**
     * @schema N8NWorkerResourcesLimits#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NWorkerResourcesLimits#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerResourcesLimits#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerResourcesLimits' to JSON representation.
 */
export declare function toJson_N8NWorkerResourcesLimits(obj: N8NWorkerResourcesLimits | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerResourcesRequests
 */
export interface N8NWorkerResourcesRequests {
    /**
     * @schema N8NWorkerResourcesRequests#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NWorkerResourcesRequests#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerResourcesRequests#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerResourcesRequests' to JSON representation.
 */
export declare function toJson_N8NWorkerResourcesRequests(obj: N8NWorkerResourcesRequests | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerStartupProbeExec
 */
export interface N8NWorkerStartupProbeExec {
    /**
     * @schema N8NWorkerStartupProbeExec#command
     */
    readonly command: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerStartupProbeExec#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerStartupProbeExec' to JSON representation.
 */
export declare function toJson_N8NWorkerStartupProbeExec(obj: N8NWorkerStartupProbeExec | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerLivenessProbeHttpGet
 */
export interface N8NWorkerLivenessProbeHttpGet {
    /**
     * @schema N8NWorkerLivenessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NWorkerLivenessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerLivenessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerLivenessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NWorkerLivenessProbeHttpGet(obj: N8NWorkerLivenessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerReadinessProbeHttpGet
 */
export interface N8NWorkerReadinessProbeHttpGet {
    /**
     * @schema N8NWorkerReadinessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NWorkerReadinessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerReadinessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerReadinessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NWorkerReadinessProbeHttpGet(obj: N8NWorkerReadinessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * Access mode for persistence
 *
 * @schema N8NWorkerPersistenceAccessMode
 */
export declare enum N8NWorkerPersistenceAccessMode {
    /** ReadWriteOnce */
    READ_WRITE_ONCE = "ReadWriteOnce",
    /** ReadWriteMany */
    READ_WRITE_MANY = "ReadWriteMany"
}
/**
 * @schema N8NTaskRunnersExternalResources
 */
export interface N8NTaskRunnersExternalResources {
    /**
     * @schema N8NTaskRunnersExternalResources#requests
     */
    readonly requests: N8NTaskRunnersExternalResourcesRequests;
    /**
     * @schema N8NTaskRunnersExternalResources#limits
     */
    readonly limits: N8NTaskRunnersExternalResourcesLimits;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NTaskRunnersExternalResources#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NTaskRunnersExternalResources' to JSON representation.
 */
export declare function toJson_N8NTaskRunnersExternalResources(obj: N8NTaskRunnersExternalResources | undefined): Record<string, any> | undefined;
/**
 * The relabeling action to perform
 *
 * @schema N8NServiceMonitorMetricRelabelingsAction
 */
export declare enum N8NServiceMonitorMetricRelabelingsAction {
    /** replace */
    REPLACE = "replace",
    /** keep */
    KEEP = "keep",
    /** drop */
    DROP = "drop",
    /** labeldrop */
    LABELDROP = "labeldrop",
    /** labelkeep */
    LABELKEEP = "labelkeep",
    /** hashmod */
    HASHMOD = "hashmod"
}
/**
 * The PostgreSQL existing certificate authority file secret.
 *
 * @schema N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret
 */
export interface N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret {
    /**
     * The name of the existing secret.
     *
     * @schema N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret#name
     */
    readonly name: string;
    /**
     * The key of the certificate authority file in the existing secret.
     *
     * @schema N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret#key
     */
    readonly key: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret' to JSON representation.
 */
export declare function toJson_N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret(obj: N8NDbPostgresdbSslExistingCertificateAuthorityFileSecret | undefined): Record<string, any> | undefined;
/**
 * The PostgreSQL existing certificate file secret.
 *
 * @schema N8NDbPostgresdbSslExistingCertFileSecret
 */
export interface N8NDbPostgresdbSslExistingCertFileSecret {
    /**
     * The name of the existing secret.
     *
     * @schema N8NDbPostgresdbSslExistingCertFileSecret#name
     */
    readonly name: string;
    /**
     * The key of the certificate file in the existing secret.
     *
     * @schema N8NDbPostgresdbSslExistingCertFileSecret#key
     */
    readonly key: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDbPostgresdbSslExistingCertFileSecret#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDbPostgresdbSslExistingCertFileSecret' to JSON representation.
 */
export declare function toJson_N8NDbPostgresdbSslExistingCertFileSecret(obj: N8NDbPostgresdbSslExistingCertFileSecret | undefined): Record<string, any> | undefined;
/**
 * The PostgreSQL existing SSL private key file secret.
 *
 * @schema N8NDbPostgresdbSslExistingPrivateKeyFileSecret
 */
export interface N8NDbPostgresdbSslExistingPrivateKeyFileSecret {
    /**
     * The name of the existing secret.
     *
     * @schema N8NDbPostgresdbSslExistingPrivateKeyFileSecret#name
     */
    readonly name: string;
    /**
     * The key of the SSL private key in the existing secret.
     *
     * @schema N8NDbPostgresdbSslExistingPrivateKeyFileSecret#key
     */
    readonly key: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NDbPostgresdbSslExistingPrivateKeyFileSecret#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NDbPostgresdbSslExistingPrivateKeyFileSecret' to JSON representation.
 */
export declare function toJson_N8NDbPostgresdbSslExistingPrivateKeyFileSecret(obj: N8NDbPostgresdbSslExistingPrivateKeyFileSecret | undefined): Record<string, any> | undefined;
/**
 * This block is for setting up the resource management for the init container more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
 *
 * @schema N8NNodesInitContainerResourcesLimits
 */
export interface N8NNodesInitContainerResourcesLimits {
    /**
     * CPU for the init container to install npm packages
     *
     * @schema N8NNodesInitContainerResourcesLimits#cpu
     */
    readonly cpu?: string;
    /**
     * Memory for the init container to install npm packages
     *
     * @schema N8NNodesInitContainerResourcesLimits#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NNodesInitContainerResourcesLimits#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NNodesInitContainerResourcesLimits' to JSON representation.
 */
export declare function toJson_N8NNodesInitContainerResourcesLimits(obj: N8NNodesInitContainerResourcesLimits | undefined): Record<string, any> | undefined;
/**
 * This block is for setting up the resource management for the init container more information can be found here: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
 *
 * @schema N8NNodesInitContainerResourcesRequests
 */
export interface N8NNodesInitContainerResourcesRequests {
    /**
     * CPU for the init container to install npm packages
     *
     * @schema N8NNodesInitContainerResourcesRequests#cpu
     */
    readonly cpu?: string;
    /**
     * Memory for the init container to install npm packages
     *
     * @schema N8NNodesInitContainerResourcesRequests#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NNodesInitContainerResourcesRequests#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NNodesInitContainerResourcesRequests' to JSON representation.
 */
export declare function toJson_N8NNodesInitContainerResourcesRequests(obj: N8NNodesInitContainerResourcesRequests | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookMcpResourcesLimits
 */
export interface N8NWebhookMcpResourcesLimits {
    /**
     * @schema N8NWebhookMcpResourcesLimits#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NWebhookMcpResourcesLimits#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpResourcesLimits#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpResourcesLimits' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpResourcesLimits(obj: N8NWebhookMcpResourcesLimits | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookMcpResourcesRequests
 */
export interface N8NWebhookMcpResourcesRequests {
    /**
     * @schema N8NWebhookMcpResourcesRequests#cpu
     */
    readonly cpu?: string;
    /**
     * @schema N8NWebhookMcpResourcesRequests#memory
     */
    readonly memory?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpResourcesRequests#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpResourcesRequests' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpResourcesRequests(obj: N8NWebhookMcpResourcesRequests | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookMcpStartupProbeExec
 */
export interface N8NWebhookMcpStartupProbeExec {
    /**
     * @schema N8NWebhookMcpStartupProbeExec#command
     */
    readonly command: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpStartupProbeExec#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpStartupProbeExec' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpStartupProbeExec(obj: N8NWebhookMcpStartupProbeExec | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookMcpLivenessProbeHttpGet
 */
export interface N8NWebhookMcpLivenessProbeHttpGet {
    /**
     * @schema N8NWebhookMcpLivenessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NWebhookMcpLivenessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpLivenessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpLivenessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpLivenessProbeHttpGet(obj: N8NWebhookMcpLivenessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookMcpReadinessProbeHttpGet
 */
export interface N8NWebhookMcpReadinessProbeHttpGet {
    /**
     * @schema N8NWebhookMcpReadinessProbeHttpGet#path
     */
    readonly path: string;
    /**
     * @schema N8NWebhookMcpReadinessProbeHttpGet#port
     */
    readonly port: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookMcpReadinessProbeHttpGet#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookMcpReadinessProbeHttpGet' to JSON representation.
 */
export declare function toJson_N8NWebhookMcpReadinessProbeHttpGet(obj: N8NWebhookMcpReadinessProbeHttpGet | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookAutoscalingMetricsType
 */
export declare enum N8NWebhookAutoscalingMetricsType {
    /** Resource */
    RESOURCE = "Resource",
    /** Pods */
    PODS = "Pods",
    /** Object */
    OBJECT = "Object",
    /** External */
    EXTERNAL = "External"
}
/**
 * @schema N8NWebhookAutoscalingBehaviorScaleUp
 */
export interface N8NWebhookAutoscalingBehaviorScaleUp {
    /**
     * Time in seconds to wait before scaling up again (default: 0)
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleUp#stabilizationWindowSeconds
     */
    readonly stabilizationWindowSeconds?: number;
    /**
     * List of scaling policies for scale-up
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleUp#policies
     */
    readonly policies?: N8NWebhookAutoscalingBehaviorScaleUpPolicies[];
    /**
     * Policy to select among multiple policies: Max (default), Min, or Disabled
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleUp#selectPolicy
     */
    readonly selectPolicy?: N8NWebhookAutoscalingBehaviorScaleUpSelectPolicy;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleUp#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookAutoscalingBehaviorScaleUp' to JSON representation.
 */
export declare function toJson_N8NWebhookAutoscalingBehaviorScaleUp(obj: N8NWebhookAutoscalingBehaviorScaleUp | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookAutoscalingBehaviorScaleDown
 */
export interface N8NWebhookAutoscalingBehaviorScaleDown {
    /**
     * Time in seconds to wait before scaling down again (default: 300)
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleDown#stabilizationWindowSeconds
     */
    readonly stabilizationWindowSeconds?: number;
    /**
     * List of scaling policies for scale-down
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleDown#policies
     */
    readonly policies?: N8NWebhookAutoscalingBehaviorScaleDownPolicies[];
    /**
     * Policy to select among multiple policies: Max (default), Min, or Disabled
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleDown#selectPolicy
     */
    readonly selectPolicy?: N8NWebhookAutoscalingBehaviorScaleDownSelectPolicy;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleDown#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWebhookAutoscalingBehaviorScaleDown' to JSON representation.
 */
export declare function toJson_N8NWebhookAutoscalingBehaviorScaleDown(obj: N8NWebhookAutoscalingBehaviorScaleDown | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerAutoscalingMetricsType
 */
export declare enum N8NWorkerAutoscalingMetricsType {
    /** Resource */
    RESOURCE = "Resource",
    /** Pods */
    PODS = "Pods",
    /** Object */
    OBJECT = "Object",
    /** External */
    EXTERNAL = "External"
}
/**
 * @schema N8NWorkerAutoscalingBehaviorScaleUp
 */
export interface N8NWorkerAutoscalingBehaviorScaleUp {
    /**
     * Time in seconds to wait before scaling up again (default: 0)
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleUp#stabilizationWindowSeconds
     */
    readonly stabilizationWindowSeconds?: number;
    /**
     * List of scaling policies for scale-up
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleUp#policies
     */
    readonly policies?: N8NWorkerAutoscalingBehaviorScaleUpPolicies[];
    /**
     * Policy to select among multiple policies: Max (default), Min, or Disabled
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleUp#selectPolicy
     */
    readonly selectPolicy?: N8NWorkerAutoscalingBehaviorScaleUpSelectPolicy;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleUp#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerAutoscalingBehaviorScaleUp' to JSON representation.
 */
export declare function toJson_N8NWorkerAutoscalingBehaviorScaleUp(obj: N8NWorkerAutoscalingBehaviorScaleUp | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWorkerAutoscalingBehaviorScaleDown
 */
export interface N8NWorkerAutoscalingBehaviorScaleDown {
    /**
     * Time in seconds to wait before scaling down again (default: 300)
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleDown#stabilizationWindowSeconds
     */
    readonly stabilizationWindowSeconds?: number;
    /**
     * List of scaling policies for scale-down
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleDown#policies
     */
    readonly policies?: N8NWorkerAutoscalingBehaviorScaleDownPolicies[];
    /**
     * Policy to select among multiple policies: Max (default), Min, or Disabled
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleDown#selectPolicy
     */
    readonly selectPolicy?: N8NWorkerAutoscalingBehaviorScaleDownSelectPolicy;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleDown#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NWorkerAutoscalingBehaviorScaleDown' to JSON representation.
 */
export declare function toJson_N8NWorkerAutoscalingBehaviorScaleDown(obj: N8NWorkerAutoscalingBehaviorScaleDown | undefined): Record<string, any> | undefined;
/**
 * @schema N8NTaskRunnersExternalResourcesRequests
 */
export interface N8NTaskRunnersExternalResourcesRequests {
    /**
     * @schema N8NTaskRunnersExternalResourcesRequests#cpu
     */
    readonly cpu: string;
    /**
     * @schema N8NTaskRunnersExternalResourcesRequests#memory
     */
    readonly memory: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NTaskRunnersExternalResourcesRequests#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NTaskRunnersExternalResourcesRequests' to JSON representation.
 */
export declare function toJson_N8NTaskRunnersExternalResourcesRequests(obj: N8NTaskRunnersExternalResourcesRequests | undefined): Record<string, any> | undefined;
/**
 * @schema N8NTaskRunnersExternalResourcesLimits
 */
export interface N8NTaskRunnersExternalResourcesLimits {
    /**
     * @schema N8NTaskRunnersExternalResourcesLimits#cpu
     */
    readonly cpu: string;
    /**
     * @schema N8NTaskRunnersExternalResourcesLimits#memory
     */
    readonly memory: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema N8NTaskRunnersExternalResourcesLimits#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'N8NTaskRunnersExternalResourcesLimits' to JSON representation.
 */
export declare function toJson_N8NTaskRunnersExternalResourcesLimits(obj: N8NTaskRunnersExternalResourcesLimits | undefined): Record<string, any> | undefined;
/**
 * @schema N8NWebhookAutoscalingBehaviorScaleUpPolicies
 */
export interface N8NWebhookAutoscalingBehaviorScaleUpPolicies {
    /**
     * Type of scaling policy: Pods (fixed number) or Percent (percentage of current replicas)
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleUpPolicies#type
     */
    readonly type: N8NWebhookAutoscalingBehaviorScaleUpPoliciesType;
    /**
     * The value to scale by (number of pods or percentage)
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleUpPolicies#value
     */
    readonly value: number;
    /**
     * Time in seconds over which the policy is evaluated
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleUpPolicies#periodSeconds
     */
    readonly periodSeconds: number;
}
/**
 * Converts an object of type 'N8NWebhookAutoscalingBehaviorScaleUpPolicies' to JSON representation.
 */
export declare function toJson_N8NWebhookAutoscalingBehaviorScaleUpPolicies(obj: N8NWebhookAutoscalingBehaviorScaleUpPolicies | undefined): Record<string, any> | undefined;
/**
 * Policy to select among multiple policies: Max (default), Min, or Disabled
 *
 * @schema N8NWebhookAutoscalingBehaviorScaleUpSelectPolicy
 */
export declare enum N8NWebhookAutoscalingBehaviorScaleUpSelectPolicy {
    /** Max */
    MAX = "Max",
    /** Min */
    MIN = "Min",
    /** Disabled */
    DISABLED = "Disabled"
}
/**
 * @schema N8NWebhookAutoscalingBehaviorScaleDownPolicies
 */
export interface N8NWebhookAutoscalingBehaviorScaleDownPolicies {
    /**
     * Type of scaling policy: Pods (fixed number) or Percent (percentage of current replicas)
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleDownPolicies#type
     */
    readonly type: N8NWebhookAutoscalingBehaviorScaleDownPoliciesType;
    /**
     * The value to scale by (number of pods or percentage)
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleDownPolicies#value
     */
    readonly value: number;
    /**
     * Time in seconds over which the policy is evaluated
     *
     * @schema N8NWebhookAutoscalingBehaviorScaleDownPolicies#periodSeconds
     */
    readonly periodSeconds: number;
}
/**
 * Converts an object of type 'N8NWebhookAutoscalingBehaviorScaleDownPolicies' to JSON representation.
 */
export declare function toJson_N8NWebhookAutoscalingBehaviorScaleDownPolicies(obj: N8NWebhookAutoscalingBehaviorScaleDownPolicies | undefined): Record<string, any> | undefined;
/**
 * Policy to select among multiple policies: Max (default), Min, or Disabled
 *
 * @schema N8NWebhookAutoscalingBehaviorScaleDownSelectPolicy
 */
export declare enum N8NWebhookAutoscalingBehaviorScaleDownSelectPolicy {
    /** Max */
    MAX = "Max",
    /** Min */
    MIN = "Min",
    /** Disabled */
    DISABLED = "Disabled"
}
/**
 * @schema N8NWorkerAutoscalingBehaviorScaleUpPolicies
 */
export interface N8NWorkerAutoscalingBehaviorScaleUpPolicies {
    /**
     * Type of scaling policy: Pods (fixed number) or Percent (percentage of current replicas)
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleUpPolicies#type
     */
    readonly type: N8NWorkerAutoscalingBehaviorScaleUpPoliciesType;
    /**
     * The value to scale by (number of pods or percentage)
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleUpPolicies#value
     */
    readonly value: number;
    /**
     * Time in seconds over which the policy is evaluated
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleUpPolicies#periodSeconds
     */
    readonly periodSeconds: number;
}
/**
 * Converts an object of type 'N8NWorkerAutoscalingBehaviorScaleUpPolicies' to JSON representation.
 */
export declare function toJson_N8NWorkerAutoscalingBehaviorScaleUpPolicies(obj: N8NWorkerAutoscalingBehaviorScaleUpPolicies | undefined): Record<string, any> | undefined;
/**
 * Policy to select among multiple policies: Max (default), Min, or Disabled
 *
 * @schema N8NWorkerAutoscalingBehaviorScaleUpSelectPolicy
 */
export declare enum N8NWorkerAutoscalingBehaviorScaleUpSelectPolicy {
    /** Max */
    MAX = "Max",
    /** Min */
    MIN = "Min",
    /** Disabled */
    DISABLED = "Disabled"
}
/**
 * @schema N8NWorkerAutoscalingBehaviorScaleDownPolicies
 */
export interface N8NWorkerAutoscalingBehaviorScaleDownPolicies {
    /**
     * Type of scaling policy: Pods (fixed number) or Percent (percentage of current replicas)
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleDownPolicies#type
     */
    readonly type: N8NWorkerAutoscalingBehaviorScaleDownPoliciesType;
    /**
     * The value to scale by (number of pods or percentage)
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleDownPolicies#value
     */
    readonly value: number;
    /**
     * Time in seconds over which the policy is evaluated
     *
     * @schema N8NWorkerAutoscalingBehaviorScaleDownPolicies#periodSeconds
     */
    readonly periodSeconds: number;
}
/**
 * Converts an object of type 'N8NWorkerAutoscalingBehaviorScaleDownPolicies' to JSON representation.
 */
export declare function toJson_N8NWorkerAutoscalingBehaviorScaleDownPolicies(obj: N8NWorkerAutoscalingBehaviorScaleDownPolicies | undefined): Record<string, any> | undefined;
/**
 * Policy to select among multiple policies: Max (default), Min, or Disabled
 *
 * @schema N8NWorkerAutoscalingBehaviorScaleDownSelectPolicy
 */
export declare enum N8NWorkerAutoscalingBehaviorScaleDownSelectPolicy {
    /** Max */
    MAX = "Max",
    /** Min */
    MIN = "Min",
    /** Disabled */
    DISABLED = "Disabled"
}
/**
 * Type of scaling policy: Pods (fixed number) or Percent (percentage of current replicas)
 *
 * @schema N8NWebhookAutoscalingBehaviorScaleUpPoliciesType
 */
export declare enum N8NWebhookAutoscalingBehaviorScaleUpPoliciesType {
    /** Pods */
    PODS = "Pods",
    /** Percent */
    PERCENT = "Percent"
}
/**
 * Type of scaling policy: Pods (fixed number) or Percent (percentage of current replicas)
 *
 * @schema N8NWebhookAutoscalingBehaviorScaleDownPoliciesType
 */
export declare enum N8NWebhookAutoscalingBehaviorScaleDownPoliciesType {
    /** Pods */
    PODS = "Pods",
    /** Percent */
    PERCENT = "Percent"
}
/**
 * Type of scaling policy: Pods (fixed number) or Percent (percentage of current replicas)
 *
 * @schema N8NWorkerAutoscalingBehaviorScaleUpPoliciesType
 */
export declare enum N8NWorkerAutoscalingBehaviorScaleUpPoliciesType {
    /** Pods */
    PODS = "Pods",
    /** Percent */
    PERCENT = "Percent"
}
/**
 * Type of scaling policy: Pods (fixed number) or Percent (percentage of current replicas)
 *
 * @schema N8NWorkerAutoscalingBehaviorScaleDownPoliciesType
 */
export declare enum N8NWorkerAutoscalingBehaviorScaleDownPoliciesType {
    /** Pods */
    PODS = "Pods",
    /** Percent */
    PERCENT = "Percent"
}
