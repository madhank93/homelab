import { ApiObject, ApiObjectMetadata, GroupVersionKind } from 'cdk8s';
import { Construct } from 'constructs';
/**
 * SecretProviderClass is the Schema for the secretproviderclasses API
 *
 * @schema SecretProviderClass
 */
export declare class SecretProviderClass extends ApiObject {
    /**
     * Returns the apiVersion and kind for "SecretProviderClass"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "SecretProviderClass".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: SecretProviderClassProps): any;
    /**
     * Defines a "SecretProviderClass" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: SecretProviderClassProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * SecretProviderClass is the Schema for the secretproviderclasses API
 *
 * @schema SecretProviderClass
 */
export interface SecretProviderClassProps {
    /**
     * @schema SecretProviderClass#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * SecretProviderClassSpec defines the desired state of SecretProviderClass
     *
     * @schema SecretProviderClass#spec
     */
    readonly spec?: SecretProviderClassSpec;
}
/**
 * Converts an object of type 'SecretProviderClassProps' to JSON representation.
 */
export declare function toJson_SecretProviderClassProps(obj: SecretProviderClassProps | undefined): Record<string, any> | undefined;
/**
 * SecretProviderClassSpec defines the desired state of SecretProviderClass
 *
 * @schema SecretProviderClassSpec
 */
export interface SecretProviderClassSpec {
    /**
     * Configuration for specific provider
     *
     * @schema SecretProviderClassSpec#parameters
     */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
     * Configuration for provider name
     *
     * @schema SecretProviderClassSpec#provider
     */
    readonly provider?: string;
    /**
     * @schema SecretProviderClassSpec#secretObjects
     */
    readonly secretObjects?: SecretProviderClassSpecSecretObjects[];
}
/**
 * Converts an object of type 'SecretProviderClassSpec' to JSON representation.
 */
export declare function toJson_SecretProviderClassSpec(obj: SecretProviderClassSpec | undefined): Record<string, any> | undefined;
/**
 * SecretObject defines the desired state of synced K8s secret objects
 *
 * @schema SecretProviderClassSpecSecretObjects
 */
export interface SecretProviderClassSpecSecretObjects {
    /**
     * annotations of k8s secret object
     *
     * @schema SecretProviderClassSpecSecretObjects#annotations
     */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
     * @schema SecretProviderClassSpecSecretObjects#data
     */
    readonly data?: SecretProviderClassSpecSecretObjectsData[];
    /**
     * labels of K8s secret object
     *
     * @schema SecretProviderClassSpecSecretObjects#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * name of the K8s secret object
     *
     * @schema SecretProviderClassSpecSecretObjects#secretName
     */
    readonly secretName?: string;
    /**
     * type of K8s secret object
     *
     * @schema SecretProviderClassSpecSecretObjects#type
     */
    readonly type?: string;
}
/**
 * Converts an object of type 'SecretProviderClassSpecSecretObjects' to JSON representation.
 */
export declare function toJson_SecretProviderClassSpecSecretObjects(obj: SecretProviderClassSpecSecretObjects | undefined): Record<string, any> | undefined;
/**
 * SecretObjectData defines the desired state of synced K8s secret object data
 *
 * @schema SecretProviderClassSpecSecretObjectsData
 */
export interface SecretProviderClassSpecSecretObjectsData {
    /**
     * data field to populate
     *
     * @schema SecretProviderClassSpecSecretObjectsData#key
     */
    readonly key?: string;
    /**
     * name of the object to sync
     *
     * @schema SecretProviderClassSpecSecretObjectsData#objectName
     */
    readonly objectName?: string;
}
/**
 * Converts an object of type 'SecretProviderClassSpecSecretObjectsData' to JSON representation.
 */
export declare function toJson_SecretProviderClassSpecSecretObjectsData(obj: SecretProviderClassSpecSecretObjectsData | undefined): Record<string, any> | undefined;
/**
 * SecretProviderClass is the Schema for the secretproviderclasses API
 *
 * @schema SecretProviderClassV1Alpha1
 */
export declare class SecretProviderClassV1Alpha1 extends ApiObject {
    /**
     * Returns the apiVersion and kind for "SecretProviderClassV1Alpha1"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "SecretProviderClassV1Alpha1".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: SecretProviderClassV1Alpha1Props): any;
    /**
     * Defines a "SecretProviderClassV1Alpha1" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: SecretProviderClassV1Alpha1Props);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * SecretProviderClass is the Schema for the secretproviderclasses API
 *
 * @schema SecretProviderClassV1Alpha1
 */
export interface SecretProviderClassV1Alpha1Props {
    /**
     * @schema SecretProviderClassV1Alpha1#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * SecretProviderClassSpec defines the desired state of SecretProviderClass
     *
     * @schema SecretProviderClassV1Alpha1#spec
     */
    readonly spec?: SecretProviderClassV1Alpha1Spec;
}
/**
 * Converts an object of type 'SecretProviderClassV1Alpha1Props' to JSON representation.
 */
export declare function toJson_SecretProviderClassV1Alpha1Props(obj: SecretProviderClassV1Alpha1Props | undefined): Record<string, any> | undefined;
/**
 * SecretProviderClassSpec defines the desired state of SecretProviderClass
 *
 * @schema SecretProviderClassV1Alpha1Spec
 */
export interface SecretProviderClassV1Alpha1Spec {
    /**
     * Configuration for specific provider
     *
     * @schema SecretProviderClassV1Alpha1Spec#parameters
     */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
     * Configuration for provider name
     *
     * @schema SecretProviderClassV1Alpha1Spec#provider
     */
    readonly provider?: string;
    /**
     * @schema SecretProviderClassV1Alpha1Spec#secretObjects
     */
    readonly secretObjects?: SecretProviderClassV1Alpha1SpecSecretObjects[];
}
/**
 * Converts an object of type 'SecretProviderClassV1Alpha1Spec' to JSON representation.
 */
export declare function toJson_SecretProviderClassV1Alpha1Spec(obj: SecretProviderClassV1Alpha1Spec | undefined): Record<string, any> | undefined;
/**
 * SecretObject defines the desired state of synced K8s secret objects
 *
 * @schema SecretProviderClassV1Alpha1SpecSecretObjects
 */
export interface SecretProviderClassV1Alpha1SpecSecretObjects {
    /**
     * annotations of k8s secret object
     *
     * @schema SecretProviderClassV1Alpha1SpecSecretObjects#annotations
     */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
     * @schema SecretProviderClassV1Alpha1SpecSecretObjects#data
     */
    readonly data?: SecretProviderClassV1Alpha1SpecSecretObjectsData[];
    /**
     * labels of K8s secret object
     *
     * @schema SecretProviderClassV1Alpha1SpecSecretObjects#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * name of the K8s secret object
     *
     * @schema SecretProviderClassV1Alpha1SpecSecretObjects#secretName
     */
    readonly secretName?: string;
    /**
     * type of K8s secret object
     *
     * @schema SecretProviderClassV1Alpha1SpecSecretObjects#type
     */
    readonly type?: string;
}
/**
 * Converts an object of type 'SecretProviderClassV1Alpha1SpecSecretObjects' to JSON representation.
 */
export declare function toJson_SecretProviderClassV1Alpha1SpecSecretObjects(obj: SecretProviderClassV1Alpha1SpecSecretObjects | undefined): Record<string, any> | undefined;
/**
 * SecretObjectData defines the desired state of synced K8s secret object data
 *
 * @schema SecretProviderClassV1Alpha1SpecSecretObjectsData
 */
export interface SecretProviderClassV1Alpha1SpecSecretObjectsData {
    /**
     * data field to populate
     *
     * @schema SecretProviderClassV1Alpha1SpecSecretObjectsData#key
     */
    readonly key?: string;
    /**
     * name of the object to sync
     *
     * @schema SecretProviderClassV1Alpha1SpecSecretObjectsData#objectName
     */
    readonly objectName?: string;
}
/**
 * Converts an object of type 'SecretProviderClassV1Alpha1SpecSecretObjectsData' to JSON representation.
 */
export declare function toJson_SecretProviderClassV1Alpha1SpecSecretObjectsData(obj: SecretProviderClassV1Alpha1SpecSecretObjectsData | undefined): Record<string, any> | undefined;
