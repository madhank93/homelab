import { Helm } from 'cdk8s';
import { Construct } from 'constructs';
export interface HeadlampProps {
    readonly namespace?: string;
    readonly releaseName?: string;
    readonly helmExecutable?: string;
    readonly helmFlags?: string[];
    readonly values?: HeadlampValues;
}
export declare class Headlamp extends Construct {
    helm: Helm;
    constructor(scope: Construct, id: string, props?: HeadlampProps);
    private flattenAdditionalValues;
}
/**
 * @schema headlamp
 */
export interface HeadlampValues {
    /**
     * Number of replicas to deploy
     *
     * @schema headlamp#replicaCount
     */
    readonly replicaCount?: number;
    /**
     * Image to deploy
     *
     * @schema headlamp#image
     */
    readonly image?: HeadlampImage;
    /**
     * ImagePullSecrets is an optional list of references to secrets in the same namespace to use for pulling any of the images used by this PodSpec. If specified, these secrets will be passed to individual puller implementations for them to use.
     *
     * @schema headlamp#imagePullSecrets
     */
    readonly imagePullSecrets?: HeadlampImagePullSecrets[];
    /**
     * Override the name of the chart
     *
     * @schema headlamp#nameOverride
     */
    readonly nameOverride?: string;
    /**
     * Override the full name of the chart
     *
     * @schema headlamp#fullnameOverride
     */
    readonly fullnameOverride?: string;
    /**
     * Override the deployment namespace; defaults to .Release.Namespace
     *
     * @schema headlamp#namespaceOverride
     */
    readonly namespaceOverride?: string;
    /**
     * Init containers
     *
     * @schema headlamp#initContainers
     */
    readonly initContainers?: HeadlampInitContainers[];
    /**
     * Headlamp deployment configuration
     *
     * @schema headlamp#config
     */
    readonly config?: HeadlampConfig;
    /**
     * Environment variables to pass to the deployment
     *
     * @schema headlamp#env
     */
    readonly env?: HeadlampEnv[];
    /**
     * Mount Service Account token in pod
     *
     * @schema headlamp#automountServiceAccountToken
     */
    readonly automountServiceAccountToken?: boolean;
    /**
     * @schema headlamp#serviceAccount
     */
    readonly serviceAccount?: HeadlampServiceAccount;
    /**
     * @schema headlamp#clusterRoleBinding
     */
    readonly clusterRoleBinding?: HeadlampClusterRoleBinding;
    /**
     * @schema headlamp#service
     */
    readonly service?: HeadlampService;
    /**
     * @schema headlamp#persistentVolumeClaim
     */
    readonly persistentVolumeClaim?: HeadlampPersistentVolumeClaim;
    /**
     * @schema headlamp#ingress
     */
    readonly ingress?: HeadlampIngress;
    /**
     * HTTPRoute configuration for Gateway API
     *
     * @schema headlamp#httpRoute
     */
    readonly httpRoute?: HeadlampHttpRoute;
    /**
     * @schema headlamp#podDisruptionBudget
     */
    readonly podDisruptionBudget?: HeadlampPodDisruptionBudget;
    /**
     * Extra manifests to apply to the deployment
     *
     * @schema headlamp#extraManifests
     */
    readonly extraManifests?: string[];
    /**
     * @schema headlamp#global
     */
    readonly global?: {
        [key: string]: any;
    };
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema headlamp#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampValues' to JSON representation.
 */
export declare function toJson_HeadlampValues(obj: HeadlampValues | undefined): Record<string, any> | undefined;
/**
 * Image to deploy
 *
 * @schema HeadlampImage
 */
export interface HeadlampImage {
    /**
     * Registry of the image
     *
     * @schema HeadlampImage#registry
     */
    readonly registry?: string;
    /**
     * Repository of the image
     *
     * @schema HeadlampImage#repository
     */
    readonly repository?: string;
    /**
     * Pull policy of the image
     *
     * @schema HeadlampImage#pullPolicy
     */
    readonly pullPolicy?: HeadlampImagePullPolicy;
    /**
     * Tag of the image
     *
     * @schema HeadlampImage#tag
     */
    readonly tag?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampImage#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampImage' to JSON representation.
 */
export declare function toJson_HeadlampImage(obj: HeadlampImage | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampImagePullSecrets
 */
export interface HeadlampImagePullSecrets {
    /**
     * Name of the image pull secret
     *
     * @schema HeadlampImagePullSecrets#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'HeadlampImagePullSecrets' to JSON representation.
 */
export declare function toJson_HeadlampImagePullSecrets(obj: HeadlampImagePullSecrets | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampInitContainers
 */
export interface HeadlampInitContainers {
    /**
     * Name of the init container
     *
     * @schema HeadlampInitContainers#name
     */
    readonly name?: string;
    /**
     * Image of the init container
     *
     * @schema HeadlampInitContainers#image
     */
    readonly image?: string;
    /**
     * Pull policy of the init container
     *
     * @schema HeadlampInitContainers#imagePullPolicy
     */
    readonly imagePullPolicy?: HeadlampInitContainersImagePullPolicy;
    /**
     * Command of the init container
     *
     * @schema HeadlampInitContainers#command
     */
    readonly command?: string[];
    /**
     * Arguments of the init container
     *
     * @schema HeadlampInitContainers#args
     */
    readonly args?: string[];
    /**
     * Resources of the init container
     *
     * @schema HeadlampInitContainers#resources
     */
    readonly resources?: HeadlampInitContainersResources;
    /**
     * Environment variables of the init container
     *
     * @schema HeadlampInitContainers#env
     */
    readonly env?: HeadlampInitContainersEnv[];
    /**
     * Volume mounts of the init container
     *
     * @schema HeadlampInitContainers#volumeMounts
     */
    readonly volumeMounts?: HeadlampInitContainersVolumeMounts[];
}
/**
 * Converts an object of type 'HeadlampInitContainers' to JSON representation.
 */
export declare function toJson_HeadlampInitContainers(obj: HeadlampInitContainers | undefined): Record<string, any> | undefined;
/**
 * Headlamp deployment configuration
 *
 * @schema HeadlampConfig
 */
export interface HeadlampConfig {
    /**
     * Base URL of the application
     *
     * @schema HeadlampConfig#baseURL
     */
    readonly baseUrl?: string;
    /**
     * The time in seconds for the session to be valid
     *
     * @schema HeadlampConfig#sessionTTL
     */
    readonly sessionTtl?: number;
    /**
     * OIDC configuration
     *
     * @schema HeadlampConfig#oidc
     */
    readonly oidc?: HeadlampConfigOidc;
    /**
     * Directory to load plugins from
     *
     * @schema HeadlampConfig#pluginsDir
     */
    readonly pluginsDir?: string;
    /**
     * Path of certificate file for TLS
     *
     * @schema HeadlampConfig#tlsCertPath
     */
    readonly tlsCertPath?: string;
    /**
     * Path of private key file for TLS
     *
     * @schema HeadlampConfig#tlsKeyPath
     */
    readonly tlsKeyPath?: string;
    /**
     * Extra arguments to pass to the application
     *
     * @schema HeadlampConfig#extraArgs
     */
    readonly extraArgs?: string[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampConfig#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampConfig' to JSON representation.
 */
export declare function toJson_HeadlampConfig(obj: HeadlampConfig | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampEnv
 */
export interface HeadlampEnv {
    /**
     * Name of the environment variable
     *
     * @schema HeadlampEnv#name
     */
    readonly name: string;
    /**
     * Value of the environment variable
     *
     * @schema HeadlampEnv#value
     */
    readonly value: string;
}
/**
 * Converts an object of type 'HeadlampEnv' to JSON representation.
 */
export declare function toJson_HeadlampEnv(obj: HeadlampEnv | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampServiceAccount
 */
export interface HeadlampServiceAccount {
    /**
     * Specifies whether a service account should be created
     *
     * @schema HeadlampServiceAccount#create
     */
    readonly create?: boolean;
    /**
     * Annotations to add to the service account
     *
     * @schema HeadlampServiceAccount#annotations
     */
    readonly annotations?: any;
    /**
     * The name of the service account to use
     *
     * @schema HeadlampServiceAccount#name
     */
    readonly name?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampServiceAccount#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampServiceAccount' to JSON representation.
 */
export declare function toJson_HeadlampServiceAccount(obj: HeadlampServiceAccount | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampClusterRoleBinding
 */
export interface HeadlampClusterRoleBinding {
    /**
     * Specifies whether a cluster role binding should be created
     *
     * @schema HeadlampClusterRoleBinding#create
     */
    readonly create?: boolean;
    /**
     * The name of the ClusterRole to create in the cluster
     *
     * @schema HeadlampClusterRoleBinding#clusterRoleName
     */
    readonly clusterRoleName?: string;
    /**
     * Annotations to add to the cluster role binding
     *
     * @schema HeadlampClusterRoleBinding#annotations
     */
    readonly annotations?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampClusterRoleBinding#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampClusterRoleBinding' to JSON representation.
 */
export declare function toJson_HeadlampClusterRoleBinding(obj: HeadlampClusterRoleBinding | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampService
 */
export interface HeadlampService {
    /**
     * Kubernetes Service type
     *
     * @schema HeadlampService#type
     */
    readonly type?: HeadlampServiceType;
    /**
     * Kubernetes Service port
     *
     * @schema HeadlampService#port
     */
    readonly port?: number;
    /**
     * Kubernetes Service clusterIP
     *
     * @schema HeadlampService#clusterIP
     */
    readonly clusterIp?: string;
    /**
     * Kubernetes Service loadBalancerIP
     *
     * @schema HeadlampService#loadBalancerIP
     */
    readonly loadBalancerIp?: string;
    /**
     * Kubernetes Service loadBalancerSourceRanges
     *
     * @schema HeadlampService#loadBalancerSourceRanges
     */
    readonly loadBalancerSourceRanges?: string[];
    /**
     * Kubernetes Service Nodeport
     *
     * @schema HeadlampService#nodePort
     */
    readonly nodePort?: number;
    /**
     * Additional ports to expose on the Service in addition to the default http port
     *
     * @schema HeadlampService#extraServicePorts
     */
    readonly extraServicePorts?: HeadlampServiceExtraServicePorts[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampService#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampService' to JSON representation.
 */
export declare function toJson_HeadlampService(obj: HeadlampService | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampPersistentVolumeClaim
 */
export interface HeadlampPersistentVolumeClaim {
    /**
     * Enable Persistent Volume Claim
     *
     * @schema HeadlampPersistentVolumeClaim#enabled
     */
    readonly enabled?: boolean;
    /**
     * Annotations to add to the persistent volume claim (if enabled)
     *
     * @schema HeadlampPersistentVolumeClaim#annotations
     */
    readonly annotations?: any;
    /**
     * @schema HeadlampPersistentVolumeClaim#accessModes
     */
    readonly accessModes?: string[];
    /**
     * @schema HeadlampPersistentVolumeClaim#size
     */
    readonly size?: string;
    /**
     * @schema HeadlampPersistentVolumeClaim#storageClassName
     */
    readonly storageClassName?: string;
    /**
     * @schema HeadlampPersistentVolumeClaim#selector
     */
    readonly selector?: HeadlampPersistentVolumeClaimSelector;
    /**
     * @schema HeadlampPersistentVolumeClaim#volumeMode
     */
    readonly volumeMode?: string;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampPersistentVolumeClaim#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampPersistentVolumeClaim' to JSON representation.
 */
export declare function toJson_HeadlampPersistentVolumeClaim(obj: HeadlampPersistentVolumeClaim | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampIngress
 */
export interface HeadlampIngress {
    /**
     * Enable ingress controller resource
     *
     * @schema HeadlampIngress#enabled
     */
    readonly enabled?: boolean;
    /**
     * Annotations for Ingress resource
     *
     * @schema HeadlampIngress#annotations
     */
    readonly annotations?: any;
    /**
     * Ingress class name
     *
     * @schema HeadlampIngress#ingressClassName
     */
    readonly ingressClassName?: string;
    /**
     * @schema HeadlampIngress#hosts
     */
    readonly hosts?: HeadlampIngressHosts[];
    /**
     * @schema HeadlampIngress#tls
     */
    readonly tls?: HeadlampIngressTls[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampIngress#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampIngress' to JSON representation.
 */
export declare function toJson_HeadlampIngress(obj: HeadlampIngress | undefined): Record<string, any> | undefined;
/**
 * HTTPRoute configuration for Gateway API
 *
 * @schema HeadlampHttpRoute
 */
export interface HeadlampHttpRoute {
    /**
     * Enable HTTPRoute resource for Gateway API
     *
     * @schema HeadlampHttpRoute#enabled
     */
    readonly enabled?: boolean;
    /**
     * Annotations for HTTPRoute resource
     *
     * @schema HeadlampHttpRoute#annotations
     */
    readonly annotations?: any;
    /**
     * Additional labels for HTTPRoute resource
     *
     * @schema HeadlampHttpRoute#labels
     */
    readonly labels?: any;
    /**
     * Parent references (REQUIRED when enabled - HTTPRoute will not work without this)
     *
     * @schema HeadlampHttpRoute#parentRefs
     */
    readonly parentRefs?: HeadlampHttpRouteParentRefs[];
    /**
     * Hostnames for the HTTPRoute
     *
     * @schema HeadlampHttpRoute#hostnames
     */
    readonly hostnames?: string[];
    /**
     * Custom routing rules (optional, defaults to path prefix /)
     *
     * @schema HeadlampHttpRoute#rules
     */
    readonly rules?: any[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampHttpRoute#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampHttpRoute' to JSON representation.
 */
export declare function toJson_HeadlampHttpRoute(obj: HeadlampHttpRoute | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampPodDisruptionBudget
 */
export interface HeadlampPodDisruptionBudget {
    /**
     * Enable PodDisruptionBudget. See: https://kubernetes.io/docs/concepts/workloads/pods/disruptions/
     *
     * @schema HeadlampPodDisruptionBudget#enabled
     */
    readonly enabled?: boolean;
    /**
     * Minimum number/percentage of pods that should remain scheduled. When it's set, maxUnavailable must be disabled by `maxUnavailable: null`
     *
     * @schema HeadlampPodDisruptionBudget#minAvailable
     */
    readonly minAvailable?: any;
    /**
     * Maximum number/percentage of pods that may be made unavailable
     *
     * @schema HeadlampPodDisruptionBudget#maxUnavailable
     */
    readonly maxUnavailable?: any;
    /**
     * How are unhealthy, but running, pods counted for eviction
     *
     * @schema HeadlampPodDisruptionBudget#unhealthyPodEvictionPolicy
     */
    readonly unhealthyPodEvictionPolicy?: any;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampPodDisruptionBudget#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampPodDisruptionBudget' to JSON representation.
 */
export declare function toJson_HeadlampPodDisruptionBudget(obj: HeadlampPodDisruptionBudget | undefined): Record<string, any> | undefined;
/**
 * Pull policy of the image
 *
 * @schema HeadlampImagePullPolicy
 */
export declare enum HeadlampImagePullPolicy {
    /** Always */
    ALWAYS = "Always",
    /** IfNotPresent */
    IF_NOT_PRESENT = "IfNotPresent",
    /** Never */
    NEVER = "Never"
}
/**
 * Pull policy of the init container
 *
 * @schema HeadlampInitContainersImagePullPolicy
 */
export declare enum HeadlampInitContainersImagePullPolicy {
    /** Always */
    ALWAYS = "Always",
    /** IfNotPresent */
    IF_NOT_PRESENT = "IfNotPresent",
    /** Never */
    NEVER = "Never"
}
/**
 * Resources of the init container
 *
 * @schema HeadlampInitContainersResources
 */
export interface HeadlampInitContainersResources {
    /**
     * Limits of the init container
     *
     * @schema HeadlampInitContainersResources#limits
     */
    readonly limits?: HeadlampInitContainersResourcesLimits;
    /**
     * Requests of the init container
     *
     * @schema HeadlampInitContainersResources#requests
     */
    readonly requests?: HeadlampInitContainersResourcesRequests;
}
/**
 * Converts an object of type 'HeadlampInitContainersResources' to JSON representation.
 */
export declare function toJson_HeadlampInitContainersResources(obj: HeadlampInitContainersResources | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampInitContainersEnv
 */
export interface HeadlampInitContainersEnv {
    /**
     * Name of the environment variable
     *
     * @schema HeadlampInitContainersEnv#name
     */
    readonly name?: string;
    /**
     * Value of the environment variable
     *
     * @schema HeadlampInitContainersEnv#value
     */
    readonly value?: string;
}
/**
 * Converts an object of type 'HeadlampInitContainersEnv' to JSON representation.
 */
export declare function toJson_HeadlampInitContainersEnv(obj: HeadlampInitContainersEnv | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampInitContainersVolumeMounts
 */
export interface HeadlampInitContainersVolumeMounts {
    /**
     * Name of the volume mount
     *
     * @schema HeadlampInitContainersVolumeMounts#name
     */
    readonly name?: string;
    /**
     * Mount path of the volume mount
     *
     * @schema HeadlampInitContainersVolumeMounts#mountPath
     */
    readonly mountPath?: string;
    /**
     * Read only of the volume mount
     *
     * @schema HeadlampInitContainersVolumeMounts#readOnly
     */
    readonly readOnly?: boolean;
}
/**
 * Converts an object of type 'HeadlampInitContainersVolumeMounts' to JSON representation.
 */
export declare function toJson_HeadlampInitContainersVolumeMounts(obj: HeadlampInitContainersVolumeMounts | undefined): Record<string, any> | undefined;
/**
 * OIDC configuration
 *
 * @schema HeadlampConfigOidc
 */
export interface HeadlampConfigOidc {
    /**
     * Secret created by Headlamp to authenticate with the OIDC provider
     *
     * @schema HeadlampConfigOidc#secret
     */
    readonly secret?: HeadlampConfigOidcSecret;
    /**
     * Issuer of the OIDC provider
     *
     * @schema HeadlampConfigOidc#clientID
     */
    readonly clientId?: string;
    /**
     * Client ID of the OIDC provider
     *
     * @schema HeadlampConfigOidc#clientSecret
     */
    readonly clientSecret?: string;
    /**
     * Client secret of the OIDC provider
     *
     * @schema HeadlampConfigOidc#issuerURL
     */
    readonly issuerUrl?: string;
    /**
     * Scopes of the OIDC provider
     *
     * @schema HeadlampConfigOidc#scopes
     */
    readonly scopes?: string;
    /**
     * Use PKCE (Proof Key for Code Exchange) for enhanced security in OIDC flow
     *
     * @schema HeadlampConfigOidc#usePKCE
     */
    readonly usePkce?: boolean;
    /**
     * External secret to use for OIDC configuration
     *
     * @schema HeadlampConfigOidc#externalSecret
     */
    readonly externalSecret?: HeadlampConfigOidcExternalSecret;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampConfigOidc#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampConfigOidc' to JSON representation.
 */
export declare function toJson_HeadlampConfigOidc(obj: HeadlampConfigOidc | undefined): Record<string, any> | undefined;
/**
 * Kubernetes Service type
 *
 * @schema HeadlampServiceType
 */
export declare enum HeadlampServiceType {
    /** ClusterIP */
    CLUSTER_IP = "ClusterIP",
    /** NodePort */
    NODE_PORT = "NodePort",
    /** LoadBalancer */
    LOAD_BALANCER = "LoadBalancer",
    /** ExternalName */
    EXTERNAL_NAME = "ExternalName"
}
/**
 * @schema HeadlampServiceExtraServicePorts
 */
export interface HeadlampServiceExtraServicePorts {
    /**
     * Port name (must be unique within the Service)
     *
     * @schema HeadlampServiceExtraServicePorts#name
     */
    readonly name: string;
    /**
     * Service port number
     *
     * @schema HeadlampServiceExtraServicePorts#port
     */
    readonly port: number;
    /**
     * Pod-side target port (number or named port). Defaults to `port` when omitted
     *
     * @default port` when omitted
     * @schema HeadlampServiceExtraServicePorts#targetPort
     */
    readonly targetPort?: any;
    /**
     * Protocol (TCP/UDP/SCTP). Defaults to TCP
     *
     * @default TCP
     * @schema HeadlampServiceExtraServicePorts#protocol
     */
    readonly protocol?: HeadlampServiceExtraServicePortsProtocol;
    /**
     * Node port (only honored when service.type is NodePort or LoadBalancer)
     *
     * @schema HeadlampServiceExtraServicePorts#nodePort
     */
    readonly nodePort?: number;
}
/**
 * Converts an object of type 'HeadlampServiceExtraServicePorts' to JSON representation.
 */
export declare function toJson_HeadlampServiceExtraServicePorts(obj: HeadlampServiceExtraServicePorts | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampPersistentVolumeClaimSelector
 */
export interface HeadlampPersistentVolumeClaimSelector {
    /**
     * @schema HeadlampPersistentVolumeClaimSelector#matchLabels
     */
    readonly matchLabels?: any;
    /**
     * @schema HeadlampPersistentVolumeClaimSelector#matchExpressions
     */
    readonly matchExpressions?: HeadlampPersistentVolumeClaimSelectorMatchExpressions[];
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampPersistentVolumeClaimSelector#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampPersistentVolumeClaimSelector' to JSON representation.
 */
export declare function toJson_HeadlampPersistentVolumeClaimSelector(obj: HeadlampPersistentVolumeClaimSelector | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampIngressHosts
 */
export interface HeadlampIngressHosts {
    /**
     * @schema HeadlampIngressHosts#host
     */
    readonly host?: string;
    /**
     * @schema HeadlampIngressHosts#paths
     */
    readonly paths?: HeadlampIngressHostsPaths[];
}
/**
 * Converts an object of type 'HeadlampIngressHosts' to JSON representation.
 */
export declare function toJson_HeadlampIngressHosts(obj: HeadlampIngressHosts | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampIngressTls
 */
export interface HeadlampIngressTls {
    /**
     * @schema HeadlampIngressTls#secretName
     */
    readonly secretName?: string;
    /**
     * @schema HeadlampIngressTls#hosts
     */
    readonly hosts?: string[];
}
/**
 * Converts an object of type 'HeadlampIngressTls' to JSON representation.
 */
export declare function toJson_HeadlampIngressTls(obj: HeadlampIngressTls | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampHttpRouteParentRefs
 */
export interface HeadlampHttpRouteParentRefs {
    /**
     * Name of the parent gateway
     *
     * @schema HeadlampHttpRouteParentRefs#name
     */
    readonly name: string;
    /**
     * Namespace of the parent gateway
     *
     * @schema HeadlampHttpRouteParentRefs#namespace
     */
    readonly namespace?: string;
    /**
     * Section name of the parent gateway listener
     *
     * @schema HeadlampHttpRouteParentRefs#sectionName
     */
    readonly sectionName?: string;
}
/**
 * Converts an object of type 'HeadlampHttpRouteParentRefs' to JSON representation.
 */
export declare function toJson_HeadlampHttpRouteParentRefs(obj: HeadlampHttpRouteParentRefs | undefined): Record<string, any> | undefined;
/**
 * Limits of the init container
 *
 * @schema HeadlampInitContainersResourcesLimits
 */
export interface HeadlampInitContainersResourcesLimits {
    /**
     * CPU limit
     *
     * @schema HeadlampInitContainersResourcesLimits#cpu
     */
    readonly cpu?: string;
    /**
     * Memory limit
     *
     * @schema HeadlampInitContainersResourcesLimits#memory
     */
    readonly memory?: string;
}
/**
 * Converts an object of type 'HeadlampInitContainersResourcesLimits' to JSON representation.
 */
export declare function toJson_HeadlampInitContainersResourcesLimits(obj: HeadlampInitContainersResourcesLimits | undefined): Record<string, any> | undefined;
/**
 * Requests of the init container
 *
 * @schema HeadlampInitContainersResourcesRequests
 */
export interface HeadlampInitContainersResourcesRequests {
    /**
     * CPU request
     *
     * @schema HeadlampInitContainersResourcesRequests#cpu
     */
    readonly cpu?: string;
    /**
     * Memory request
     *
     * @schema HeadlampInitContainersResourcesRequests#memory
     */
    readonly memory?: string;
}
/**
 * Converts an object of type 'HeadlampInitContainersResourcesRequests' to JSON representation.
 */
export declare function toJson_HeadlampInitContainersResourcesRequests(obj: HeadlampInitContainersResourcesRequests | undefined): Record<string, any> | undefined;
/**
 * Secret created by Headlamp to authenticate with the OIDC provider
 *
 * @schema HeadlampConfigOidcSecret
 */
export interface HeadlampConfigOidcSecret {
    /**
     * Name of the secret
     *
     * @schema HeadlampConfigOidcSecret#name
     */
    readonly name?: string;
    /**
     * Create the secret
     *
     * @schema HeadlampConfigOidcSecret#create
     */
    readonly create?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampConfigOidcSecret#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampConfigOidcSecret' to JSON representation.
 */
export declare function toJson_HeadlampConfigOidcSecret(obj: HeadlampConfigOidcSecret | undefined): Record<string, any> | undefined;
/**
 * External secret to use for OIDC configuration
 *
 * @schema HeadlampConfigOidcExternalSecret
 */
export interface HeadlampConfigOidcExternalSecret {
    /**
     * Name of the external secret
     *
     * @schema HeadlampConfigOidcExternalSecret#name
     */
    readonly name?: string;
    /**
     * Enable the external secret
     *
     * @schema HeadlampConfigOidcExternalSecret#enabled
     */
    readonly enabled?: boolean;
    /**
     * Values that are not available in values.schema.json will not be code generated. You can add such values to this property.
     *
     * @schema HeadlampConfigOidcExternalSecret#additionalValues
     */
    readonly additionalValues?: {
        [key: string]: any;
    };
}
/**
 * Converts an object of type 'HeadlampConfigOidcExternalSecret' to JSON representation.
 */
export declare function toJson_HeadlampConfigOidcExternalSecret(obj: HeadlampConfigOidcExternalSecret | undefined): Record<string, any> | undefined;
/**
 * Protocol (TCP/UDP/SCTP). Defaults to TCP
 *
 * @default TCP
 * @schema HeadlampServiceExtraServicePortsProtocol
 */
export declare enum HeadlampServiceExtraServicePortsProtocol {
    /** TCP */
    TCP = "TCP",
    /** UDP */
    UDP = "UDP",
    /** SCTP */
    SCTP = "SCTP"
}
/**
 * @schema HeadlampPersistentVolumeClaimSelectorMatchExpressions
 */
export interface HeadlampPersistentVolumeClaimSelectorMatchExpressions {
    /**
     * @schema HeadlampPersistentVolumeClaimSelectorMatchExpressions#key
     */
    readonly key?: string;
    /**
     * @schema HeadlampPersistentVolumeClaimSelectorMatchExpressions#operator
     */
    readonly operator?: string;
    /**
     * @schema HeadlampPersistentVolumeClaimSelectorMatchExpressions#values
     */
    readonly values?: string[];
}
/**
 * Converts an object of type 'HeadlampPersistentVolumeClaimSelectorMatchExpressions' to JSON representation.
 */
export declare function toJson_HeadlampPersistentVolumeClaimSelectorMatchExpressions(obj: HeadlampPersistentVolumeClaimSelectorMatchExpressions | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampIngressHostsPaths
 */
export interface HeadlampIngressHostsPaths {
    /**
     * @schema HeadlampIngressHostsPaths#path
     */
    readonly path: string;
    /**
     * @schema HeadlampIngressHostsPaths#type
     */
    readonly type: string;
    /**
     * Optional override of the backend Service for this path
     *
     * @schema HeadlampIngressHostsPaths#backend
     */
    readonly backend?: HeadlampIngressHostsPathsBackend;
}
/**
 * Converts an object of type 'HeadlampIngressHostsPaths' to JSON representation.
 */
export declare function toJson_HeadlampIngressHostsPaths(obj: HeadlampIngressHostsPaths | undefined): Record<string, any> | undefined;
/**
 * Optional override of the backend Service for this path
 *
 * @schema HeadlampIngressHostsPathsBackend
 */
export interface HeadlampIngressHostsPathsBackend {
    /**
     * @schema HeadlampIngressHostsPathsBackend#service
     */
    readonly service?: HeadlampIngressHostsPathsBackendService;
}
/**
 * Converts an object of type 'HeadlampIngressHostsPathsBackend' to JSON representation.
 */
export declare function toJson_HeadlampIngressHostsPathsBackend(obj: HeadlampIngressHostsPathsBackend | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampIngressHostsPathsBackendService
 */
export interface HeadlampIngressHostsPathsBackendService {
    /**
     * Service name (supports tpl). Defaults to the Headlamp Service when omitted
     *
     * @default the Headlamp Service when omitted
     * @schema HeadlampIngressHostsPathsBackendService#name
     */
    readonly name?: string;
    /**
     * @schema HeadlampIngressHostsPathsBackendService#port
     */
    readonly port?: HeadlampIngressHostsPathsBackendServicePort;
}
/**
 * Converts an object of type 'HeadlampIngressHostsPathsBackendService' to JSON representation.
 */
export declare function toJson_HeadlampIngressHostsPathsBackendService(obj: HeadlampIngressHostsPathsBackendService | undefined): Record<string, any> | undefined;
/**
 * @schema HeadlampIngressHostsPathsBackendServicePort
 */
export interface HeadlampIngressHostsPathsBackendServicePort {
    /**
     * @schema HeadlampIngressHostsPathsBackendServicePort#number
     */
    readonly number?: number;
    /**
     * @schema HeadlampIngressHostsPathsBackendServicePort#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'HeadlampIngressHostsPathsBackendServicePort' to JSON representation.
 */
export declare function toJson_HeadlampIngressHostsPathsBackendServicePort(obj: HeadlampIngressHostsPathsBackendServicePort | undefined): Record<string, any> | undefined;
